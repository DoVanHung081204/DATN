package com.example.datn_sd_78;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatnSd78Application {

	public static void main(String[] args) {
		SpringApplication.run(DatnSd78Application.class, args);
	}

}

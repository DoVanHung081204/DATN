package com.example.datn_sd_78.config;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;

@Component
public class AuthenticationSuccessHandlers implements AuthenticationSuccessHandler {

    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();

        // Kiểm tra quyền hạn của người dùng và điều hướng phù hợp
        for (GrantedAuthority authority : authorities) {
            String role = authority.getAuthority();
            if ("ADMIN".equals(role)) {
                // Chuyển hướng đến trang quản lý dành riêng cho ADMIN
                redirectStrategy.sendRedirect(request, response, "/admin/index");
                return;
            } else if ("STAFF".equals(role)) {
                // Chuyển hướng đến trang quản lý dành riêng cho STAFF
                redirectStrategy.sendRedirect(request, response, "/order");
                return;
            } else if ("CLIENT".equals(role)) {
                if (request.getSession().getAttribute("selectedProduct") != null) {
                    // Chuyển hướng đến trang chi tiết sản phẩm đã chọn
                    redirectStrategy.sendRedirect(request, response, "/online/detail_user");
                } else {
                    // Nếu không có sản phẩm, chuyển hướng về trang danh sách sản phẩm
                    redirectStrategy.sendRedirect(request, response, "/online/product");
                }
                return;

            } else {
                // Nếu không phải là các vai trò hợp lệ, ném ngoại lệ hoặc xử lý tùy ý
                throw new IllegalStateException("Không có quyền hợp lệ.");
            }
        }
    }
}



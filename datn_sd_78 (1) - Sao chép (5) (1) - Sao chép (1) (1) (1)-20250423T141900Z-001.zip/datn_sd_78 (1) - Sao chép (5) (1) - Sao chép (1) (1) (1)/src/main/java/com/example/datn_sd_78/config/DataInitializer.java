package com.example.datn_sd_78.config;

import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.entity.VaiTro;
import com.example.datn_sd_78.repository.UserRepository;
import com.example.datn_sd_78.repository.VaiTroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DataInitializer implements CommandLineRunner {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private VaiTroRepository vaiTroRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Override
    public void run(String... args) throws Exception {
        // Kiểm tra nếu chưa có tài khoản admin
        if (userRepository.findByTaiKhoan("admin").isEmpty()) {
            // Tạo tài khoản admin
            Users adminUser = new Users();
            adminUser.setTaiKhoan("admin");
            adminUser.setMatKhau(passwordEncoder.encode("admin"));
            adminUser.setEmail("admin@example.com");
            adminUser.setNgayTao(new Date());
            adminUser.setTrangThai(1);

            VaiTro vaiTro = vaiTroRepository.findByTenVaiTro("ADMIN");
            adminUser.setVaiTro(vaiTro);

            userRepository.save(adminUser);

            // Tạo thông tin nhân viên cho admin (Nếu cần)
            NhanVien nhanVien = new NhanVien();
            nhanVien.setMaNhanVien("NV001");
            nhanVien.setTenNhanVien("Admin");
            nhanVien.setEmail("admin@example.com");
            nhanVien.setGioiTinh(1); // Ví dụ, 1 là Nam
            nhanVien.setDiaChi("Admin Address");
//            nhanVien.setSoDienThoai("0123456789");
            nhanVien.setTrangThai(1);
//            nhanVien.setNgayTao(new Date());
            nhanVien.setUser(adminUser);

            System.out.println("Tài khoản admin đã được tạo thành công!");
        }
    }
}

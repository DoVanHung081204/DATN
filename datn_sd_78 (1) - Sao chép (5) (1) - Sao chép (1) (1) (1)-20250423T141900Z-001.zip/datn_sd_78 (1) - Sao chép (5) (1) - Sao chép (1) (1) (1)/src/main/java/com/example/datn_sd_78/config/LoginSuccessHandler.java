package com.example.datn_sd_78.config;

import com.example.datn_sd_78.entity.GioHang;
import com.example.datn_sd_78.service.GioHangService;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class LoginSuccessHandler implements AuthenticationSuccessHandler {

    private final GioHangService gioHangService;

    public LoginSuccessHandler(GioHangService gioHangService) {
        this.gioHangService = gioHangService;
    }

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
        // Lấy thông tin người dùng hiện tại
        String username = authentication.getName();

        // Truy vấn giỏ hàng của người dùng từ cơ sở dữ liệu
        GioHang gioHang = gioHangService.getGioHangByCurrentCustomer();

        // Lưu giỏ hàng vào session
        HttpSession session = request.getSession();
        session.setAttribute("gioHang", gioHang);

        // Chuyển hướng đến trang sản phẩm hoặc trang khác
        try {
            response.sendRedirect("/online/product");
        } catch (IOException e) {
            e.printStackTrace();  // Optionally log the exception
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Redirect failed.");
        }
    }
}

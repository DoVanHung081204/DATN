package com.example.datn_sd_78.config;

import com.example.datn_sd_78.entity.GioHangChiTiet;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.service.SanPhamService;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.logout.LogoutHandler;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.security.web.firewall.HttpFirewall;
import org.springframework.security.web.firewall.StrictHttpFirewall;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

@Configuration
@EnableWebSecurity
@EnableMethodSecurity
public class SecurityConfig {

    private final UserDetailsService userDetailsService;
    private final AuthenticationSuccessHandlers successHandler;

    // Tiêm SanPhamService vào constructor
    @Autowired
    public SecurityConfig(UserDetailsService userDetailsService, AuthenticationSuccessHandlers successHandler) {
        this.userDetailsService = userDetailsService;
        this.successHandler = successHandler;
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder(10); // Độ mạnh của mã hóa
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider provider = new DaoAuthenticationProvider();
        provider.setUserDetailsService(userDetailsService);
        provider.setPasswordEncoder(passwordEncoder());
        return provider;
    }

    @Bean
    public SecurityContextLogoutHandler customLogoutHandler() {
        return new SecurityContextLogoutHandler();
    }

    // Cấu hình StrictHttpFirewall để cho phép URL có dấu "//"
    @Bean
    public HttpFirewall allowUrlWithDoubleSlash() {
        StrictHttpFirewall firewall = new StrictHttpFirewall();
        firewall.setAllowUrlEncodedDoubleSlash(true); // Cho phép chuỗi "//" trong URL
        return firewall;
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(request -> request
                        .requestMatchers("/WEB-INF/view/**", "/css/**", "/anh/**", "/fonts/**", "/img/**", "/js/**", "/index/**", "/image/**", "/qr/**", "/quenMatKhau/**", "/dangKy/**")
                        .permitAll()
                        .requestMatchers("/admin/**", "/khuyen-mai/**","/khachhang/**","/nhanvien/**","/order/**").hasAnyAuthority("ADMIN", "STAFF")
                        .requestMatchers("/product/**","/home/**","/online").hasAuthority("CLIENT")
                        .anyRequest().permitAll()
                )
                .formLogin(form -> form
                        .loginPage("/login")
                        .permitAll()
                        .usernameParameter("username")
                        .passwordParameter("password")
                        .successHandler(successHandler)
                )
                .logout(logout -> logout
                        .logoutUrl("/logout")
                        .logoutSuccessUrl("/online/product")
                        .permitAll()
                )
                .csrf(csrf -> csrf.disable());

        // Áp dụng cấu hình firewall mới
        http.setSharedObject(HttpFirewall.class, allowUrlWithDoubleSlash());
        return http.build();
    }
}

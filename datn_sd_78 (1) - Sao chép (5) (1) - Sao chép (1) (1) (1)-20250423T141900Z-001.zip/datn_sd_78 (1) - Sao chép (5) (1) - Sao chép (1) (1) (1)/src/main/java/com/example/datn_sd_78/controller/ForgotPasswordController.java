package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.service.AuthService;
import com.example.datn_sd_78.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ForgotPasswordController {

    @Autowired
    private AuthService userService;  // Giả sử bạn có UserService để xử lý logic liên quan đến User

    @Autowired
    private EmailService emailService;  // Tiêm emailService để gửi email
    @GetMapping("/forgot-password")
    public String showForgotPasswordPage() {
        return "forgot-password";  // Trả về trang JSP để người dùng nhập email
    }

    @PostMapping("/sendResetLink")
    public String sendResetLink(@RequestParam("email") String email, Model model) {
        try {
            // Tạo token đặt lại mật khẩu
            String resetToken = userService.generateResetToken(email);

            // Tạo đường link đặt lại mật khẩu
            String resetLink = "http://localhost:8080/reset-password?token=" + resetToken;

            // Gửi đường link qua email cho người dùng
            emailService.sendResetLink(email, resetLink);  // Gọi emailService để gửi email

            model.addAttribute("message", "Đã gửi yêu cầu đặt lại mật khẩu vào email của bạn!");
        } catch (Exception e) {
            model.addAttribute("message", "Email không tồn tại!");
        }
        return "forgot-password"; // Trở lại trang quên mật khẩu với thông báo
    }
}

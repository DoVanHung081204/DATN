package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.service.HoaDonServices;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/hoa-don")
public class HoaDonController {

    @Autowired
    private HoaDonServices hoaDonServices;

    // Phương thức xử lý yêu cầu GET
    @GetMapping("/{id}")
    public ResponseEntity<HoaDon> getHoaDonById(@PathVariable Integer id) {
        HoaDon hoaDon = hoaDonServices.findById(id);
        if (hoaDon != null) {
            return ResponseEntity.ok(hoaDon);
        } else {
            return ResponseEntity.notFound().build();
        }
    }
}


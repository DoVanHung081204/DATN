package com.example.datn_sd_78.controller;


import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.repository.KhachHangRepository;
import com.example.datn_sd_78.service.AuthService;
import com.example.datn_sd_78.service.KhachHangService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@Controller
@RequestMapping("/khachhang")
public class KhachHangController {
    @Autowired
    KhachHangRepository khachHangRepository;
    @Autowired
    private AuthService authService;

    @GetMapping("/list")
    public String getAllKhachHang(Model model,
                                  @RequestParam(defaultValue = "0") int page,
                                  @RequestParam(value = "searchTerm", required = false) String searchTerm) {
        int pageSize = 5;
        Pageable pageable = PageRequest.of(page, pageSize);
        Page<KhachHang> khachHangPage;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            khachHangPage = khachHangRepository.findByHoTenContainingIgnoreCase(searchTerm, pageable);
            if (khachHangPage.getTotalElements() == 0) {
                khachHangPage = khachHangRepository.findAll(pageable);
            }
        } else {
            khachHangPage = khachHangRepository.findAll(pageable);
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khachHangs", khachHangPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", khachHangPage.getTotalPages());
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("searchTerm", searchTerm);

        return "khach-hang/index";
    }

@Autowired
    private KhachHangService khachHangService;

    @GetMapping("/add")
    public String viewAdd(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khachHang", new KhachHang());
        return "khach-hang/formkh";
    }

    @PostMapping("/add")
    public String register(@RequestParam String taiKhoan,
                           @RequestParam String matKhau,
                           @RequestParam String email,
                           @RequestParam String ten,
                           @RequestParam String diaChi,
                           @RequestParam String soDienThoai,
                           @RequestParam Integer gioiTinh,
                           Model model) {

        // Gọi service để thực hiện đăng ký
        String result = khachHangService.addKH(taiKhoan, matKhau, email, ten, diaChi, soDienThoai,gioiTinh);

        if (result.equals("success")) {
            return "redirect:/khachhang/list";
        } else {
            // Nếu có lỗi, thêm lỗi vào model và trả về trang đăng ký
            model.addAttribute("error", result);
            return "khach-hang/formkh";
        }
    }

    @GetMapping("/update/{id}")
    public String viewUpdate(@PathVariable("id") Integer id, Model model) {
        Optional<KhachHang> khachHangOpt = khachHangRepository.findById(id);
        if (!khachHangOpt.isPresent()) {
            model.addAttribute("error", "Khách hàng không tồn tại!");
            return "khach-hang/index";
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        KhachHang khachHang = khachHangOpt.get();
        model.addAttribute("khachHang", khachHang);
        return "khach-hang/updatekh";
    }

    // Phương thức xử lý cập nhật thông tin khách hàng
    @PostMapping("/update")
    public String update(@RequestParam Integer id,
                         @RequestParam String taiKhoan,
                         @RequestParam String matKhau,
                         @RequestParam String email,
                         @RequestParam String ten,
                         @RequestParam String diaChi,
                         @RequestParam String soDienThoai,
                         @RequestParam Integer trangThai,
                         Model model) {

        // Gọi service để thực hiện cập nhật
        String result = khachHangService.updateKH(id, taiKhoan, matKhau, email, ten, diaChi, soDienThoai, trangThai);

        if (result.equals("success")) {
            return "redirect:/khachhang/list";
        } else {
            model.addAttribute("error", result);
            return "khach-hang/updatekh";
        }
    }

}
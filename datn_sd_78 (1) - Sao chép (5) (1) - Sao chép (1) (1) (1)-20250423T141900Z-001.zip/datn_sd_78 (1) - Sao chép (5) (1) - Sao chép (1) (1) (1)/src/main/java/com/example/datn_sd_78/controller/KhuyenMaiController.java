package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.KhuyenMai;
import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.SanPham;

import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.repository.KhuyenMaiRepository;
import com.example.datn_sd_78.service.AuthService;
import com.example.datn_sd_78.service.KhuyenMaiService;
import com.example.datn_sd_78.service.SanPhamService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/khuyen-mai")
public class KhuyenMaiController {

    @Autowired
    private KhuyenMaiService khuyenMaiService;

    @Autowired
    private SanPhamService sanPhamService;
    @Autowired
    private KhuyenMaiRepository khuyenMaiRepository;
    @Autowired
    private AuthService authService;

    @GetMapping
    public String showKhuyenMaiList(Model model) {
        List<KhuyenMai> khuyenMais = khuyenMaiService.findAll();
        for (KhuyenMai km : khuyenMais) {
            if (km.getNgayKetThuc().before(new Date(System.currentTimeMillis()))) {
                km.setTrangThai(0); // Đặt lại trạng thái
                khuyenMaiRepository.save(km); // Cập nhật vào database
            }
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khuyenMais", khuyenMais);
        return "khuyenmai/list"; // Trả về view hiển thị danh sách khuyến mại
    }


    @GetMapping("/create")
    public String showCreateKhuyenMaiForm(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khuyenMai", new KhuyenMai());
        return "khuyenmai/create"; // Trả về view để tạo khuyến mại mới
    }

    @PostMapping("/create")
    public String createKhuyenMai(@ModelAttribute KhuyenMai khuyenMai) {
        khuyenMaiService.save(khuyenMai);
        return "redirect:/khuyen-mai"; // Quay lại danh sách khuyến mại
    }
    //Lọc trạng thái
    @GetMapping("/filter")
    public String filterKhuyenMai(@RequestParam("status") Integer status, Model model) {
        List<KhuyenMai> khuyenMais = khuyenMaiService.filterByStatus(status);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khuyenMais", khuyenMais);
        return "khuyenmai/list"; // Trả về view hiển thị danh sách khuyến mại
    }

    //
    @GetMapping("/products")
    public String showProductsForPromotion(@RequestParam Integer id, Model model) {
        // Tìm khuyến mãi theo ID
        Optional<KhuyenMai> khuyenMaiOptional = khuyenMaiRepository.findById(id);

        if (khuyenMaiOptional.isPresent()) {
            KhuyenMai khuyenMai = khuyenMaiOptional.get(); // Lấy đối tượng khuyến mãi
            List<SanPham> availableProducts = khuyenMaiService.getAvailableProductsForPromotion(id);
            model.addAttribute("sanPhams", availableProducts);
            model.addAttribute("khuyenMai", khuyenMai); // Thêm khuyến mãi vào model
        } else {
            // Xử lý trường hợp không tìm thấy khuyến mãi
            model.addAttribute("errorMessage", "Khuyến mãi không tồn tại.");
            return "error"; // Trả về trang lỗi hoặc chuyển hướng
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        return "khuyenmai/products"; // Trả về view để chọn sản phẩm
    }
//
    // KhuyenMaiController.java

    @GetMapping("/search")
    public String searchPromotion(@RequestParam("query") String query, Model model) {
        List<KhuyenMai> promotions = khuyenMaiService.searchByCodeOrName(query);
        model.addAttribute("khuyenMais", promotions);
        return "khuyenmai/list"; // Trả về trang danh sách khuyến mãi
    }



    //
    @PostMapping("/apply-discount")
    public String applyDiscount(@RequestParam Integer khuyenMaiId, @RequestParam List<Integer> productIds, Model model) {
        // Tìm khuyến mãi theo ID
        Optional<KhuyenMai> khuyenMaiOptional = khuyenMaiRepository.findById(khuyenMaiId);

        if (!khuyenMaiOptional.isPresent()) {
            model.addAttribute("errorMessage", "Khuyến mãi không tồn tại.");
            return "redirect:/khuyen-mai"; // Quay lại danh sách khuyến mại
        }

        KhuyenMai khuyenMai = khuyenMaiOptional.get();

        // Kiểm tra trạng thái khuyến mãi
        if (khuyenMai.getTrangThai() == 0 || khuyenMai.getTrangThai() == 2) {
            model.addAttribute("errorMessage", "Khuyến mãi không hoạt động hoặc chưa bắt đầu. Không thể thêm sản phẩm.");
            return "redirect:/khuyen-mai"; // Chuyển hướng về danh sách khuyến mại với thông báo lỗi
        }

        try {
            khuyenMaiService.applyDiscount(khuyenMaiId, productIds);
        } catch (IllegalArgumentException e) {
            model.addAttribute("errorMessage", e.getMessage());
            // Lấy lại danh sách sản phẩm để hiển thị
            List<SanPham> availableProducts = khuyenMaiService.getAvailableProductsForPromotion(khuyenMaiId);
            model.addAttribute("sanPhams", availableProducts);
            model.addAttribute("khuyenMai", khuyenMai);
            return "khuyenmai/products"; // Quay lại trang chọn sản phẩm với thông báo lỗi
        }

        return "redirect:/khuyen-mai"; // Quay lại danh sách khuyến mại
    }


    @GetMapping("/edit/{id}")
    public String showEditKhuyenMaiForm(@PathVariable("id") Integer id, Model model) {
        Optional<KhuyenMai> khuyenMaiOptional = khuyenMaiRepository.findById(id);

        if (!khuyenMaiOptional.isPresent()) {
            model.addAttribute("errorMessage", "Khuyến mãi không tồn tại.");
            return "error"; // Hoặc redirect về trang khác
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("khuyenMai", khuyenMaiOptional.get());
        return "khuyenmai/edit"; // Trả về view để sửa khuyến mãi
    }
    @PostMapping("/edit")
    public String updateKhuyenMai(@ModelAttribute KhuyenMai khuyenMai) {
        // Kiểm tra xem khuyến mãi có tồn tại không
        Optional<KhuyenMai> existingKhuyenMai = khuyenMaiRepository.findById(khuyenMai.getId());

        if (!existingKhuyenMai.isPresent()) {
            return "redirect:/khuyen-mai?error=Khuyến mãi không tồn tại.";
        }

        // Cập nhật khuyến mãi
        khuyenMaiService.save(khuyenMai);
        return "redirect:/khuyen-mai"; // Quay lại danh sách khuyến mãi
    }
}



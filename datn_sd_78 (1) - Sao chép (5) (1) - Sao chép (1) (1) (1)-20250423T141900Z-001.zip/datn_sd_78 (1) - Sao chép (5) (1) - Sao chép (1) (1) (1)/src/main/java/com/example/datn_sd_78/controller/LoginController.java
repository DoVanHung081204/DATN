package com.example.datn_sd_78.controller;
import com.example.datn_sd_78.entity.*;
import com.example.datn_sd_78.repository.*;
import com.example.datn_sd_78.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

@Controller
public class LoginController {

    @Autowired
    @Lazy
    AuthService authService;

    @Autowired
    ChiTietSanPhamRepository chiTietSanPhamRepository;

    @Autowired
    KhachHangVoucherRepository khachHangVoucherRepository;

    @Autowired
    TrangThaiHoaDonChiTietRepo trangThaiHoaDonChiTietRepo;

    @Autowired
    HoaDonRepository hoaDonRepository;

    @Autowired
    HoaDonChiTietRepository hoaDonChiTietRepository;

    @Autowired
    TrangThaiHoaDonRepo trangThaiHoaDonRepository;

    @Autowired
    UserRepository userRepository;


    // Xử lý trang login
    @GetMapping("/login")
    public String showLoginPage(@RequestParam(value = "error", required = false) String error,
                                @RequestParam(value = "logout", required = false) String logout,
                                Model model) {
        if (error != null) {
            model.addAttribute("error", "Tài khoản hoặc mật khẩu không chính xác.");
        }
        if (logout != null) {
            model.addAttribute("message", "Bạn đã đăng xuất thành công.");
        }
        return "login"; // Trả về trang JSP đăng nhập
    }

    @GetMapping("/register")
    public String showRegistrationForm() {
        return "register";
    }


    @PostMapping("/register")
    public String register(@RequestParam String taiKhoan,
                           @RequestParam String matKhau,
                           @RequestParam String email,
                           @RequestParam String ten,
                           @RequestParam String diaChi,
                           @RequestParam String soDienThoai,
                           @RequestParam Integer gioiTinh,
                           Model model) {

        String result = authService.registerUser(taiKhoan, matKhau, email, ten, diaChi, soDienThoai, gioiTinh);

        if (result.equals("success")) {
            return "redirect:/login";
        } else {
            model.addAttribute("error", result);
            return "register";
        }
    }

    @GetMapping("/home")
    public String showHomePage(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users user = authService.findUserByUsername(username);
        KhachHang khachHang = user.getKhachHang();

        // Lấy các trạng thái hoa đơn cho phần "Đang xử lý"
        List<TrangThaiHoaDon> trangThaiPendingList = trangThaiHoaDonRepository.findAllByTenIn(Arrays.asList(
                "Chờ xác nhận",
                "Đang xử lý",
                "Chờ đơn vị vận chuyển",
                "Đang vận chuyển",
                "Chờ nhận hàng"
        ));

        // Lấy các trạng thái hoa đơn cho phần "Đã hoàn thành"
        List<TrangThaiHoaDon> trangThaiCompletedList = trangThaiHoaDonRepository.findAllByTenIn(Arrays.asList(
                "Đã nhận hàng",
                "Hoàn thành"
        ));

        // Lấy các trạng thái hoa đơn cho phần "Đã hủy"
        List<TrangThaiHoaDon> trangThaiCancelledList = trangThaiHoaDonRepository.findAllByTenIn(Arrays.asList(
                "Hủy"
        ));

        // Lấy danh sách đơn hàng với các trạng thái trên
        List<HoaDon> ordersPending = hoaDonRepository.findByTrangThaiInAndKhachHang(trangThaiPendingList, khachHang);
        List<HoaDon> ordersCompleted = hoaDonRepository.findByTrangThaiInAndKhachHang(trangThaiCompletedList, khachHang);
        List<HoaDon> ordersCancelled = hoaDonRepository.findByTrangThaiInAndKhachHang(trangThaiCancelledList, khachHang);

        // Sắp xếp các danh sách đơn hàng theo ngày tạo giảm dần
        ordersPending.sort((o1, o2) -> o2.getNgayTao().compareTo(o1.getNgayTao()));  // Đơn hàng mới nhất lên đầu
        ordersCompleted.sort((o1, o2) -> o2.getNgayTao().compareTo(o1.getNgayTao()));  // Đơn hàng mới nhất lên đầu
        ordersCancelled.sort((o1, o2) -> o2.getNgayTao().compareTo(o1.getNgayTao()));  // Đơn hàng mới nhất lên đầu

        // Truyền thông tin vào model
        model.addAttribute("user", user);
        model.addAttribute("khachHang", khachHang);
        model.addAttribute("ordersPending", ordersPending);  // Danh sách đơn hàng đang xử lý
        model.addAttribute("ordersCompleted", ordersCompleted);  // Danh sách đơn hàng đã hoàn thành
        model.addAttribute("ordersCancelled", ordersCancelled);  // Danh sách đơn hàng đã hủy

        return "home";  // Hoặc tên trang JSP của bạn
    }


    @PostMapping("/update-account")
    public String updateAccount(@RequestParam("email") String email,
                                @RequestParam("hoTen") String hoTen,
                                @RequestParam("sdt") String sdt,
                                @RequestParam("diaChi") String diaChi,
                                Principal principal) {
        String taiKhoan = principal.getName();

        Optional<Users> optionalUser = userRepository.findByTaiKhoan(taiKhoan);

        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            // Cập nhật thông tin người dùng
            user.setEmail(email);
            if (user.getKhachHang() != null) {
                user.getKhachHang().setHoTen(hoTen);
                user.getKhachHang().setSdt(sdt);
                user.getKhachHang().setDiaChi(diaChi);
            }

            userRepository.save(user);

            // Chuyển hướng về trang chủ sau khi cập nhật
            return "redirect:/home"; // Chuyển hướng về trang home
        }
        return "error"; // Nếu không tìm thấy người dùng, hiển thị trang lỗi
    }

    @PostMapping("/cancel-order")
    public String cancelOrder(
            @RequestParam("orderId") Integer orderId,
            @RequestParam("reason") String reason,
            RedirectAttributes redirectAttributes) {

        HoaDon order = hoaDonRepository.findById(orderId).orElse(null);
        if (order.getVoucher() != null) {
            KhachHangVoucher khachHangVoucher = khachHangVoucherRepository.findByKhachHangAndVoucher(order.getKhachHang(), order.getVoucher());
            khachHangVoucher.setTrangThai(0);
            khachHangVoucherRepository.save(khachHangVoucher);
        }
        if (order != null) {
            // Danh sách trạng thái cho phép hủy
            List<String> allowedStatuses = Arrays.asList(
                    "Chờ xác nhận",
                    "Đang xử lý"
            );

            // Kiểm tra trạng thái hiện tại của đơn hàng
            if (allowedStatuses.contains(order.getTrangThai().getTen())) {
                // Tìm trạng thái "Hủy"
                Optional<TrangThaiHoaDon> trangThaiHuyOptional = trangThaiHoaDonRepository.findByTen("Hủy");

                // Nếu trạng thái "Hủy" tồn tại, gán cho đơn hàng
                trangThaiHuyOptional.ifPresentOrElse(
                        trangThaiHoaDon -> order.setTrangThai(trangThaiHoaDon),
                        () -> {
                            TrangThaiHoaDon newTrangThai = new TrangThaiHoaDon();
                            newTrangThai.setTen("Hủy");
                            TrangThaiHoaDon savedTrangThai = trangThaiHoaDonRepository.save(newTrangThai);
                            order.setTrangThai(savedTrangThai);
                        }
                );

                // Hoàn lại số lượng sản phẩm trong kho
                List<HoaDonChiTiet> chiTietHoaDons = hoaDonChiTietRepository.findByHoaDon(order);
                for (HoaDonChiTiet chiTiet : chiTietHoaDons) {
                    SanPhamChiTiet sanPham = chiTiet.getChiTietSanPham();
                    int soLuongHoanLai = chiTiet.getSoLuong();
                    sanPham.setSoLuong(sanPham.getSoLuong() + soLuongHoanLai);
                    chiTietSanPhamRepository.save(sanPham);
                }

                // Lưu lý do hủy vào đơn hàng
                order.setMoTa(reason); // Giả sử bảng `HoaDon` có cột `lyDoHuy`
                hoaDonRepository.save(order);

                redirectAttributes.addFlashAttribute("successMessage", "Đơn hàng đã được hủy với lý do: " + reason);
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Không thể hủy đơn hàng này vì trạng thái không hợp lệ.");
            }
        } else {
            redirectAttributes.addFlashAttribute("errorMessage", "Không thể tìm thấy đơn hàng.");
        }

        return "redirect:/home";
    }

    @PostMapping("/huy-san-pham")
    public String huySanPham(
            @RequestParam("chiTietId") Integer id,
            @RequestParam(value = "lyDoHuy", required = false) String lyDoHuy) {
        HoaDonChiTiet hoaDonChiTiet = hoaDonChiTietRepository.findById(id).orElse(null);
        HoaDon hoaDon = hoaDonChiTiet.getHoaDon();
        if(hoaDon.getTrangThai().getTen().equals("Chờ xác nhận") || hoaDon.getTrangThai().getTen().equals("Đang xử lý ")){
            hoaDonChiTiet.setLyDoHuy(lyDoHuy);
            hoaDonChiTiet.setTrangThai(trangThaiHoaDonChiTietRepo.findById(4).orElse(null));
            hoaDonChiTietRepository.save(hoaDonChiTiet);

            // Hoàn lại số lượng sản phẩm
            SanPhamChiTiet sanPham = hoaDonChiTiet.getChiTietSanPham();
            int soLuongHoanLai = hoaDonChiTiet.getSoLuong();
            sanPham.setSoLuong(sanPham.getSoLuong() + soLuongHoanLai);
            chiTietSanPhamRepository.save(sanPham);

            // Xử lý tổng tiền
            BigDecimal tongTien = hoaDon.getTongTien().subtract(hoaDonChiTiet.getTongTien());
            boolean allCancelled = true; // Biến kiểm tra nếu tất cả hóa đơn chi tiết có trạng thái 4

            for (HoaDonChiTiet hdct : hoaDon.getHoaDonChiTiet()) {
                if (hdct.getTrangThai() == null || hdct.getTrangThai().getId() != 4) {
                    allCancelled = false; // Nếu có bất kỳ hóa đơn chi tiết nào không phải trạng thái 4
                    break; // Thoát khỏi vòng lặp
                }
            }

            if (allCancelled) {
                hoaDon.setTienShip(BigDecimal.ZERO); // Set phí ship bằng 0
                hoaDon.setTongTien(BigDecimal.ZERO); // Set tổng tiền bằng 0
                hoaDon.setTrangThai(trangThaiHoaDonRepository.findById(8).orElse(null)); // Chuyển trạng thái hóa đơn thành 8
            } else {
                // Nếu không phải tất cả hóa đơn chi tiết có trạng thái 4
                hoaDon.setTongTien(tongTien); // Cập nhật tổng tiền theo logic khác
            }

            // Xử lý thông báo
            if (hoaDon.getVoucher() != null) {
                if (hoaDon.getVoucher().getGiaTriDonHangToiThieu().compareTo(hoaDon.getTienHang().subtract(hoaDonChiTiet.getTongTien())) < 0) {
                    hoaDon.setTongTien(hoaDon.getTongTien().add(hoaDon.getTienGiam()));
                }
                KhachHangVoucher khachHangVoucher = khachHangVoucherRepository.findByKhachHangAndVoucher(hoaDon.getKhachHang(), hoaDon.getVoucher());
                khachHangVoucher.setTrangThai(0); // Cập nhật trạng thái "đã sử dụng"
                khachHangVoucherRepository.save(khachHangVoucher);
            }

            hoaDonRepository.save(hoaDon);
            return "redirect:/home";
        }
        return "redirect:/home";
    }

}

package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.Users;

import com.example.datn_sd_78.repository.NhanVienRepo;
import com.example.datn_sd_78.service.AuthService;
import com.example.datn_sd_78.service.NhanVienService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/nhanvien")
public class NhanVienController {

    @Autowired
    private NhanVienService nhanVienService;

    @Autowired
    private NhanVienRepo nhanVienRepository;
    @Autowired
    private AuthService authService;
    @GetMapping("/list")
    public String getAllNhanVien(Model model,
                                 @RequestParam(defaultValue = "0") int page,
                                 @RequestParam(value = "searchTerm", required = false) String searchTerm,
                                 @RequestParam(value = "gioiTinh", required = false) Integer gioiTinh,
                                 @RequestParam(value = "trangThai", required = false) Integer trangThai) {
        int pageSize = 8;
        Pageable pageable = PageRequest.of(page, pageSize);
        Page<NhanVien> nhanVienPage;

        if (searchTerm != null && !searchTerm.isEmpty()) {
            if (gioiTinh != null && trangThai != null) {
                nhanVienPage = nhanVienRepository.findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndGioiTinhAndTrangThai(
                        searchTerm, searchTerm, gioiTinh, trangThai, pageable
                );
            } else if (gioiTinh != null) {
                nhanVienPage = nhanVienRepository.findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndGioiTinh(
                        searchTerm, searchTerm, gioiTinh, pageable
                );
            } else if (trangThai != null) {
                nhanVienPage = nhanVienRepository.findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndTrangThai(
                        searchTerm, searchTerm, trangThai, pageable
                );
            } else {
                nhanVienPage = nhanVienRepository.findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCase(
                        searchTerm, searchTerm, pageable
                );
            }
        } else {
            if (gioiTinh != null && trangThai != null) {
                nhanVienPage = nhanVienRepository.findByGioiTinhAndTrangThai(gioiTinh, trangThai, pageable);
            } else if (gioiTinh != null) {
                nhanVienPage = nhanVienRepository.findByGioiTinh(gioiTinh, pageable);
            } else if (trangThai != null) {
                nhanVienPage = nhanVienRepository.findByTrangThai(trangThai, pageable);
            } else {
                nhanVienPage = nhanVienRepository.findAll(pageable);
            }
        }

        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("nhanViens", nhanVienPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", nhanVienPage.getTotalPages());
        model.addAttribute("pageSize", pageSize);
        model.addAttribute("searchTerm", searchTerm);
        model.addAttribute("gioiTinh", gioiTinh);
        model.addAttribute("trangThai", trangThai);

        return "nhanvien/index";
    }


    @GetMapping("/add")
    public String viewAdd(Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("nhanVien", new NhanVien());
        model.addAttribute("gioiTinhOptions", List.of(1, 0)); // 1 for Male, 0 for Female
        return "nhanvien/add";
    }

    @PostMapping("/add")
    public String register(
            @RequestParam String taiKhoan,
            @RequestParam String matKhau,
            @RequestParam String email,
            @RequestParam String ten,
            @RequestParam String diaChi,
            @RequestParam String soDienThoai,
            @RequestParam Integer gioiTinh,
            @RequestParam String cccd,
            Model model) {
        String result = nhanVienService.addNhanVien(taiKhoan, matKhau, email, ten, diaChi, soDienThoai, gioiTinh,cccd);

        if ("success".equals(result)) {
            return "redirect:/nhanvien/list";
        } else {
            model.addAttribute("error", result);
            return "nhanvien/add";
        }
    }

    @GetMapping("/update/{id}")
    public String viewUpdate(@PathVariable("id") Integer id, Model model) {
        Optional<NhanVien> nhanVienOpt = nhanVienRepository.findById(id);
        if (!nhanVienOpt.isPresent()) {
            model.addAttribute("error", "Nhân viên không tồn tại!");
            return "nhanvien/index";
        }
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien1 = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien1);
        NhanVien nhanVien = nhanVienOpt.get();
        model.addAttribute("nhanVien", nhanVien);
        return "nhanvien/update";
    }

    @PostMapping("/update")
    public String update(@RequestParam Integer id,
                         @RequestParam String taiKhoan,
                         @RequestParam String matKhau,
                         @RequestParam String email,
                         @RequestParam String ten,
                         @RequestParam String diaChi,
                         @RequestParam String soDienThoai,
                         @RequestParam Integer gioiTinh,
                         @RequestParam String cccd,
                         @RequestParam Integer trangThai,
                         Model model) {

        String result = nhanVienService.updateNhanVien(id, taiKhoan, matKhau, email, ten, diaChi, soDienThoai, gioiTinh,cccd, trangThai);

        if ("success".equals(result)) {
            return "redirect:/nhanvien/list";
        } else {
            model.addAttribute("error", result);
            return "nhanvien/update";
        }
    }
}

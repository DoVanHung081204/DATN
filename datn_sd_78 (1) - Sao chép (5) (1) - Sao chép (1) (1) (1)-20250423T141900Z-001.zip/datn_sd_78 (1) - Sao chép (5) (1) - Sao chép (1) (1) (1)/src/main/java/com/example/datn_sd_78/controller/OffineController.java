package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.city.District;
import com.example.datn_sd_78.city.Province;
import com.example.datn_sd_78.city.Ward;
import com.example.datn_sd_78.entity.DiaChiVanChuyen;
import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.entity.HoaDonChiTiet;
import com.example.datn_sd_78.entity.Huyen;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.KhachHangVoucher;
import com.example.datn_sd_78.entity.MauSac;
import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.entity.Size;
import com.example.datn_sd_78.entity.Tinh;
import com.example.datn_sd_78.entity.Xa;
import com.example.datn_sd_78.repository.*;
import com.example.datn_sd_78.service.CartServices;
import com.example.datn_sd_78.service.GHNService;
import com.example.datn_sd_78.service.NhanVienService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/order")
public class OffineController {
    @Autowired
    ChiTietSanPhamRepository sanPhamChiTietRepo;
    @Autowired
    CartServices cartServices;
    @Autowired
    HoaDonRepository hoaDonRepo;
    @Autowired
    HoaDonChiTietRepository hoaDonChiTietRepo;
    @Autowired
    private KhachHangRepository khachHangRepository;
    @Autowired
    TrangThaiHoaDonRepo trangThaiHoaDonRepo;
    @Autowired
    private GHNService ghnService;
    @Autowired
    MauSacRepository mauSacRepository;
    @Autowired
    SizeRepository sizeRepository;
    @Autowired
    VoucherRepository voucherRepository;
    @Autowired
    KhachHangVoucherRepository khachHangVoucherRepository;
    @Autowired
    private NhanVienService nhanVienService;
    @Autowired
    private XaRepository xaRepository;

    @Autowired
    private HuyenRepository huyenRepository;

    @Autowired
    private TinhRepository tinhRepository;
    @Autowired
    private DiaChiVanChuyenRepository diaChiVanChuyenRepository;


    @GetMapping
    public String ShowCheckOutPage(Model model,
                                   HttpSession session,
                                   @RequestParam(required = false) String maGiamGia,
                                   @RequestParam(required = false) String keyword,  // Tìm kiếm sản phẩm
                                   @RequestParam(required = false) String KhachHangKeyWord, // Tìm kiếm khách hàng
                                   @RequestParam(required = false) Long colorId,
                                   @RequestParam(required = false) Long sizeId,
                                   @RequestParam(defaultValue = "0") int page,
                                   @RequestParam(defaultValue = "5") int size,
                                   Principal principal) {

        String username = principal.getName();
        if(username!=null){
            NhanVien nhanVien = nhanVienService.findByTaiKhoan(username);
        }

        // Lấy danh sách sản phẩm theo tìm kiếm, màu sắc, và kích thước
        Pageable pageable = PageRequest.of(page, size);
        Page<SanPhamChiTiet> lstSanPhamChiTiet;
        Page<KhachHang> lstKhachHang;
        List<Province> provice = ghnService.getProvinces();

        if ((keyword != null && !keyword.isEmpty()) || colorId != null || sizeId != null) {
            // Lọc sản phẩm theo từ khóa, màu sắc và kích thước
            lstSanPhamChiTiet = sanPhamChiTietRepo.filterSanPham(keyword, colorId, sizeId, pageable);
        } else {
            // Lấy tất cả sản phẩm nếu không có bộ lọc
            lstSanPhamChiTiet = sanPhamChiTietRepo.getDanhSach(pageable);
        }

        // Nếu có từ khóa tìm kiếm, gọi searchKhachHang, nếu không gọi findAll để lấy tất cả khách hàng
        if (KhachHangKeyWord != null && !KhachHangKeyWord.trim().isEmpty()) {
            lstKhachHang = khachHangRepository.searchKhachHang(KhachHangKeyWord, pageable);
        } else {
            lstKhachHang = khachHangRepository.findAll(pageable); // Nếu không có từ khóa, lấy tất cả khách hàng
        }

        // Lấy danh sách màu sắc và kích thước từ repository
        List<MauSac> lstMauSac = mauSacRepository.findAll();
        List<Size> lstSize = sizeRepository.findAll();

        // Lấy danh sách hóa đơn và khách hàng với phân trang
        List<HoaDon> lstHoaDon = hoaDonRepo.findAllHoaDon();


        // Thêm dữ liệu vào model
        model.addAttribute("provinces", provice);
        model.addAttribute("lstHoaDon", lstHoaDon);
        model.addAttribute("lstSanPham", lstSanPhamChiTiet.getContent());
        model.addAttribute("lstKhachHang", lstKhachHang.getContent());
        model.addAttribute("totalPagesSanPham", lstSanPhamChiTiet.getTotalPages()); // Phân trang cho sản phẩm
        model.addAttribute("currentPageSanPham", page);
        model.addAttribute("pageSizeSanPham", size);
        model.addAttribute("totalPagesKhachHang", lstKhachHang.getTotalPages()); // Phân trang cho khách hàng
        model.addAttribute("currentPageKhachHang", page);
        model.addAttribute("pageSizeKhachHang", size);
        model.addAttribute("keyword", keyword);  // Từ khóa cho sản phẩm
        model.addAttribute("KhachHangKeyWord", KhachHangKeyWord);  // Từ khóa cho khách hàng
        model.addAttribute("lstMauSac", lstMauSac);  // Thêm danh sách màu sắc vào model
        model.addAttribute("lstSize", lstSize);     // Thêm danh sách kích thước vào model

        return "offine/order"; // Chuyển về view order.jsp
    }


    @PostMapping("/taohoadon")
    public String taoHoaDon(HttpSession session,Principal principal) {
        Integer idHoaDon = cartServices.taoHoaDon(principal);
        session.setAttribute("idHoaDon", idHoaDon);
        return "redirect:/order/hoaDon/" + idHoaDon;
    }


    @GetMapping("/hoaDon/{id}")
    public String chonHoaDon(Model model,
                             @PathVariable Integer id,
                             HttpSession session,
                             @RequestParam(required = false) String maGiamGia,
                             @RequestParam(required = false) String keyword,  // Tìm kiếm sản phẩm
                             @RequestParam(required = false) String KhachHangKeyWord, // Tìm kiếm khách hàng
                             @RequestParam(required = false) Long colorId,
                             @RequestParam(required = false) Long sizeId,
                             @RequestParam(defaultValue = "0") int page,
                             @RequestParam(defaultValue = "5") int size,
                             Principal principal) {
        String username = principal.getName();
        if(username!=null){
            NhanVien nhanVien = nhanVienService.findByTaiKhoan(username);
        }

        // Lấy danh sách sản phẩm theo tìm kiếm, mà u sắc, và kích thước
        Pageable pageable = PageRequest.of(page, size);
        Page<SanPhamChiTiet> lstSanPhamChiTiet;
        Page<KhachHang> lstKhachHang;
        List<Province> provice = ghnService.getProvinces();

        if ((keyword != null && !keyword.isEmpty()) || colorId != null || sizeId != null) {
            // Lọc sản phẩm theo từ khóa, màu sắc và kích thước
            lstSanPhamChiTiet = sanPhamChiTietRepo.filterSanPham(keyword, colorId, sizeId, pageable);
        } else {
            // Lấy tất cả sản phẩm nếu không có bộ lọc
            lstSanPhamChiTiet = sanPhamChiTietRepo.getDanhSach(pageable);
        }

        // Nếu có từ khóa tìm kiếm, gọi searchKhachHang, nếu không gọi findAll để lấy tất cả khách hàng
        if (KhachHangKeyWord != null && !KhachHangKeyWord.trim().isEmpty()) {
            lstKhachHang = khachHangRepository.searchKhachHang(KhachHangKeyWord, pageable);
        } else {
            lstKhachHang = khachHangRepository.findAll(pageable); // Nếu không có từ khóa, lấy tất cả khách hàng
        }

        // Lấy danh sách màu sắc và kích thước từ repository
        List<MauSac> lstMauSac = mauSacRepository.findAll();
        List<Size> lstSize = sizeRepository.findAll();

        // Lấy danh sách hóa đơn và khách hàng với phân trang
        List<HoaDon> lstHoaDon = hoaDonRepo.findAllHoaDon();


        // Thêm dữ liệu vào model
        model.addAttribute("provinces", provice);
        model.addAttribute("lstHoaDon", lstHoaDon);
        model.addAttribute("lstSanPham", lstSanPhamChiTiet.getContent());
        model.addAttribute("lstKhachHang", lstKhachHang.getContent());
        model.addAttribute("totalPagesSanPham", lstSanPhamChiTiet.getTotalPages()); // Phân trang cho sản phẩm
        model.addAttribute("currentPageSanPham", page);
        model.addAttribute("pageSizeSanPham", size);
        model.addAttribute("totalPagesKhachHang", lstKhachHang.getTotalPages()); // Phân trang cho khách hàng
        model.addAttribute("currentPageKhachHang", page);
        model.addAttribute("pageSizeKhachHang", size);
        model.addAttribute("keyword", keyword);  // Từ khóa cho sản phẩm
        model.addAttribute("KhachHangKeyWord", KhachHangKeyWord);  // Từ khóa cho khách hàng
        model.addAttribute("lstMauSac", lstMauSac);  // Thêm danh sách màu sắc vào model
        model.addAttribute("lstSize", lstSize);     // Thêm danh sách kích thước vào model

        // Xử lý hóa đơn
        HoaDon hoaDon = hoaDonRepo.findById(id).orElse(null);
        if (hoaDon != null) {
            session.setAttribute("hoaDonId", hoaDon.getId());
            List<HoaDonChiTiet> lstHoaDonChiTiet = hoaDonChiTietRepo.lstHoaDonChiTiet(id);

            // Tính tổng tiền
            BigDecimal tongTien = cartServices.tinhTongTien(lstHoaDonChiTiet);

            // Truyền dữ liệu vào model
            model.addAttribute("lstHoaDonChiTiet", lstHoaDonChiTiet);
            model.addAttribute("hoaDon", hoaDon);
            model.addAttribute("tongTien", tongTien);

            // Kiểm tra xem có voucher đã áp dụng không
            if (hoaDon.getVoucher() != null) {
                BigDecimal giaTriGiam = hoaDon.getVoucher().getGiaTriGiam();
                BigDecimal giaTriDonHangToiThieu = hoaDon.getVoucher().getGiaTriDonHangToiThieu(); // Giá trị đơn hàng tối thiểu để áp dụng voucher

                // Kiểm tra xem tổng tiền có lớn hơn hoặc bằng giá trị tối thiểu của voucher không
                if (tongTien.compareTo(giaTriDonHangToiThieu) < 0) {
                    // Nếu tổng tiền không đủ điều kiện, xóa voucher khỏi hóa đơn
                    hoaDon.setVoucher(null);  // Xóa voucher khỏi hóa đơn
                    hoaDonRepo.save(hoaDon);  // Lưu lại hóa đơn sau khi xóa voucher

                    // Thông báo lỗi và không áp dụng voucher
                    model.addAttribute("errorMessage", "Tổng tiền đơn hàng không đủ điều kiện để áp dụng voucher!");
                    model.addAttribute("thanhTien", tongTien); // Hiển thị tổng tiền trước giảm giá
                } else {
                    // Nếu tổng tiền đủ điều kiện, tính lại thành tiền sau khi giảm giá
                    BigDecimal thanhTien = tongTien.subtract(giaTriGiam);
                    model.addAttribute("tienGiam", giaTriGiam);
                    model.addAttribute("thanhTien", thanhTien);
                }
            } else {
                model.addAttribute("thanhTien", tongTien); // Nếu không có voucher, chỉ hiển thị tổng tiền ban đầu
            }
        }

        // Lấy danh sách voucher của khách hàng với trạng thái
        if (hoaDon != null && hoaDon.getKhachHang() != null) {
            Integer idKhachHang = hoaDon.getKhachHang().getId();
            List<KhachHangVoucher> lstKhachHangVoucher = khachHangVoucherRepository.findByKhachHangIdOrderByTrangThai(idKhachHang);

            // Trả về danh sách KhachHangVoucher chứa thông tin trạng thái
            model.addAttribute("lstKhachHangVoucher", lstKhachHangVoucher);
            System.out.println(lstKhachHangVoucher);
        }

        return "offine/order"; // Chuyển về view order.jsp
    }


    @PostMapping("/themNhieuSanPham")
    public String addMultipleProductsToCart(@RequestParam("selectedProducts") List<Integer> selectedProducts,
                                            @RequestParam Map<String, String> allParams,
                                            HttpSession session) {
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");

        // Duyệt qua tất cả các sản phẩm được chọn
        for (Integer idCTSP : selectedProducts) {
            // Lấy số lượng từ các tham số (sử dụng key là quantity_{productId})
            String quantityParam = allParams.get("quantity_" + idCTSP);
            int quantity = Integer.parseInt(quantityParam != null ? quantityParam : "1"); // Mặc định là 1 nếu không có giá trị

            // Gọi service để thêm từng sản phẩm vào giỏ hàng
            try {
                cartServices.addProductToCart(idCTSP, idHoaDon, quantity);
            } catch (IllegalStateException e) {
                // Nếu có lỗi (ví dụ số lượng sản phẩm không đủ), thông báo lỗi
                session.setAttribute("error", e.getMessage());
                return "redirect:/order/hoaDon/" + idHoaDon;
            }
        }

        // Sau khi thêm tất cả sản phẩm, chuyển hướng đến trang giỏ hàng
        return "redirect:/order/hoaDon/" + idHoaDon;
    }


    @PostMapping("/themkhachhang/{idKhachHang}")
    public String addCustomerToBill(@PathVariable int idKhachHang, Model model, HttpSession session) {
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");
        cartServices.addCustomerToBill(idHoaDon, idKhachHang);
        return "redirect:/order/hoaDon/" + idHoaDon;
    }

    @PostMapping("/xoakhachhang")
    public String deleteCustomerFromBill(@RequestBody Map<String, Object> payload, HttpSession session, Model model) {
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");
        HoaDon hoaDon = hoaDonRepo.findById(idHoaDon).orElse(null);

        if (hoaDon != null) {
            // Lấy customerId từ payload, và chuyển đổi nếu cần
            Object customerIdObj = payload.get("customerId");
            Integer customerId = null;

            if (customerIdObj instanceof String) {
                customerId = Integer.parseInt((String) customerIdObj);  // Chuyển String thành Integer
            } else if (customerIdObj instanceof Integer) {
                customerId = (Integer) customerIdObj;
            }

            // Kiểm tra xem khách hàng có tồn tại trong hóa đơn không
            if (hoaDon.getKhachHang() != null && hoaDon.getKhachHang().getId().equals(customerId)) {
                hoaDon.setKhachHang(null);  // Xóa khách hàng khỏi hóa đơn
                hoaDonRepo.save(hoaDon);  // Lưu lại hóa đơn
            } else {
                model.addAttribute("errorMessage", "Khách hàng không tồn tại trong hóa đơn.");
                return "redirect:/order/hoaDon/" + idHoaDon;
            }
        }

        return "redirect:/order/hoaDon/" + idHoaDon;
    }



    @PostMapping("/themvoucher/{idVoucher}")
    public String addVoucherToBill(@PathVariable int idVoucher, Model model, HttpSession session) {
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");
        cartServices.addVoucherToBill(idHoaDon, idVoucher);
        return "redirect:/order/hoaDon/" + idHoaDon;
    }

    @PostMapping("/xoavoucher")
    public String deleteVoucherFromBill(@RequestBody Map<String, Object> payload, HttpSession session) {
        // Lấy id hoaDon từ session
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");
        HoaDon hoaDon = hoaDonRepo.findById(idHoaDon).orElse(null);

        // Kiểm tra xem hóa đơn có tồn tại hay không
        if (hoaDon != null) {
            // Lấy voucherId từ payload và chuyển đổi nếu cần
            Object voucherIdObj = payload.get("voucherId");
            Integer voucherId = null;

            // Kiểm tra kiểu dữ liệu voucherId trong payload và chuyển đổi
            if (voucherIdObj instanceof String) {
                voucherId = Integer.parseInt((String) voucherIdObj);  // Chuyển từ String sang Integer
            } else if (voucherIdObj instanceof Integer) {
                voucherId = (Integer) voucherIdObj;  // Nếu là Integer rồi, lấy trực tiếp
            }

            // Nếu voucherId hợp lệ, xóa voucher khỏi hóa đơn
            if (voucherId != null && hoaDon.getVoucher() != null && hoaDon.getVoucher().getId().equals(voucherId)) {
                hoaDon.setVoucher(null);  // Xóa voucher khỏi hóa đơn
                hoaDonRepo.save(hoaDon);  // Lưu hóa đơn
            } else {
                // Nếu không có voucher hợp lệ, có thể thêm thông báo lỗi hoặc hành động khác
                // Ví dụ: gửi thông báo lỗi vào model (tuỳ thuộc vào nhu cầu của bạn)
                // model.addAttribute("errorMessage", "Voucher không tồn tại hoặc không hợp lệ!");
            }
        }

        // Redirect lại trang chi tiết hóa đơn
        return "redirect:/order/hoaDon/" + idHoaDon;
    }



    @PostMapping("/hoaDon/{id}/thanhToan")
    public String thanhToan(Model model, @PathVariable Integer id, @RequestParam String hoTen,
                            @RequestParam Boolean hinhThucNhanHang, @RequestParam String diaChi,
                            @RequestParam String sdt, @RequestParam BigDecimal thanhTien,
                            @RequestParam BigDecimal phiShip, @RequestParam(required = false) BigDecimal tienGiam,
                            @RequestParam BigDecimal tienHang,@RequestParam(required = false) Integer tinhThanh,
                            @RequestParam(required = false) Integer quanHuyen,
                            @RequestParam(required = false) Integer phuongXa,
                            HttpSession session) {

        HoaDon hoaDon = hoaDonRepo.findById(id).orElse(null);
        DiaChiVanChuyen diaChiVanChuyen = null;
        if (hoaDon != null) {
            // Cập nhật thông tin hóa đơn
            hoaDon.setHoTen(hoTen);
            hoaDon.setDiaChi(diaChi);
            hoaDon.setSdt(sdt);
            hoaDon.setTienShip(phiShip);
            hoaDon.setTienGiam(tienGiam);
            hoaDon.setTongTien(thanhTien);
            hoaDon.setTienHang(tienHang);
            hoaDon.setLoaiHoaDon(false);
//            hoaDon.setNhanVien();

            // Xử lý ngày nhận và ngày thanh toán
            if (hinhThucNhanHang) {
                hoaDon.setNgayNhanHang(hoaDon.getNgayTao());
                hoaDon.setNgayThanhToan(hoaDon.getNgayTao());
                hoaDon.setTrangThai(trangThaiHoaDonRepo.findById(7).orElse(null));
                hoaDon.setHinhThucNhanHang(true);
            } else {
                hoaDon.setNgayNhanHang(null);
                hoaDon.setNgayThanhToan(null);
                hoaDon.setTrangThai(trangThaiHoaDonRepo.findById(1).orElse(null));
                hoaDon.setHinhThucNhanHang(false);
                hoaDon.setNgayThanhToan(hoaDon.getNgayTao());
                //Lấy danh sách tỉnh thành từ API
                List<Province> provinces = ghnService.getProvinces();
                Province province = provinces.stream().filter(p -> p.getId() == tinhThanh).findFirst().orElse(null);
                if (province != null) {
                    Tinh tinh = tinhRepository.findById(tinhThanh).orElse(null);
                    if (tinh == null) {
                        tinh = new Tinh();
                        tinh.setMaTinh(String.valueOf(province.getId()));
                        tinh.setTenTinh(province.getName()); // Lấy tên tỉnh từ API
                        tinh.setNgayTao(new Date());
                        tinh.setNgayCapNhat(new Date());
                        tinhRepository.save(tinh);
                    }

                    // Lấy danh sách quận huyện của tỉnh
                    List<District> districts = ghnService.getDistricts(tinhThanh);
                    District district = districts.stream().filter(d -> d.getId() == quanHuyen).findFirst().orElse(null);
                    if (district != null) {
                        Huyen huyen = huyenRepository.findById(quanHuyen).orElse(null);
                        if (huyen == null) {
                            huyen = new Huyen();
                            huyen.setTenHuyen(district.getName()); // Lấy tên huyện từ API
                            huyen.setTinh(tinh); // Liên kết với tỉnh
                            huyen.setNgayTao(new Date());
                            huyen.setNgayCapNhat(new Date());
                            huyenRepository.save(huyen);
                        }

                        // Lấy danh sách phường xã của quận
                        List<Ward> wards = ghnService.getWards(quanHuyen);
                        Ward ward = wards.stream()
                                .filter(w -> w.getCode().equals(String.valueOf(phuongXa))) // Convert phuongXa to String
                                .findFirst()
                                .orElse(null);
                        if (ward != null) {
                            Xa xa = xaRepository.findById(phuongXa).orElse(null);
                            if (xa == null) {
                                xa = new Xa();
                                xa.setTenXa(ward.getName()); // Lấy tên xã từ API
                                xa.setHuyen(huyen); // Liên kết với huyện
                                xa.setNgayTao(new Date());
                                xa.setNgayCapNhat(new Date());
                                xaRepository.save(xa);
                            }

                            String address1 = diaChi + ", " + ward.getName() + ", " + district.getName() + ", " + province.getName();

                            diaChiVanChuyen = new DiaChiVanChuyen();
                            diaChiVanChuyen.setDiaChiCuThe(address1);
                            diaChiVanChuyen.setNgayTao(new Date());
                            diaChiVanChuyen.setNgayCapNhat(new Date());
                            diaChiVanChuyen.setTrangThai(true); // Có thể tùy chỉnh trạng thái
                            diaChiVanChuyen.setTinh(tinh);
                            diaChiVanChuyen.setHuyen(huyen);
                            diaChiVanChuyen.setXa(xa);
                            diaChiVanChuyen.setKhachHang(hoaDon.getKhachHang());
                            diaChiVanChuyenRepository.save(diaChiVanChuyen);
                        }
                    }
                }
                hoaDon.setDiaChiVanChuyen(diaChiVanChuyen.getIdDiaChiVanChuyen());
            }


            // Cập nhật trạng thái voucher thành 1 (đã sử dụng) sau khi thanh toán
            if (hoaDon.getVoucher() != null) {
                KhachHangVoucher khachHangVoucher = khachHangVoucherRepository.findByKhachHangAndVoucher(
                        hoaDon.getKhachHang(), hoaDon.getVoucher());
                if (khachHangVoucher != null) {
                    // Cập nhật trạng thái voucher thành 1 (đã sử dụng)
                    khachHangVoucher.setTrangThai(1);
                    khachHangVoucherRepository.save(khachHangVoucher); // Lưu lại sự thay đổi
                }
            }

            hoaDonRepo.save(hoaDon);

            // Thêm thông tin vào model để hiển thị lại
            model.addAttribute("hoaDon", hoaDon);
            model.addAttribute("message", "Hóa đơn đã được thanh toán thành công!");

            // Xóa hoaDonId khỏi session
            session.removeAttribute("hoaDonId");

            return "redirect:/order";
        }

        return "redirect:/order";
    }


    @PostMapping("/xoahoadonchitiet/{id}")
    public String xoaHoaDonChiTiet(@PathVariable Integer id, HttpSession session) {
        Integer idHoaDon = (Integer) session.getAttribute("hoaDonId");

        // Lấy đối tượng HoaDonChiTiet từ database
        HoaDonChiTiet hoaDonChiTiet = hoaDonChiTietRepo.findById(id).orElse(null);

        if (hoaDonChiTiet != null) {
            // Trước khi xóa, lưu lại thông tin sản phẩm
            SanPhamChiTiet sanPhamChiTiet = hoaDonChiTiet.getChiTietSanPham();
            Integer soLuongXoa = hoaDonChiTiet.getSoLuong();

            // Xóa chi tiết hóa đơn
            hoaDonChiTietRepo.delete(hoaDonChiTiet);

            // Sau khi xóa, thêm lại sản phẩm vào cơ sở dữ liệu (tăng số lượng sản phẩm)
            sanPhamChiTiet.setSoLuong(sanPhamChiTiet.getSoLuong() + soLuongXoa);
            sanPhamChiTietRepo.save(sanPhamChiTiet); // Lưu lại thông tin sản phẩm đã cập nhật số lượng
        }

        // Sau khi xóa xong, chuyển hướng lại về trang chi tiết hóa đơn
        return "redirect:/order/hoaDon/" + idHoaDon;
    }


}

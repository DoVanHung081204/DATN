package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.city.Province;
import com.example.datn_sd_78.entity.CtspKhuyenMai;
import com.example.datn_sd_78.entity.GioHangChiTiet;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.KhachHangVoucher;
import com.example.datn_sd_78.entity.MauSac;
import com.example.datn_sd_78.entity.SanPham;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.entity.Size;
import com.example.datn_sd_78.entity.Voucher;
import com.example.datn_sd_78.reponse.ResponseDTO;
import com.example.datn_sd_78.repository.ChiTietSanPhamRepository;
import com.example.datn_sd_78.repository.CtspKhuyenMaiRepository;
import com.example.datn_sd_78.repository.KhachHangVoucherRepository;
import com.example.datn_sd_78.repository.SanPhamRepository;
import com.example.datn_sd_78.repository.UserRepository;
import com.example.datn_sd_78.repository.VoucherRepository;
import com.example.datn_sd_78.request.RequestDTO;
import com.example.datn_sd_78.service.GHNService;
import com.example.datn_sd_78.service.GioHangService;
import com.example.datn_sd_78.service.KhachHangService;
import com.example.datn_sd_78.service.MauSacService;
import com.example.datn_sd_78.service.SanPhamService;
import com.example.datn_sd_78.service.SizeService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.math.BigDecimal;
import java.security.Principal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

@Controller
@RequestMapping("/online")
public class OnlineController {
    @Autowired
    private SanPhamRepository sanPhamRepository;

    @Autowired
    ChiTietSanPhamRepository chiTietSanPhamRepository;

    @Autowired
    private GioHangService gioHangService;
    @Autowired
    private CtspKhuyenMaiRepository ctspKhuyenMaiRepository;

    @Autowired
    private SanPhamService sanPhamService;

    @Autowired
    private MauSacService mauSacService;

    @Autowired
    private SizeService sizeService;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private KhachHangService khachHangService;

    @Autowired
    private GHNService ghnService;

    @Autowired
    private VoucherRepository voucherRepository;

//    @Autowired
//    VoucherRepository voucherRepository;
    @Autowired
    KhachHangVoucherRepository khachHangVoucherRepository;

    @GetMapping("/menu")
    public String showProductManagement() {
        return "menu";
    }

    @GetMapping("/user")
    public String showUser() {
        return "online/user";
    }

    @GetMapping("/product")
    public String getSanPham(Model model) {
        Pageable pageable = PageRequest.of(0, 20);
        List<SanPham> sanPhams = sanPhamRepository.findTop20Newest(pageable);
        List<GioHangChiTiet> gioHangItems = gioHangService.getItems();

        sanPhams.forEach(sanPham -> {
            BigDecimal giaGoc = sanPham.getGiaBan();
            BigDecimal giaSauKhiGiam = giaGoc;
            CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(sanPham.getId());
            if (khuyenMai != null) {
                if (khuyenMai.getLoaiGiamGia()) {
                    giaSauKhiGiam = giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                } else {
                    giaSauKhiGiam = giaGoc.subtract(khuyenMai.getMucGiam());
                }
            }
            sanPham.setGiaGoc(giaGoc.setScale(0, BigDecimal.ROUND_HALF_UP));
            sanPham.setGiaSauKhiGiam(giaSauKhiGiam.setScale(0, BigDecimal.ROUND_HALF_UP));
        });

        model.addAttribute("giohang", gioHangItems);
        model.addAttribute("sanphams", sanPhams);
        return "online/trangChu";
    }

    @GetMapping("/shop")
    public String getSanPham1(Model model,
                              @RequestParam(defaultValue="") String keyword,
                              @RequestParam(required = false) Integer color,
                              @RequestParam(required = false) Integer size,
                              @RequestParam(required = false) Double minPrice,
                              @RequestParam(required = false) Double maxPrice,
                              @RequestParam(defaultValue = "0") int page) { // Default page is 0

        Pageable pageable = PageRequest.of(page, 6); // Page 0 and size 8 per page
        Page<SanPham> sanPhamPage;

        // Check if price filter is valid
        if (minPrice != null && maxPrice != null && minPrice > maxPrice) {
            model.addAttribute("error", "Giá tối thiểu không được lớn hơn giá tối đa.");
            sanPhamPage = Page.empty();
        } else {
            // Filter products based on parameters
            if (keyword.isEmpty() && color == null && size == null && minPrice == null && maxPrice == null) {
                sanPhamPage = sanPhamRepository.findAll(pageable);
            } else {
                sanPhamPage = sanPhamRepository.filterProducts(keyword, color, size, minPrice, maxPrice, pageable);
            }
        }

        if (sanPhamPage.isEmpty()) {
            model.addAttribute("error", "Không có sản phẩm nào phù hợp với tiêu chí tìm kiếm.");
        }

        // Calculate discount for each product
        for (SanPham sanPham : sanPhamPage.getContent()) {
            BigDecimal giaGoc = sanPham.getGiaBan();
            BigDecimal giaSauKhiGiam = giaGoc;

            CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(sanPham.getId());
            if (khuyenMai != null) {
                if (khuyenMai.getLoaiGiamGia()) {
                    giaSauKhiGiam = giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                } else {
                    giaSauKhiGiam = giaGoc.subtract(khuyenMai.getMucGiam());
                }
            }

            if (giaSauKhiGiam == null) {
                giaSauKhiGiam = giaGoc;
            }

            sanPham.setGiaSauKhiGiam(giaSauKhiGiam);
        }

        // Add data to model
        model.addAttribute("sanphams", sanPhamPage.getContent());
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", sanPhamPage.getTotalPages());

        // Get filter options (colors and sizes)
        List<MauSac> colors = mauSacService.getAllColors();
        List<Size> sizes = sizeService.getAllSizes();
        model.addAttribute("colors", colors);
        model.addAttribute("sizes", sizes);

        return "online/sanPham";
    }

    @GetMapping("/detail/{id}")
    public String getProductDetail(@PathVariable Integer id, Model model, Principal principal) {
        // Kiểm tra xem người dùng đã đăng nhập chưa
        if (principal == null) {
            // Nếu chưa đăng nhập, chuyển hướng tới trang đăng nhập
            return "redirect:/login";
        }

        // Nếu đã đăng nhập, tiếp tục xử lý chi tiết sản phẩm
        Optional<SanPham> sanPhamOptional = sanPhamRepository.findById(id);

        if (sanPhamOptional.isPresent()) {
            SanPham sanPham = sanPhamOptional.get();

            // Lấy giá gốc từ giá bán
            BigDecimal giaGoc = sanPham.getGiaBan();
            BigDecimal giaSauKhiGiam = giaGoc;  // Mặc định giá giảm là giá gốc

            // Kiểm tra nếu có khuyến mãi
            CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(sanPham.getId());

            if (khuyenMai != null) {
                // Nếu có khuyến mãi, tính giá sau khi giảm
                if (khuyenMai.getLoaiGiamGia()) {
                    giaSauKhiGiam = giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                } else {
                    giaSauKhiGiam = giaGoc.subtract(khuyenMai.getMucGiam());
                }
            }

            // Lấy danh sách chi tiết sản phẩm
            List<SanPhamChiTiet> variants = chiTietSanPhamRepository.findBySanPhamId(sanPham.getId());

            // Kiểm tra sản phẩm có các biến thể hay không
            if (variants.isEmpty()) {
                model.addAttribute("outOfStock", true); // Đánh dấu sản phẩm hết hàng
            } else {
                model.addAttribute("outOfStock", false);
            }

            // Truyền thông tin sản phẩm và giá sau khi giảm
            model.addAttribute("product", sanPham);
            model.addAttribute("giaSauKhiGiam", giaSauKhiGiam);
            model.addAttribute("variants", variants);
        } else {
            return "redirect:/";
        }

        return "online/detail_user";
    }

    @GetMapping("/giohang")
    public String showGioHang(Model model) {
        List<GioHangChiTiet> gioHangItems = gioHangService.getItems();

        gioHangItems.forEach(item -> {
            BigDecimal giaGoc = item.getChiTietSanPham().getSanPham().getGiaBan();
            BigDecimal giaSauKhiGiam = giaGoc;

            // Tìm khuyến mãi áp dụng cho sản phẩm
            CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(item.getChiTietSanPham().getSanPham().getId());
            if (khuyenMai != null) {
                if (khuyenMai.getLoaiGiamGia()) {
                    giaSauKhiGiam = giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                } else {
                    giaSauKhiGiam = giaGoc.subtract(khuyenMai.getMucGiam());
                }
            }

            // Gán giá trị đã giảm vào sản phẩm trong giỏ hàng
            item.getChiTietSanPham().getSanPham().setGiaGoc(giaGoc.setScale(0, BigDecimal.ROUND_HALF_UP));
            item.getChiTietSanPham().getSanPham().setGiaSauKhiGiam(giaSauKhiGiam.setScale(0, BigDecimal.ROUND_HALF_UP));
        });



        // Tính tổng giá trị giỏ hàng với giá giảm
        int tongGiaTri = gioHangItems.stream()
                .mapToInt(item -> item.getChiTietSanPham().getSanPham().getGiaSauKhiGiam()
                        .multiply(BigDecimal.valueOf(item.getSoLuong()))
                        .intValue())
                .sum();

        model.addAttribute("giohang", gioHangItems);
        model.addAttribute("tongGiaTri", tongGiaTri);
        model.addAttribute("phiShip", 0);
        return "online/giohang";
    }



    @RequestMapping("/check")
    public String trangChu1(Model model, Principal principal) {
        KhachHang currentUser = null;
        Integer idKhachHang = null;

        // Lấy thông tin khách hàng hiện tại nếu đã đăng nhập
        if (principal != null) {
            String username = principal.getName();
            currentUser = khachHangService.findByTaiKhoan(username);

            // Nếu khách hàng tồn tại, lấy ID của họ
            if (currentUser != null) {
                idKhachHang = currentUser.getId();
            }
        }

        // Thêm thông tin khách hàng vào model
        model.addAttribute("currentUser", currentUser);

        // Lấy danh sách voucher của khách hàng từ KhachHangVoucher repository
        List<KhachHangVoucher> lstKhachHangVoucher = new ArrayList<>();
        if (idKhachHang != null) {
            lstKhachHangVoucher = khachHangVoucherRepository.findByKhachHangIdOrderByTrangThai(idKhachHang);
        }

        // Thêm danh sách voucher vào model
        model.addAttribute("lstKhachHangVoucher", lstKhachHangVoucher);

        // Lấy thông tin giỏ hàng
        List<GioHangChiTiet> gioHangItems = gioHangService.getItems();

        // Tính toán giá giảm cho từng sản phẩm trong giỏ hàng
        gioHangItems.forEach(item -> {
            BigDecimal giaGoc = item.getChiTietSanPham().getSanPham().getGiaBan();
            BigDecimal giaSauKhiGiam = giaGoc;

            // Tìm khuyến mãi áp dụng cho sản phẩm
            CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(item.getChiTietSanPham().getSanPham().getId());
            if (khuyenMai != null) {
                if (khuyenMai.getLoaiGiamGia()) {
                    giaSauKhiGiam = giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                } else {
                    giaSauKhiGiam = giaGoc.subtract(khuyenMai.getMucGiam());
                }
            }

            // Cập nhật giá giảm vào sản phẩm trong giỏ hàng
            item.getChiTietSanPham().getSanPham().setGiaSauKhiGiam(giaSauKhiGiam.setScale(0, BigDecimal.ROUND_HALF_UP));
        });

        int tongGiaTri = gioHangItems.stream()
                .mapToInt(item -> item.getChiTietSanPham().getSanPham().getGiaSauKhiGiam()
                        .multiply(BigDecimal.valueOf(item.getSoLuong()))
                        .intValue())
                .sum();


        // Lấy danh sách các tỉnh từ dịch vụ giao hàng
        List<Province> provinces = ghnService.getProvinces();

        // Thêm các thông tin vào model để hiển thị trong view
        model.addAttribute("tongGiaTri", tongGiaTri);
        model.addAttribute("giohang", gioHangItems);
        model.addAttribute("phiShip", 0);
        model.addAttribute("provinces", provinces);

        return "online/checkout";
    }



    @PostMapping("/themvoucher/{idVoucher}")
    public ResponseEntity<?> applyVoucher(@PathVariable("idVoucher") Integer idVoucher, @RequestParam("tongTien") double tongTien) {
        Voucher voucher = voucherRepository.findById(idVoucher).orElse(null);
        Map<String, Object> response = new HashMap<>();

        if (voucher == null) {
            response.put("success", false);
            response.put("message", "Voucher not found.");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        // Convert BigDecimal to double
        double giaTriDonHangToiThieu = voucher.getGiaTriDonHangToiThieu().doubleValue();
        double giaTriGiam = voucher.getGiaTriGiam().doubleValue();
        int trangThai = voucher.getTrangThai();
        int voucherId = voucher.getId();

        // Check if the total amount is less than the minimum order value
        if (tongTien < giaTriDonHangToiThieu) {
            response.put("success", false);
            response.put("message", "Giá trị đơn hàng tối thiểu lớn hơn giá trị đơn hàng không thể áp dụng!!!");
            return ResponseEntity.ok(response);  // Return error response
        }

        response.put("success", true);
        response.put("trangthai",trangThai);
        response.put("voucherId",voucherId);
        response.put("giaTriGiam", giaTriGiam); // Discount value
        response.put("giaTriDonHangToiThieu", giaTriDonHangToiThieu); // Minimum order value

        return ResponseEntity.ok(response);
    }




    @PostMapping("/remove-voucher")
    @ResponseBody
    public ResponseEntity<String> removeVoucher(HttpSession session) {
        // Xóa giá trị voucher khỏi session hoặc xử lý theo logic lưu trữ của bạn
        session.removeAttribute("voucher");

        // Trả về phản hồi thành công
        return null;
    }

    @RequestMapping(value = "/add-gio-hang/{id}", method = RequestMethod.POST)
    public String addGioHang(@PathVariable int id,
                             @RequestParam("soLuong") int soLuong,
                             @RequestParam("selectedSize") String sizeId,
                             @RequestParam("selectedColor") String colorId,
                             RedirectAttributes redirectAttributes) {
        try {
            SanPhamChiTiet sanPhamChiTiet = sanPhamService.findVariantByColorAndSize(id, colorId, sizeId);
            if (sanPhamChiTiet == null || sanPhamChiTiet.getSoLuong() < soLuong) {
                redirectAttributes.addFlashAttribute("errorMessage", "Số lượng trong kho không đủ.");
                return "redirect:/online/product";
            }

            gioHangService.add(id, soLuong, colorId, sizeId);
            redirectAttributes.addFlashAttribute("message", "Đã thêm vào giỏ hàng!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
            return "redirect:/online/product";
        }
        return "redirect:/online/product";
    }



    @RequestMapping("/delete/{id}")
    public String xoaGioHang(@PathVariable int id,
                             @RequestParam("selectedSize") String sizeId,
                             @RequestParam("selectedColor") String colorId) {
        gioHangService.remove(id, sizeId, colorId);  // Call the service method with the parameters
        List<GioHangChiTiet> items = gioHangService.getItems();

        if (items == null || items.isEmpty()) {
            return "redirect:/online/product";
        } else {
            return "redirect:/online/giohang";
        }
    }


    @PostMapping("/update/{id}")
    public String updateGioHang(@PathVariable int id,
                                @RequestParam("soLuong") Integer soLuong,
                                @RequestParam("selectedColor") String selectedColor,
                                @RequestParam("selectedSize") String selectedSize,
                                RedirectAttributes redirectAttributes) {
        try {
            // Kiểm tra số lượng có hợp lệ không
            if (soLuong == null || soLuong <= 0) {
                redirectAttributes.addFlashAttribute("errorMessage", "Số lượng phải là số dương.");
                return "redirect:/online/giohang";
            }

            GioHangChiTiet gioHangChiTiet = gioHangService.getItems()
                    .stream()
                    .filter(gh -> gh.getChiTietSanPham().getSanPham().getId() == id
                            && gh.getChiTietSanPham().getMauSac().getTen().equals(selectedColor)
                            && gh.getChiTietSanPham().getSize().getTen().equals(selectedSize))
                    .findFirst()
                    .orElse(null);

            if (gioHangChiTiet != null) {
                SanPhamChiTiet sanPhamChiTiet = gioHangChiTiet.getChiTietSanPham();
                if (sanPhamChiTiet.getSoLuong() < soLuong) {
                    redirectAttributes.addFlashAttribute("errorMessage", "Số lượng yêu cầu vượt quá tồn kho.");
                    return "redirect:/online/giohang";
                }
                gioHangService.update(gioHangChiTiet, soLuong);
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Sản phẩm chi tiết không tồn tại trong giỏ hàng.");
            }
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("errorMessage", e.getMessage());
        }
        return "redirect:/online/giohang";
    }



    private final String token = "f7a6a8d9-a552-11ef-a89d-dab02cbaab48";
    @PostMapping("/ship")
    public ResponseDTO eship(@RequestBody ResponseDTO responseDTO1){
        String url = "https://online-gateway.ghn.vn/shiip/public-api/v2/shipping-order/fee";
        RequestDTO requestDTO = new RequestDTO();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Token", token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<RequestDTO> entity = new HttpEntity<>(requestDTO, headers);
        System.out.println("entity: "+entity);
        ResponseEntity<ResponseDTO> response = restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                ResponseDTO.class
        );
        System.out.println("check get fee API: "+response.getBody().getData());
        return response.getBody();
    }


}

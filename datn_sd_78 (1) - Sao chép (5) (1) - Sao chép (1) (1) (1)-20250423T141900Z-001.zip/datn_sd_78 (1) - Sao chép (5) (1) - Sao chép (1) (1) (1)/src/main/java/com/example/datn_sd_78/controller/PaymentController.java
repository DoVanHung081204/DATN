package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.city.District;
import com.example.datn_sd_78.city.Province;
import com.example.datn_sd_78.city.Ward;
import com.example.datn_sd_78.config.Config;
import com.example.datn_sd_78.entity.*;
import com.example.datn_sd_78.repository.*;
import com.example.datn_sd_78.service.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.security.Principal;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.util.*;

@RestController
@RequestMapping("/api/payment")
public class PaymentController {

    @Autowired
    private HoaDonServices hoaDonService;

    @Autowired
    GioHangService gioHangService;

    @Autowired
    private TrangThaiHoaDonRepo trangThaiHoaDonRepo;

    @Autowired
    private KhachHangService khachHangService;

    @Autowired
    private ChiTietHoaDonService chiTietHoaDonService;

    @Autowired
    private ChiTietSanPhamService chiTietSanPhamService;

    @Autowired
    private GHNService ghnService;

    @Autowired
    private XaRepository xaRepository;

    @Autowired
    private HuyenRepository huyenRepository;

    @Autowired
    private TinhRepository tinhRepository;

    @Autowired
    private DiaChiVanChuyenRepository diaChiVanChuyenRepository;

    @Autowired
    KhachHangVoucherRepository khachHangVoucherRepository;

    @Autowired
    VoucherRepository voucherRepository;


//    @Autowired
//    private EmailService emailService;

    @PostMapping("/creat_payment")
    public void createPayment(@RequestParam String name,
                              @RequestParam String email,
                              @RequestParam String address,
                              @RequestParam String phone,
                              @RequestParam(required = false) String note,
                              @RequestParam(required = false, defaultValue = "0") long amount,
                              @RequestParam String paymentMethod,
                              @RequestParam("tinhThanh") Integer tinhThanh,
                              @RequestParam("quanHuyen") Integer quanHuyen,
                              @RequestParam("phuongXa") Integer phuongXa,
                              @RequestParam BigDecimal phiShipHidden,
                              @RequestParam(name = "voucherId", required = false) Integer voucherId,
                              @RequestParam(required = false, defaultValue = "0") long originalTotalAmount,
                              HttpServletRequest req, HttpServletResponse response, Principal principal) throws IOException {

        // Kiểm tra khách hàng đăng nhập
        KhachHang khachHang = null;
        if (principal == null) {
            // Nếu khách hàng chưa đăng nhập, yêu cầu đăng nhập
            response.sendRedirect("/login"); // Chuyển hướng tới trang đăng nhập
            return;
        }

        // Nếu đã đăng nhập, lấy thông tin khách hàng
        String username = principal.getName();
        khachHang = khachHangService.findByTaiKhoan(username);

        // Sử dụng thông tin từ tài khoản nếu có
        if (khachHang != null) {
            // Sử dụng tên từ ô nhập nếu có
            if (name == null || name.isEmpty()) {
                name = khachHang.getHoTen();
            }
            if (email == null || email.isEmpty()) {
                email = khachHang.getUser().getEmail();
            }
            if (address == null || address.isEmpty()) {
                address = khachHang.getDiaChi();
            }
            if (phone == null || phone.isEmpty()) {
                phone = khachHang.getSdt();
            }
        }


        DiaChiVanChuyen diaChiVanChuyen = null;

        //         Lấy danh sách tỉnh thành từ API
        List<Province> provinces = ghnService.getProvinces();
        Province province = provinces.stream().filter(p -> p.getId() == tinhThanh).findFirst().orElse(null);
        if (province != null) {
            Tinh tinh = tinhRepository.findById(tinhThanh).orElse(null);
            if (tinh == null) {
                tinh = new Tinh();
                tinh.setMaTinh(String.valueOf(province.getId()));
                tinh.setTenTinh(province.getName()); // Lấy tên tỉnh từ API
                tinh.setNgayTao(new Date());
                tinh.setNgayCapNhat(new Date());
                tinhRepository.save(tinh);
            }

            // Lấy danh sách quận huyện của tỉnh
            List<District> districts = ghnService.getDistricts(tinhThanh);
            District district = districts.stream().filter(d -> d.getId() == quanHuyen).findFirst().orElse(null);
            if (district != null) {
                Huyen huyen = huyenRepository.findById(quanHuyen).orElse(null);
                if (huyen == null) {
                    huyen = new Huyen();
                    huyen.setTenHuyen(district.getName()); // Lấy tên huyện từ API
                    huyen.setTinh(tinh); // Liên kết với tỉnh
                    huyen.setNgayTao(new Date());
                    huyen.setNgayCapNhat(new Date());
                    huyenRepository.save(huyen);
                }

                // Lấy danh sách phường xã của quận
                List<Ward> wards = ghnService.getWards(quanHuyen);
                Ward ward = wards.stream()
                        .filter(w -> w.getCode().equals(String.valueOf(phuongXa))) // Convert phuongXa to String
                        .findFirst()
                        .orElse(null);
                if (ward != null) {
                    Xa xa = xaRepository.findById(phuongXa).orElse(null);
                    if (xa == null) {
                        xa = new Xa();
                        xa.setTenXa(ward.getName()); // Lấy tên xã từ API
                        xa.setHuyen(huyen); // Liên kết với huyện
                        xa.setNgayTao(new Date());
                        xa.setNgayCapNhat(new Date());
                        xaRepository.save(xa);
                    }

                    String address1 = address + ", " + ward.getName() + ", " + district.getName() + ", " + province.getName();

                    diaChiVanChuyen = new DiaChiVanChuyen();
                    diaChiVanChuyen.setDiaChiCuThe(address1);
                    diaChiVanChuyen.setNgayTao(new Date());
                    diaChiVanChuyen.setNgayCapNhat(new Date());
                    diaChiVanChuyen.setTrangThai(true); // Có thể tùy chỉnh trạng thái
                    diaChiVanChuyen.setMoTa(note);
                    diaChiVanChuyen.setTinh(tinh);
                    diaChiVanChuyen.setHuyen(huyen);
                    diaChiVanChuyen.setXa(xa);
                    diaChiVanChuyen.setKhachHang(khachHang);
                    diaChiVanChuyenRepository.save(diaChiVanChuyen);
                }
            }
        }


        // 1. Tạo hóa đơn mới
        HoaDon hoaDon = new HoaDon();
        hoaDon.setDiaChi(address);
        hoaDon.setHoTen(name);
        hoaDon.setSdt(phone);
        hoaDon.setNgayTao(LocalDateTime.now());
        hoaDon.setTongTien(BigDecimal.valueOf(amount));
        hoaDon.setNgayThanhToan(hoaDon.getNgayTao());
        hoaDon.setKhachHang(khachHang);
        hoaDon.setLoaiHoaDon(true);
        hoaDon.setTienShip(phiShipHidden);
        hoaDon.setDiaChiVanChuyen(diaChiVanChuyen.getIdDiaChiVanChuyen());
        Voucher voucher = voucherId != null ? voucherRepository.findById(voucherId).orElse(null) : null;
        hoaDon.setVoucher(voucher);
        hoaDon.setTienGiam(voucher != null ? voucher.getGiaTriGiam() : BigDecimal.ZERO);
        hoaDon.setTienHang(BigDecimal.valueOf(originalTotalAmount));


        // Cập nhật trạng thái voucher thành 1 (đã sử dụng) sau khi thanh toán
        if (voucherId != null) {
            voucher = voucherRepository.findById(voucherId).orElse(null);
            if (voucher != null) {
                hoaDon.setVoucher(voucher);
                hoaDon.setTienGiam(voucher.getGiaTriGiam());

                KhachHangVoucher khachHangVoucher = khachHangVoucherRepository.findByKhachHangAndVoucher(khachHang, voucher);
                if (khachHangVoucher != null) {
                    khachHangVoucher.setTrangThai(1); // Đã sử dụng
                    khachHangVoucherRepository.save(khachHangVoucher);
                }
            }
        } else {
            hoaDon.setTienGiam(BigDecimal.ZERO); // Không có giảm giá nếu không có voucher
        }



        // 2. Xác định trạng thái thanh toán
        TrangThaiHoaDon trangThai = null;
        if ("online".equals(paymentMethod) || "col".equals(paymentMethod)) {
            trangThai = trangThaiHoaDonRepo.findById(1).orElse(null); // Both online and COD payment
        }

        if (trangThai != null) {
            hoaDon.setTrangThai(trangThai);
        }

        if ("online".equals(paymentMethod)) {
            hoaDon.setTrangThaiThanhToan(false);  // Set as false initially for online payment
        } else if ("col".equals(paymentMethod)) {
            hoaDon.setTrangThaiThanhToan(false);  // Set to false for COD, indicating not paid
        }


        hoaDon.setPhuongThucThanhToan(true); // True nếu online, false nếu COD


        // 3. Lưu hóa đơn vào database
        hoaDonService.save(hoaDon);

        // 4. Lưu chi tiết đơn hàng từ giỏ hàng
        List<GioHangChiTiet> cartItems = gioHangService.getItems(); // Gọi phương thức mà không cần tham số
        for (GioHangChiTiet cartItem : cartItems) {
            HoaDonChiTiet chiTietHoaDon = new HoaDonChiTiet();
            chiTietHoaDon.setHoaDon(hoaDon);
            chiTietHoaDon.setChiTietSanPham(cartItem.getChiTietSanPham()); // Sản phẩm trong giỏ hàng
            chiTietHoaDon.setSoLuong(cartItem.getSoLuong()); // Số lượng sản phẩm
            chiTietHoaDon.setDonGia(cartItem.getChiTietSanPham().getSanPham().getGiaBan()); // Giá bán của sản phẩm
            chiTietHoaDon.setDonGia(cartItem.getChiTietSanPham().getSanPham().getGiaBan().multiply(BigDecimal.valueOf(cartItem.getSoLuong()))); // Tính tổng tiền


            // Lưu chi tiết đơn hàng vào database
            chiTietHoaDonService.save(chiTietHoaDon); // Giả sử bạn có service để lưu chi tiết đơn hàng

            // Cập nhật số lượng tồn kho
            SanPhamChiTiet chiTietSanPham = cartItem.getChiTietSanPham();
            int soLuongTon = chiTietSanPham.getSoLuong() - cartItem.getSoLuong();
            if (soLuongTon < 0) {
                throw new IllegalArgumentException("Số lượng sản phẩm trong kho không đủ.");
            }
            chiTietSanPham.setSoLuong(soLuongTon);
            chiTietSanPhamService.update(chiTietSanPham); // Lưu thay đổi vào cơ sở dữ liệu
        }




        // 4. Xóa sản phẩm khỏi giỏ hàng sau khi thanh toán thành công
        gioHangService.clearCartAfterPayment(req.getSession());




//         4.5. Gửi email xác nhận đơn hàng
//        try {
//            HoaDon hoaDon1 = new HoaDon(); // Giả sử bạn có cách tạo dto từ HoaDon
//            emailService.sendEmail(email, hoaDon1); // Gửi email đến khách hàng
//        } catch (MessagingException e) {
//            e.printStackTrace();
//            // Xử lý lỗi nếu có
//        }

        // 5. Xử lý thanh toán online (VNPAY)
        if ("online".equals(paymentMethod)) {
            String vnp_TxnRef = String.valueOf(hoaDon.getId());
            String vnp_IpAddr = Config.getIpAddress(req);
            String vnp_TmnCode = Config.vnp_TmnCode;

            Map<String, String> vnp_Params = new HashMap<>();
            vnp_Params.put("vnp_Version", Config.vnp_Version);
            vnp_Params.put("vnp_Command", Config.vnp_Command);
            vnp_Params.put("vnp_TmnCode", vnp_TmnCode);
            vnp_Params.put("vnp_Amount", String.valueOf(amount * 100));
            vnp_Params.put("vnp_CurrCode", "VND");
            vnp_Params.put("vnp_BankCode", "NCB");
            vnp_Params.put("vnp_TxnRef", vnp_TxnRef);
            vnp_Params.put("vnp_OrderInfo", "Thanh toan don hang: " + vnp_TxnRef + " - " + note + " - " + name + " - " + email);
            vnp_Params.put("vnp_OrderType", "other");
            String locate = req.getParameter("language");
            vnp_Params.put("vnp_Locale", (locate != null && !locate.isEmpty()) ? locate : "vn");
            vnp_Params.put("vnp_ReturnUrl", Config.vnp_ReturnUrl);
            vnp_Params.put("vnp_IpAddr", vnp_IpAddr);

            // Thêm thời gian tạo và hết hạn
            Calendar cld = Calendar.getInstance(TimeZone.getTimeZone("Etc/GMT+7"));
            SimpleDateFormat formatter = new SimpleDateFormat("yyyyMMddHHmmss");
            String vnp_CreateDate = formatter.format(cld.getTime());
            vnp_Params.put("vnp_CreateDate", vnp_CreateDate);
            cld.add(Calendar.MINUTE, 15);
            String vnp_ExpireDate = formatter.format(cld.getTime());
            vnp_Params.put("vnp_ExpireDate", vnp_ExpireDate);

            // Tạo query URL và hash dữ liệu
            List<String> fieldNames = new ArrayList<>(vnp_Params.keySet());
            Collections.sort(fieldNames);
            StringBuilder hashData = new StringBuilder();
            StringBuilder query = new StringBuilder();
            for (String fieldName : fieldNames) {
                String fieldValue = vnp_Params.get(fieldName);
                if (fieldValue != null && fieldValue.length() > 0) {
                    hashData.append(fieldName).append('=').append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString())).append('&');
                    query.append(URLEncoder.encode(fieldName, StandardCharsets.US_ASCII.toString()))
                            .append('=')
                            .append(URLEncoder.encode(fieldValue, StandardCharsets.US_ASCII.toString()))
                            .append('&');
                }
            }

            hashData.setLength(hashData.length() - 1); // Remove trailing &
            query.setLength(query.length() - 1); // Remove trailing &

            String vnp_SecureHash = Config.hmacSHA512(Config.secretKey, hashData.toString());
            String paymentUrl = Config.vnp_PayUrl + "?" + query + "&vnp_SecureHash=" + vnp_SecureHash;

            // Redirect đến VNPAY
            response.sendRedirect(paymentUrl);
        } else {
            // Xử lý COD
            response.sendRedirect("/views/online/thank_you.jsp?paymentMethod=cod&orderId=" + hoaDon.getId());
        }



    }



    @RequestMapping("/vnpay_return")
    public void vnpayReturn(HttpServletRequest request, HttpServletResponse response) throws IOException {
        // Lấy các tham số từ VNPAY
        String amount = request.getParameter("vnp_Amount");
        String bankCode = request.getParameter("vnp_BankCode");
        String transactionNo = request.getParameter("vnp_TransactionNo");
        String transactionStatus = request.getParameter("vnp_TransactionStatus");
        String responseCode = request.getParameter("vnp_ResponseCode");
        String orderInfo = request.getParameter("vnp_OrderInfo");
        String txnRef = request.getParameter("vnp_TxnRef");
        String vnp_ReturnComfim = request.getRequestURL().toString();

        String paymentMethod = (String) request.getSession().getAttribute("paymentMethod");

        // Lấy hóa đơn từ ID (ví dụ txnRef)
        HoaDon hoaDon = hoaDonService.findById(Integer.parseInt(txnRef));

        if (hoaDon != null) {
            // Kiểm tra trạng thái thanh toán của hóa đơn
            boolean isPaid = hoaDon.getTrangThaiThanhToan() != null && hoaDon.getTrangThaiThanhToan(); // true if paid

            // Kiểm tra mã phản hồi từ VNPAY và cập nhật trạng thái thanh toán
            if ("00".equals(responseCode) && "00".equals(transactionStatus)) {
                // Giao dịch thành công
                if (!isPaid) {
                    // Nếu trạng thái thanh toán chưa thành công, cập nhật trạng thái thanh toán và trạng thái hóa đơn
                    hoaDon.setTrangThaiThanhToan(true); // 1 - Thành công

                    // Cập nhật trạng thái hóa đơn thành "Chờ vận chuyển" (TrangThaiHoaDon = 2)
                    TrangThaiHoaDon trangThai = trangThaiHoaDonRepo.findById(2).orElse(null); // 2 - Chờ vận chuyển
                    if (trangThai != null) {
                        hoaDon.setTrangThai(trangThai); // Cập nhật trạng thái hóa đơn
                    }
                }
            } else {
                // Phương thức thanh toán online hoặc COD
                if ("online".equals(paymentMethod) || "col".equals(paymentMethod)) {
                    hoaDon.setTrangThaiThanhToan(false); // 0 - Giao dịch thất bại hoặc COD
                }

                // Kiểm tra nếu khách hàng chọn "Tiếp tục"
                if ("https://sandbox.vnpayment.vn/paymentv2/Ncb/Transaction/Confirm.html".equals(vnp_ReturnComfim)) {
                    // Cập nhật trạng thái hóa đơn thành "Chờ vận chuyển" (TrangThaiHoaDon = 2)
                    TrangThaiHoaDon trangThai = trangThaiHoaDonRepo.findById(2).orElse(null); // 2 - Chờ vận chuyển
                    if (trangThai != null) {
                        hoaDon.setTrangThai(trangThai); // Cập nhật trạng thái hóa đơn
                    }
                }
            }

            hoaDonService.save(hoaDon);
        }

        // Chuyển hướng đến trang JSP để hiển thị kết quả
        response.sendRedirect(request.getContextPath() + "/views/online/returnpay.jsp?vnp_Amount=" + amount +
                "&vnp_BankCode=" + bankCode +
                "&vnp_TransactionNo=" + transactionNo +
                "&vnp_TransactionStatus=" + transactionStatus +
                "&vnp_ResponseCode=" + responseCode +
                "&vnp_OrderInfo=" + orderInfo);
    }


}

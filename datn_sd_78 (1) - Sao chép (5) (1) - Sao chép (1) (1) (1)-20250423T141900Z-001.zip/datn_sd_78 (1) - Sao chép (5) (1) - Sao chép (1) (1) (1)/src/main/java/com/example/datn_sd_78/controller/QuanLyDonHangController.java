package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.*;
import com.example.datn_sd_78.repository.*;
import com.itextpdf.text.*;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Arrays;
import java.util.List;

@RequestMapping("/hoaDon")
@Controller
public class QuanLyDonHangController {

    @Autowired
    private HoaDonRepository hoaDonRepository;

    @Autowired
    private HoaDonChiTietRepository hoaDonChiTietRepository;

    @Autowired
    ChiTietSanPhamRepository chiTietSanPhamRepository;

    @Autowired
    KhachHangVoucherRepository khachHangVoucherRepository;
    @Autowired
    DiaChiVanChuyenRepository diaChiVanChuyenRepository;

    //    @GetMapping("/ql-donHang")
    //    public String showOrderList(Model model) {
    //        List<HoaDon> orders = hoaDonRepository.findAll(); // Giả sử bạn có phương thức để lấy danh sách đơn hàng
    //        model.addAttribute("qlDonHang", orders);
    //        return "/ql_donhang/quanLyDonHang"; // Đây là tên của JSP
    //    }

    @GetMapping("/ql-donHang")
    public String listOrders(Model model,
                             @RequestParam(required = false) String search,
                             @RequestParam(required = false) String status,
                             @RequestParam(required = false) String start_date,
                             @RequestParam(required = false) String end_date,
                             @RequestParam(name = "loaiHoaDon", required = false) Boolean loaiHoaDon) {
        List<HoaDon> orders;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        LocalDateTime startDateTime = null;
        LocalDateTime endDateTime = null;
        try {
            if (start_date != null && !start_date.isEmpty()) {
                startDateTime = LocalDateTime.parse(start_date, formatter);
            }
            if (end_date != null && !end_date.isEmpty()) {
                endDateTime = LocalDateTime.parse(end_date, formatter);
            }
        } catch (DateTimeParseException e) {
            // Handle parsing error if necessary
        }

        // Lọc hóa đơn với các tham số không bao gồm loaiHoaDon
        if (loaiHoaDon == null) {
            orders = hoaDonRepository.searchAndFilterOrders(search, status, startDateTime, endDateTime);
        } else {
            // Lọc hóa đơn với tham số loaiHoaDon
            orders = hoaDonRepository.findByLoaiHoaDon(loaiHoaDon);
        }

        // Sắp xếp các đơn hàng theo ngày tạo giảm dần (đơn hàng mới nhất lên đầu)
        orders.sort((o1, o2) -> o2.getNgayTao().compareTo(o1.getNgayTao()));

        model.addAttribute("qlDonHang", orders);
        return "/ql_donhang/quanLyDonHang";
    }



    @Autowired
    private TrangThaiHoaDonRepo trangThaiHoaDonRepo;

    @Autowired
    DiaChiVanChuyenRepository diaChiVanChuyenRepo;


    @GetMapping("/chi-tiet")
    public String getHoaDonChiTietAndUpdateStatus(@RequestParam("id") Integer id, Model model) {
        // Lấy thông tin hóa đơn
        HoaDon hoaDon = hoaDonRepository.findById(id).orElse(null);
        if (hoaDon == null) {
            model.addAttribute("error", "Đơn hàng không tồn tại.");
            return "redirect:/hoaDon/ql-donHang"; // Nếu không tìm thấy hóa đơn, chuyển hướng về trang quản lý đơn hàng
        }

        // Lấy thông tin khách hàng từ hóa đơn
        KhachHang khachHang = hoaDon.getKhachHang();
        model.addAttribute("khachHang", khachHang);

        // Lấy chi tiết sản phẩm trong hóa đơn
        List<HoaDonChiTiet> chiTietList = hoaDonChiTietRepository.findByHoaDon_Id(id);
        model.addAttribute("chiTietList", chiTietList);

        // Lấy danh sách trạng thái
        List<TrangThaiHoaDon> trangThaiList = trangThaiHoaDonRepo.findAll();
        model.addAttribute("trangThaiList", trangThaiList);

        // Kiểm tra trạng thái "Hoàn thành"
        if ("Hoàn thành".equalsIgnoreCase(hoaDon.getTrangThai().getTen())) {
            model.addAttribute("message", "Đơn hàng đã hoàn thành, không thể cập nhật trạng thái.");
        }

        // Thêm đối tượng hoaDon vào model để hiển thị
        model.addAttribute("hoaDon", hoaDon);

        // Kiểm tra xem địa chỉ nhận hàng có tồn tại không
        if (hoaDon.getDiaChiVanChuyen() != null) {
            if (hoaDon.getKhachHang() != null && hoaDon.getKhachHang().getId() != null) {
                // Lấy địa chỉ vận chuyển theo idKhachHang
                DiaChiVanChuyen diaChiVanChuyen = diaChiVanChuyenRepo.findById(hoaDon.getDiaChiVanChuyen()).orElse(null);
                if (diaChiVanChuyen != null) {
                    model.addAttribute("diaChiVanChuyen", diaChiVanChuyen);
                } else {
                    model.addAttribute("diaChiVanChuyenError", "Không tìm thấy địa chỉ nhận hàng.");
                }
            } else {
                // Khách lẻ, xử lý địa chỉ mặc định
                DiaChiVanChuyen diaChiMacDinh = diaChiVanChuyenRepo.findByIdDiaChiVanChuyen(hoaDon.getDiaChiVanChuyen()).orElse(null); // Giả sử ID = 1 là địa chỉ mặc định
                if (diaChiMacDinh != null) {
                    model.addAttribute("diaChiVanChuyen", diaChiMacDinh);
                } else {
                    model.addAttribute("diaChiVanChuyenError", "Không tìm thấy địa chỉ mặc định cho khách lẻ.");
                }
            }
        } else {
            model.addAttribute("diaChiVanChuyenError", "Địa chỉ nhận hàng không có.");
        }


        return "/ql_donhang/chiTietDonHang";
    }


    @PostMapping("/update-status")
    public String updateOrderStatus(@RequestParam("id") Integer id, @RequestParam("statusId") Integer statusId, RedirectAttributes redirectAttributes) {
        HoaDon hoaDon = hoaDonRepository.findById(id).orElse(null);

        if (hoaDon == null) {
            redirectAttributes.addFlashAttribute("error", "Đơn hàng không tồn tại.");
            return "redirect:/hoaDon/ql-donHang";
        }

        // Kiểm tra nếu trạng thái hiện tại là "Hoàn thành"
        if ("Hoàn thành".equalsIgnoreCase(hoaDon.getTrangThai().getTen())) {
            redirectAttributes.addFlashAttribute("error", "Đơn hàng đã hoàn thành, không thể cập nhật trạng thái.");
            return "redirect:/hoaDon/ql-donHang";
        }

        TrangThaiHoaDon newStatus = trangThaiHoaDonRepo.findById(statusId).orElse(null);

        if (newStatus != null && isNextStatus(hoaDon.getTrangThai(), newStatus)) {
            hoaDon.setTrangThai(newStatus);
            hoaDonRepository.save(hoaDon);
            redirectAttributes.addFlashAttribute("success", "Cập nhật trạng thái thành công.");
        } else {
            redirectAttributes.addFlashAttribute("error", "Trạng thái không hợp lệ.");
        }

        return "redirect:/hoaDon/ql-donHang";
    }

    // Hàm kiểm tra trạng thái tiếp theo
    private boolean isNextStatus(TrangThaiHoaDon currentStatus, TrangThaiHoaDon newStatus) {
        return newStatus.getId() == currentStatus.getId() + 1;
    }


    @GetMapping("/huy-don")
    public String showCancelOrderForm(@RequestParam("id") Integer id, @RequestParam(value = "error", required = false) String error, Model model) {
        HoaDon hoaDon = hoaDonRepository.findById(id).orElse(null);

        if (hoaDon != null) {
            model.addAttribute("hoaDon", hoaDon);
        }

        if (error != null) {
            model.addAttribute("error", error);
        }

        return "/ql_donhang/huyDonForm"; // Tạo một trang JSP nhập lý do hủy
    }


    @PostMapping("/huy-don")
    public String cancelOrder(@RequestParam("id") Integer id, @RequestParam("lyDoHuy") String lyDoHuy) {
        HoaDon hoaDon = hoaDonRepository.findById(id).orElse(null);
        if(hoaDon.getVoucher() != null) {
            KhachHangVoucher khachHangVoucher= khachHangVoucherRepository.findByKhachHangAndVoucher(hoaDon.getKhachHang(), hoaDon.getVoucher());
            khachHangVoucher.setTrangThai(0);
            khachHangVoucherRepository.save(khachHangVoucher);
        }

        if (hoaDon != null) {
            // Lấy danh sách các trạng thái có thể hủy
            List<String> allowedStatus = Arrays.asList("Chờ xác nhận", "Đang xử lý", "Chờ đơn vị vận chuyển");

            // Hoàn lại số lượng sản phẩm trong kho
            List<HoaDonChiTiet> chiTietHoaDons = hoaDonChiTietRepository.findByHoaDon(hoaDon);
            for (HoaDonChiTiet chiTiet : chiTietHoaDons) {
                SanPhamChiTiet sanPham = chiTiet.getChiTietSanPham();
                int soLuongHoanLai = chiTiet.getSoLuong();
                sanPham.setSoLuong(sanPham.getSoLuong() + soLuongHoanLai);
                chiTietSanPhamRepository.save(sanPham);
            }

            // Kiểm tra xem trạng thái hiện tại của đơn hàng có trong danh sách cho phép hủy không
            if (allowedStatus.contains(hoaDon.getTrangThai().getTen())) {
                TrangThaiHoaDon huyTrangThai = trangThaiHoaDonRepo.findByTen("Hủy").orElse(null);
                if (huyTrangThai != null) {
                    hoaDon.setTrangThai(huyTrangThai);
                    hoaDon.setLyDoHuy(lyDoHuy);
                    hoaDonRepository.save(hoaDon);
                }
            } else {
                String errorMessage = "Không thể hủy đơn trong trạng thái hiện tại";
                return "redirect:/hoaDon/ql-donHang?error=" + URLEncoder.encode(errorMessage, StandardCharsets.UTF_8);
            }
        }

        return "redirect:/hoaDon/ql-donHang"; // Quay lại danh sách đơn hàng sau khi hủy
    }



    @GetMapping("/db-donHang")
    private String showv() {
        return "/ql_donhang/dashboard";
    }

    @GetMapping("/xuatPdf")
    public void xuatPdf(@RequestParam("id") Integer id, HttpServletResponse response) throws IOException, DocumentException {
        HoaDon hoaDon = hoaDonRepository.findById(id).orElse(null);
        if (hoaDon == null) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Hóa đơn không tồn tại");
            return;
        }

        List<HoaDonChiTiet> chiTietList = hoaDonChiTietRepository.findByHoaDon_Id(id);
        if (chiTietList.isEmpty()) {
            response.sendError(HttpServletResponse.SC_NOT_FOUND, "Không có chi tiết hóa đơn cho hóa đơn này");
            return;
        }

        // Thiết lập kiểu phản hồi là PDF
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=hoa_don_" + id + ".pdf");

        // Tạo tài liệu PDF
        Document document = new Document();
        PdfWriter.getInstance(document, response.getOutputStream());
        document.open();

        // Thêm tên cửa hàng và địa chỉ

//        Font headerFont = new Font(Font.FontFamily.HELVETICA, 16, Font.BOLD);
//        Paragraph storeName = new Paragraph("Tên Cửa Hàng: Cửa Hàng Bán Dép Footstyle", headerFont);
//        storeName.setAlignment(Element.ALIGN_CENTER);
//        document.add(storeName);
//
//        Paragraph storeAddress = new Paragraph("Địa Chỉ: FPT Polytechnic, Nam Từ Liêm, TP. Hà Nội", headerFont);
//        storeAddress.setAlignment(Element.ALIGN_CENTER);
//        document.add(storeAddress);

// Dòng trống để ngăn cách
        document.add(new Paragraph("\n"));

        // Thêm tiêu đề
        Font titleFont = new Font(Font.FontFamily.HELVETICA, 20, Font.BOLD);
        Paragraph title = new Paragraph("Chi Tiết Hóa Đơn", titleFont);
        title.setAlignment(Element.ALIGN_CENTER);
        document.add(title);

        // Thông tin khách hàng
        Font subTitleFont = new Font(Font.FontFamily.HELVETICA, 14, Font.BOLD);
        Paragraph customerInfo = new Paragraph("Thông Tin Khách Hàng", subTitleFont);
        document.add(customerInfo);
        document.add(new Paragraph("Tên: " + hoaDon.getKhachHang().getHoTen()));
        document.add(new Paragraph("Email: " + hoaDon.getKhachHang().getUser().getEmail()));
        document.add(new Paragraph("Số điện thoại: " + hoaDon.getKhachHang().getSdt()));

        // Thông tin hóa đơn
        document.add(new Paragraph("Thông Tin Hóa Đơn", subTitleFont));
        document.add(new Paragraph("Ngày Tạo: " + hoaDon.getNgayTao()));
        document.add(new Paragraph("Tổng Tiền: " + hoaDon.getTongTien() + " VND"));

        // Chi tiết sản phẩm
        document.add(new Paragraph("Chi Tiết Sản Phẩm", subTitleFont));

        // Tạo bảng chi tiết hóa đơn
        PdfPTable table = new PdfPTable(5); // 5 cột
        table.setWidthPercentage(100); // Đặt chiều rộng của bảng là 100%

        // Đặt các tiêu đề cho bảng
        table.addCell("ID Hóa Đơn");
        table.addCell("Tên Sản Phẩm");
        table.addCell("Số Lượng");
        table.addCell("Giá (VND)");
        table.addCell("Thành Tiền (VND)");

        // Thêm các dòng vào bảng
        for (HoaDonChiTiet chiTiet : chiTietList) {
            table.addCell(String.valueOf(hoaDon.getId())); // ID Hóa Đơn
            table.addCell(chiTiet.getChiTietSanPham().getSanPham().getTen()); // Tên sản phẩm
            table.addCell(String.valueOf(chiTiet.getSoLuong())); // Số lượng
            table.addCell(String.valueOf(chiTiet.getDonGia())); // Giá
            table.addCell(String.valueOf(chiTiet.getTongTien())); // Thành tiền
        }

        // Thêm bảng vào tài liệu PDF
        document.add(table);

        // Tổng cộng
        document.add(new Paragraph("Tổng Cộng: " + hoaDon.getTongTien() + " VND", subTitleFont));

        document.close();
    }
    @GetMapping("/order-details/{orderId}")
    public String viewOrderDetails(@PathVariable("orderId") Integer orderId, Model model) {
        // Tìm hóa đơn theo ID
        HoaDon hoaDon = hoaDonRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Không tìm thấy hóa đơn với ID: " + orderId));

        // Kiểm tra giá trị tienShip
        if (hoaDon.getTienShip() == null) {
            System.out.println("Phí ship là null");
        } else {
            System.out.println("Phí ship: " + hoaDon.getTienShip());
        }

        // Tìm địa chỉ vận chuyển (nếu có) từ ID địa chỉ vận chuyển
        DiaChiVanChuyen diaChiVanChuyen = null;
        if (hoaDon.getDiaChiVanChuyen() != null) {
            diaChiVanChuyen = diaChiVanChuyenRepository.findById(hoaDon.getDiaChiVanChuyen()).orElse(null);
        }

        // Đưa thông tin vào model
        model.addAttribute("hoaDon", hoaDon);
        model.addAttribute("diaChiVanChuyen", diaChiVanChuyen);
        model.addAttribute("diaChiVanChuyenError", "Địa chỉ không hợp lệ");
        model.addAttribute("chiTietHoaDonList", hoaDon.getHoaDonChiTiet());

        return "/ql_donhang/orderDetails";
    }

}

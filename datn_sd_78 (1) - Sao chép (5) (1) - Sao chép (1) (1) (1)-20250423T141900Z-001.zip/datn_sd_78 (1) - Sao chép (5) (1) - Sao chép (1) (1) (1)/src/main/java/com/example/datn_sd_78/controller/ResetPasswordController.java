package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.service.AuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class ResetPasswordController {

    @Autowired
    private AuthService userService;

    @GetMapping("/reset-password")
    public String showResetPasswordPage(@RequestParam("token") String token, Model model) {
        if (!userService.validateResetToken(token)) {
            model.addAttribute("message", "Yêu cầu hết hạn, gửi lại yêu cầu mới!.");
            return "reset-password";  // Hiển thị thông báo lỗi nếu token không hợp lệ
        }
        model.addAttribute("token", token);  // Truyền token vào form
        return "reset-password";
    }

    @PostMapping("/resetPassword")
    public String resetPassword(@RequestParam("token") String token, @RequestParam("newPassword") String newPassword, Model model) {
        try {
            boolean isSuccess = userService.resetPassword(token, newPassword);
            if (isSuccess) {
                model.addAttribute("message", "Mật khẩu đã được thay đổi thành công.");
                return "login";  // Chuyển về trang đăng nhập
            } else {
                model.addAttribute("message", "Có lỗi xảy ra khi thay đổi mật khẩu.");
                return "reset-password";
            }
        } catch (Exception e) {
            model.addAttribute("message", "Có lỗi xảy ra: " + e.getMessage());
            return "reset-password";
        }
    }
}

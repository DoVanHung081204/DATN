package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.Anh;
import com.example.datn_sd_78.entity.ChatLieu;
import com.example.datn_sd_78.entity.DanhMuc;
import com.example.datn_sd_78.entity.KieuDang;
import com.example.datn_sd_78.entity.MauSac;
import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.NhapHang;
import com.example.datn_sd_78.entity.SanPham;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.entity.Size;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.repository.AnhRepository;
import com.example.datn_sd_78.repository.ChatLieuRepository;
import com.example.datn_sd_78.repository.ChiTietSanPhamRepository;
import com.example.datn_sd_78.repository.DanhMucRepository;
import com.example.datn_sd_78.repository.KieuDangRepository;
import com.example.datn_sd_78.repository.MauSacRepository;
import com.example.datn_sd_78.repository.NhapHangRepository;
import com.example.datn_sd_78.repository.SanPhamRepository;
import com.example.datn_sd_78.repository.SizeRepository;
import com.example.datn_sd_78.service.AuthService;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.property.TextAlignment;
import com.itextpdf.layout.property.UnitValue;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Controller
@RequestMapping("/admin")
public class SanPhamController {

    @Autowired
    private SanPhamRepository sanPhamRepository;

    @Autowired
    private ChiTietSanPhamRepository chiTietSanPhamRepository;
    @Autowired
    private AuthService authService;

    @GetMapping("/index")
    public String show(Model model,
                       @RequestParam(defaultValue = "1") int page,
                       @RequestParam(defaultValue = "5") int size) {
        Pageable pageable = PageRequest.of(page - 1, size);
        Page<SanPham> spPage = sanPhamRepository.findAll(pageable);

        model.addAttribute("dataSp", spPage.getContent()); // List of products
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", spPage.getTotalPages());
        model.addAttribute("totalItems", spPage.getTotalElements());

        // Calculate the starting index for each page
        int startIndex = (page - 1) * size;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("startIndex", startIndex);

        return "/san_pham/hello";
    }

    @GetMapping("/danhMuc")
    private String showDanhMuc(Model model) {
        List<DanhMuc> dm = danhMucRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataDanhMuc", dm);
        return "/danh_muc/danhMuc";
    }

    @PostMapping("/themDanhMuc")
    public String addDanhMuc(@RequestParam String ten, @RequestParam int trangthai) {
        DanhMuc danhMuc = new DanhMuc();
        danhMuc.setTen(ten);
        danhMuc.setTrangthai(trangthai);
        danhMuc.setNgayTao(LocalDate.now());
        danhMucRepository.save(danhMuc);
        return "redirect:/admin/danhMuc";
    }

    @RequestMapping("/xoaDanhMuc/{id}")
    public String xoaDanhMuc(@PathVariable int id) {
        danhMucRepository.deleteById(id);
        return "redirect:/admin/danhMuc";
    }

    @GetMapping("/productDetail/{id}")
    public String showProductDetail(@PathVariable("id") Integer id, Model model) {
        SanPham sanPham = sanPhamRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("sanPham", sanPham);
        return "/san_pham/SanPhamChiTiet";
    }

    @GetMapping("/search")
    public String searchProducts(@RequestParam("query") String query, Model model) {
        List<SanPham> sanPhams = sanPhamRepository.findByTenContaining(query.toLowerCase());
        model.addAttribute("dataSp", sanPhams);
        return "/san_pham/hello";
    }
    @GetMapping("/search2")
    public String searchProducts2(@RequestParam("query") String query, Model model) {
        List<SanPham> sanPhams = sanPhamRepository.findByTenContaining(query.toLowerCase());
        model.addAttribute("sanPhams", sanPhams);
        return "/khuyenmai/products";
    }

    @GetMapping("/exportPDF")
    public void exportPDF(HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        response.setHeader("Content-Disposition", "attachment; filename=products.pdf");

        PdfWriter writer = new PdfWriter(response.getOutputStream());
        PdfDocument pdf = new PdfDocument(writer);
        Document document = new Document(pdf);

        PdfFont font = PdfFontFactory.createFont(StandardFonts.HELVETICA);
        document.setFont(font);

        // Tiêu đề
        Paragraph title = new Paragraph("Danh Sách Sản Phẩm")
                .setFontSize(18)
                .setBold()
                .setTextAlignment(TextAlignment.CENTER)
                .setMarginBottom(20);
        document.add(title);

        // Bảng
        Table table = new Table(7);
        table.setWidth(UnitValue.createPercentValue(100));

        // Header Cells
        String[] headers = {"Mã sản phẩm", "Tên sản phẩm", "Số lượng", "Thương hiệu", "Màu sắc", "Kích thước", "Trạng thái"};
        for (String header : headers) {
            table.addHeaderCell(new Cell()
                    .add(new Paragraph(header))
                    .setFontSize(10)
                    .setBold()
                    .setBackgroundColor(ColorConstants.LIGHT_GRAY)
                    .setTextAlignment(TextAlignment.CENTER)
                    .setPadding(5));
        }

        // Data Cells
        List<SanPhamChiTiet> chiTietSanPhams = chiTietSanPhamRepository.findAll();
        for (SanPhamChiTiet spct : chiTietSanPhams) {
            table.addCell(new Cell().add(new Paragraph(spct.getSanPham().getMa())).setTextAlignment(TextAlignment.CENTER));
            table.addCell(new Cell().add(new Paragraph(spct.getSanPham().getTen())).setTextAlignment(TextAlignment.LEFT));
            table.addCell(new Cell().add(new Paragraph(String.valueOf(spct.getSoLuong()))).setTextAlignment(TextAlignment.CENTER));
            table.addCell(new Cell().add(new Paragraph(spct.getSanPham().getThuongHieu())).setTextAlignment(TextAlignment.LEFT));
            table.addCell(new Cell().add(new Paragraph(spct.getMauSac().getTen())).setTextAlignment(TextAlignment.CENTER));
            table.addCell(new Cell().add(new Paragraph(spct.getSize().getTen())).setTextAlignment(TextAlignment.CENTER));
            table.addCell(new Cell().add(new Paragraph(spct.getSanPham().getTrangThai() == 1 ? "Còn hàng" : "Hết hàng")).setTextAlignment(TextAlignment.CENTER));
        }

        document.add(table);
        document.close();
    }
    @Autowired
    private ChatLieuRepository chatLieuRepository;

    @Autowired
    private DanhMucRepository danhMucRepository;

    @Autowired
    private MauSacRepository mauSacRepository;

    @Autowired
    private SizeRepository sizeRepository;

    @Autowired
    private KieuDangRepository kieuDangRepository;

    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        // Tìm chi tiết sản phẩm dựa trên id
        SanPhamChiTiet chiTiet = chiTietSanPhamRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        if (chiTiet != null) {
            model.addAttribute("chiTiet", chiTiet);
            return "editSanPham";  // Trả về trang edit.jsp
        } else {
            return "redirect:/admin/index";  // Nếu không tìm thấy thì quay về danh sách
        }
    }


    @PostMapping("/deleteSp/{id}")
    public String deleteProduct(@PathVariable("id") Integer id, RedirectAttributes redirectAttributes) {
        try {
            // Lấy sản phẩm từ repository
            Optional<SanPham> sanPhamOptional = sanPhamRepository.findById(id);

            if (sanPhamOptional.isPresent()) {
                SanPham sanPham = sanPhamOptional.get();

                // Kiểm tra trạng thái hiện tại của sản phẩm và thay đổi
                if (sanPham.getTrangThai() == 1) {  // Trạng thái ACTIVE là 1
                    sanPham.setTrangThai(0);  // Cập nhật trạng thái thành DELETED (0)
                    redirectAttributes.addFlashAttribute("message", "Sản phẩm đã được cập nhật trạng thái thành xóa.");
                } else {
                    sanPham.setTrangThai(1);  // Cập nhật trạng thái thành ACTIVE (1)
                    redirectAttributes.addFlashAttribute("message", "Sản phẩm đã được cập nhật trạng thái thành hoạt động.");
                }

                // Lưu lại thay đổi
                sanPhamRepository.save(sanPham);
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "Sản phẩm không tồn tại.");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Cập nhật trạng thái không thành công.");
        }
        return "redirect:/admin/index";
    }



    @GetMapping("/suaDanhMuc/{id}")
    public String suaDanhMuc(@PathVariable("id") Integer id, Model model) {
        DanhMuc danhMuc = danhMucRepository.findById(id).orElseThrow(() -> new IllegalArgumentException("ID không hợp lệ: " + id));
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("danhMuc", danhMuc);
        return "/danh_muc/updateDanhMuc";
    }

    @PostMapping("/capNhatDanhMuc")
    public String capNhatDanhMuc(@ModelAttribute DanhMuc danhMuc) {
        DanhMuc danhMucOld = danhMucRepository.findById(danhMuc.getId()).orElseThrow(() -> new IllegalArgumentException("ID không hợp lệ: " + danhMuc.getId()));

        // Giữ nguyên ngày tạo nếu không thay đổi
        danhMuc.setNgayTao(danhMucOld.getNgayTao());

        danhMucRepository.save(danhMuc);
        return "redirect:/admin/danhMuc";
    }

    @GetMapping("/size")
    private String showSize(Model model) {
        List<Size> dm = sizeRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataSize", dm);
        return "/size/size";
    }


    @GetMapping("/suaSize/{id}")
    public String suaSize(@PathVariable("id") int id, Model model) {
        Size size = sizeRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("size", size);
        return "/size/updateSize"; // tên của file JSP
    }

    @PostMapping("/capSize")
    public String capNhatSize(@ModelAttribute Size size) {
        Size danhMucOld = sizeRepository.findById(size.getId()).orElseThrow(() -> new IllegalArgumentException("ID không hợp lệ: " + size.getId()));

        sizeRepository.save(size);
        return "redirect:/admin/size";
    }

    @RequestMapping("/xoaSize/{id}")
    public String xoaSize(@PathVariable int id) {
        sizeRepository.deleteById(id);
        return "redirect:/admin/size"; // Đổi redirect nếu cần
    }

    @PostMapping("/themSize")
    public String addSize(@RequestParam String ten, @RequestParam int trangthai) {
        Size size = new Size();
        size.setTen(ten);
        size.setTrangthai(trangthai);
        sizeRepository.save(size);
        return "redirect:/admin/size";
    }

    @GetMapping("/chatLieu")
    private String showChatLieu(Model model) {
        List<ChatLieu> dm = chatLieuRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataChatLieu", dm);
        return "/chat_lieu/chatLieu";
    }

    @GetMapping("/suaChatLieu/{id}")
    public String suaChatLieu(@PathVariable("id") Integer id, Model model) {
        ChatLieu chatLieu = chatLieuRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("datachatLieu", chatLieu);
        return "/chat_lieu/suaChatLieu"; // tên của JSP page
    }

    // Cập nhật chất liệu
    @PostMapping("/capNhatChatLieu/{id}")
    public String capNhatChatLieu(@PathVariable("id") Integer id,
                                  @RequestParam("ten") String ten,
                                  @RequestParam("trangthai") Integer trangthai) {
        ChatLieu chatLieu = chatLieuRepository.findById(id).orElse(null);
        if (chatLieu != null) {
            chatLieu.setTen(ten);
            chatLieu.setTrangthai(trangthai);
            chatLieuRepository.save(chatLieu);
        }
        return "redirect:/admin/chatLieu"; // chuyển hướng đến danh sách chất liệu sau khi cập nhật
    }

    @RequestMapping("/xoaChatLieu/{id}")
    public String xoaChatLieu(@PathVariable int id) {
        chatLieuRepository.deleteById(id);
        return "redirect:/admin/chatLieu"; // Đổi redirect nếu cần
    }

    @PostMapping("/themChatLieu")
    public String addChatLieu(@RequestParam String ten, @RequestParam int trangthai) {
        ChatLieu cl = new ChatLieu();
        cl.setTen(ten);
        cl.setTrangthai(trangthai);
        chatLieuRepository.save(cl);
        return "redirect:/admin/chatLieu";
    }

    @GetMapping("/kieudang")
    private String showKieuDang(Model model) {
        List<KieuDang> kd = kieuDangRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataKieuDang", kd);
        return "/kieu_dang/kieu_dang";
    }


    @RequestMapping("/xoaKieuDang/{id}")
    public String xoaKieuDang(@PathVariable int id) {
        kieuDangRepository.deleteById(id);
        return "redirect:/admin/kieuDang"; // Đổi redirect nếu cần
    }

    @PostMapping("/themKieuDang")
    public String addKieuDang(@RequestParam String ten, @RequestParam int trangthai) {
        KieuDang kd = new KieuDang();
        kd.setTen(ten);
        kd.setTrangthai(trangthai);
        kieuDangRepository.save(kd);
        return "redirect:/admin/kieuDang";
    }

    @GetMapping("/suaKieuDang/{id}")
    public String suaKieuDangString(@PathVariable("id") Integer id, Model model) {
        KieuDang kieuDang = kieuDangRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataKieuDang", kieuDang);
        return "/kieu_dang/updateKieuDang"; // tên của JSP page
    }

    // Cập nhật chất liệu
    @PostMapping("/capNhatKieuDang/{id}")
    public String capNhatKieuDang(@PathVariable("id") Integer id,
                                  @RequestParam("ten") String ten,
                                  @RequestParam("trangthai") Integer trangthai) {
        KieuDang kieuDang = kieuDangRepository.findById(id).orElse(null);
        if (kieuDang != null) {
            kieuDang.setTen(ten);
            kieuDang.setTrangthai(trangthai);
            kieuDangRepository.save(kieuDang);
        }
        return "redirect:/admin/kieuDang"; // chuyển hướng đến danh sách chất liệu sau khi cập nhật
    }

    @GetMapping("/mauSac")
    private String showMauSac(Model model) {
        List<MauSac> ms = mauSacRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataMauSac", ms);
        return "/mau_sac/list";
    }

    @PostMapping("/themMauSac")
    public String addMauSac(@RequestParam String ten, @RequestParam int trangthai) {
        MauSac ms = new MauSac();
        ms.setTen(ten);
        ms.setTrangthai(trangthai);
        mauSacRepository.save(ms);
        return "redirect:/admin/mauSac";
    }

    @RequestMapping("/xoaMauSac/{id}")
    public String xoaMauSac(@PathVariable int id) {
        mauSacRepository.deleteById(id);
        return "redirect:/admin/mauSac"; // Đổi redirect nếu cần
    }

    @GetMapping("/suaMauSac/{id}")
    public String suaMauSac(@PathVariable("id") int id, Model model) {
        MauSac ms = mauSacRepository.findById(id).orElse(null);
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("dataMauSac", ms);
        return "/mau_sac/updateMauSac";
    }

    @PostMapping("/capMauSac")
    public String capNhatMauSac(@ModelAttribute MauSac ms) {
        MauSac danhMucOld = mauSacRepository.findById(ms.getId()).orElseThrow(() -> new IllegalArgumentException("ID không hợp lệ: " + ms.getId()));
        mauSacRepository.save(ms);
        return "redirect:/admin/list";
    }

    @GetMapping("/editSanPham/{id}")
    public String showEditSanPhamForm(@PathVariable("id") Integer id, Model model) {
        // Lấy thông tin sản phẩm từ database
        SanPham sanPham = sanPhamRepository.getById(id); // Lấy sản phẩm theo ID
        model.addAttribute("sanPham", sanPham);

        // Lấy danh sách danh mục, kiểu dáng, chất liệu từ database
        List<DanhMuc> danhMucList = danhMucRepository.findAll();
        List<KieuDang> kieuDangList = kieuDangRepository.findAll();
        List<ChatLieu> chatLieuList = chatLieuRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        // Gửi danh sách danh mục, kiểu dáng, chất liệu về JSP
        model.addAttribute("danhMucList", danhMucList);
        model.addAttribute("kieuDangList", kieuDangList);
        model.addAttribute("chatLieuList", chatLieuList);

        return "/san_pham/edit-sanpham";
    }

    @PostMapping("/updateSanPham/{id}")
    public String updateSanPham(@PathVariable("id") Integer id, @ModelAttribute SanPham sanPham,
                                HttpServletRequest request) {
        // Lấy sản phẩm cũ từ database
        SanPham existingSanPham = sanPhamRepository.getById(id);

        // Cập nhật thông tin sản phẩm cũ với dữ liệu mới từ form
        existingSanPham.setTen(sanPham.getTen());
        existingSanPham.setGiaBan(sanPham.getGiaBan());
        existingSanPham.setDanhMuc(sanPham.getDanhMuc());
        existingSanPham.setKieuDang(sanPham.getKieuDang());
        existingSanPham.setChatLieu(sanPham.getChatLieu());
        existingSanPham.setGioiTinh(sanPham.getGioiTinh());
        existingSanPham.setTrangThai(sanPham.getTrangThai());
        // Lưu lại sản phẩm sau khi cập nhật
        sanPhamRepository.save(existingSanPham);

        return "redirect:/admin/productDetail/" + id;
    }


    @GetMapping("/addSp")
    public String showAddSanPhamForm(Model model, @RequestParam(required = false) Integer sanPhamId) {
        // Nếu sanPhamId được cung cấp, tìm sản phẩm
        SanPham sanPham = sanPhamId != null ? sanPhamRepository.findById(sanPhamId).orElse(null) : null;
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        // Thêm các thuộc tính vào model
        model.addAttribute("danhMucList", danhMucRepository.findAll()); // Lấy danh sách danh mục
        model.addAttribute("kieuDangList", kieuDangRepository.findAll()); // Lấy danh sách kiểu dáng
        model.addAttribute("chatLieuList", chatLieuRepository.findAll()); // Lấy danh sách chất liệu
        model.addAttribute("kichCoList", sizeRepository.findAll()); // Danh sách size
        model.addAttribute("mauSacList", mauSacRepository.findAll()); // Danh sách màu sắc

        // Nếu sanPham có giá trị, tìm ảnh liên quan đến sản phẩm đó
        if (sanPham != null) {
            List<Anh> anhList = anhRepository.findBySanPham(sanPham); // Lấy danh sách ảnh của sản phẩm
            model.addAttribute("anhList", anhList); // Thêm vào model
        }

        return "/san_pham/addSanPham"; // Trả về tên trang JSP
    }



    @PostMapping("/addSanPham")
    public String addSanPham(@RequestParam("ma") String ma,
                             @RequestParam("thuongHieu") String thuongHieu,
                             @RequestParam("ten") String ten,
                             @RequestParam("giaBan") BigDecimal giaBan,
                             @RequestParam("danhMuc") Integer danhMucId,
                             @RequestParam("kieuDang") Integer kieuDangId,
                             @RequestParam("chatLieu") Integer chatLieuId,
                             @RequestParam("gioiTinh") int gioiTinh,
                             @RequestParam("trangThai") int trangThai,
                             @RequestParam("anh") MultipartFile anh,
                             HttpServletRequest request) {


        // Tạo đối tượng SanPham và thiết lập thuộc tính
        SanPham sanPham = new SanPham();
        sanPham.setMa(ma);
        sanPham.setThuongHieu(thuongHieu);
        sanPham.setTen(ten);
        sanPham.setGiaBan(giaBan);
        sanPham.setGioiTinh(gioiTinh);
        sanPham.setTrangThai(trangThai);
        sanPham.setNgayTao(new Date());

        // Thiết lập các mối quan hệ
        DanhMuc danhMuc = danhMucRepository.findById(danhMucId).orElse(null);
        KieuDang kieuDang = kieuDangRepository.findById(kieuDangId).orElse(null);
        ChatLieu chatLieu = chatLieuRepository.findById(chatLieuId).orElse(null);

        if (danhMuc == null || kieuDang == null || chatLieu == null) {
            // Xử lý nếu không tìm thấy danh mục, kiểu dáng hoặc chất liệu
            return "redirect:/admin/index?error=notFound";
        }

        sanPham.setDanhMuc(danhMuc);
        sanPham.setKieuDang(kieuDang);
        sanPham.setChatLieu(chatLieu);

        // Xử lý lưu file ảnh
        String uploadDir = request.getServletContext().getRealPath("/image");
        File uploadDirectory = new File(uploadDir);
        if (!uploadDirectory.exists()) {
            uploadDirectory.mkdirs();
        }

        String fileName = anh.getOriginalFilename();
        File file = new File(uploadDir, fileName);
        try {
            anh.transferTo(file);
            sanPham.setAnh(fileName);
        } catch (IOException e) {
            e.printStackTrace();
            return "redirect:/admin/index?error=uploadFailed";
        }

        // Lưu sản phẩm trước
        sanPhamRepository.save(sanPham);

        return "redirect:/admin/index";
    }

    @Autowired
    private AnhRepository anhRepository;

    @GetMapping("/exportSanPhamExcel")
    public ResponseEntity<byte[]> exportSanPhamToExcel(@PathVariable("id") Integer sanPhamId) throws IOException {

        SanPham sanPham = sanPhamRepository.getById(sanPhamId);

        // Kiểm tra xem sản phẩm có tồn tại hay không
        if (sanPham == null) {
            // Nếu không tìm thấy sản phẩm, trả về lỗi 404
            return ResponseEntity.notFound().build();
        }

        List<SanPhamChiTiet> chiTietSanPhamList = sanPham.getChiTietSanPhamList();

        // Tạo Workbook và Sheet
        Workbook workbook = new XSSFWorkbook();
        Sheet sheet = workbook.createSheet("Chi Tiết Sản Phẩm");

        // Tạo dòng tiêu đề
        Row headerRow = sheet.createRow(0);
        headerRow.createCell(0).setCellValue("Mã Sản Phẩm");
        headerRow.createCell(1).setCellValue("Tên Sản Phẩm");
        headerRow.createCell(2).setCellValue("Danh Mục");
        headerRow.createCell(3).setCellValue("Thương Hiệu");
        headerRow.createCell(4).setCellValue("Số Lượng");
        headerRow.createCell(5).setCellValue("Giá Bán");
        headerRow.createCell(6).setCellValue("Ngày Tạo");
        headerRow.createCell(7).setCellValue("Trạng Thái");

        // Điền dữ liệu sản phẩm vào dòng thứ 2
        Row row = sheet.createRow(1);
        row.createCell(0).setCellValue(sanPham.getMa());
        row.createCell(1).setCellValue(sanPham.getTen());
        row.createCell(2).setCellValue(sanPham.getDanhMuc().getTen());
        row.createCell(3).setCellValue(sanPham.getThuongHieu());
        row.createCell(5).setCellValue(sanPham.getGiaBan().toString()); // Chuyển đổi BigDecimal thành String
        row.createCell(6).setCellValue(sanPham.getNgayTao().toString());
        row.createCell(7).setCellValue(sanPham.getTrangThai() == 1 ? "Còn hàng" : "Hết hàng");

        // Tiêu đề cho chi tiết sản phẩm
        Row detailHeaderRow = sheet.createRow(3);
        detailHeaderRow.createCell(0).setCellValue("Màu Sắc");
        detailHeaderRow.createCell(1).setCellValue("Kích Thước");
        detailHeaderRow.createCell(2).setCellValue("Mã QR");

        // Điền dữ liệu chi tiết sản phẩm
        int rowNum = 4; // Bắt đầu từ dòng thứ 5
        for (SanPhamChiTiet chiTiet : chiTietSanPhamList) {
            Row detailRow = sheet.createRow(rowNum++);
            detailRow.createCell(0).setCellValue(chiTiet.getMauSac().getTen());
            detailRow.createCell(1).setCellValue(chiTiet.getSize().getTen());
            detailRow.createCell(2).setCellValue(chiTiet.getQrcode());
        }

        // Ghi dữ liệu vào ByteArrayOutputStream
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        workbook.write(outputStream);
        workbook.close();

        // Tạo ResponseEntity để gửi tệp Excel cho người dùng
        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_OCTET_STREAM);
        headers.setContentDispositionFormData("attachment", "ChiTietSanPham.xlsx");

        return ResponseEntity
                .ok()
                .headers(headers)
                .body(outputStream.toByteArray());
    }


    @GetMapping("/sanPham/{id}/themChiTiet")
    public String showAddDetailForm(@PathVariable("id") Integer sanPhamId, Model model) {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        Optional<SanPham> sanPham = sanPhamRepository.findById(sanPhamId);
        if (sanPham.isPresent()) {
            model.addAttribute("sanPham", sanPham.get());
            model.addAttribute("sizes", sizeRepository.findAll());  // Lấy tất cả kích thước
            model.addAttribute("colors", mauSacRepository.findAll());  // Lấy tất cả màu sắc
            return "/san_pham/addChiTietSanPham"; // Tên của file JSP (thêmChiTietSanPham.jsp)
        } else {
            return "redirect:/admin/index"; // Nếu không tìm thấy sản phẩm, quay về danh sách
        }}

    @PostMapping("/sanPham/{id}/luuChiTiet")
    public String saveProductDetail(
            @PathVariable("id") Integer sanPhamId,
            @RequestParam("size") Integer sizeId,
            @RequestParam("color") Integer colorId,
            @RequestParam("quantity") Integer quantity,
            @RequestParam(value = "qrcode", required = false) String qrcode,
            @RequestParam("image") MultipartFile image,
            HttpServletRequest request,
            Model model) {

        try {
            Optional<SanPham> sanPhamOpt = sanPhamRepository.findById(sanPhamId);
            if (sanPhamOpt.isPresent()) {
                SanPham sanPham = sanPhamOpt.get();

                Optional<Size> sizeOpt = sizeRepository.findById(sizeId);
                Optional<MauSac> colorOpt = mauSacRepository.findById(colorId);

                if (sizeOpt.isEmpty() || colorOpt.isEmpty()) {
                    model.addAttribute("error", "Kích thước hoặc màu sắc không hợp lệ.");
                    return "redirect:/sanPham/" + sanPhamId + "/themChiTiet";
                }

                Size size = sizeOpt.get();
                MauSac color = colorOpt.get();

                // Kiểm tra chi tiết sản phẩm đã tồn tại
                Optional<SanPhamChiTiet> existingChiTiet = chiTietSanPhamRepository
                        .findBySanPhamAndSizeAndMauSac(sanPham, size, color);

                if (existingChiTiet.isPresent()) {
                    model.addAttribute("error", "Chi tiết sản phẩm với kích thước và màu sắc này đã tồn tại.");
                    return "redirect:/admin/productDetail/" + sanPhamId;
                }

                // Xử lý lưu file ảnh
                String uploadDir = request.getServletContext().getRealPath("/image");
                File uploadDirectory = new File(uploadDir);
                if (!uploadDirectory.exists()) {
                    uploadDirectory.mkdirs();
                }

                String fileName = image.getOriginalFilename();
                File file = new File(uploadDir, fileName);
                try {
                    image.transferTo(file);
                    sanPham.setAnh(fileName);
                } catch (IOException e) {
                    e.printStackTrace();
                    return "redirect:/admin/index?error=uploadFailed";
                }

                // Lưu chi tiết sản phẩm
                SanPhamChiTiet chiTietSanPham = new SanPhamChiTiet();
                chiTietSanPham.setSanPham(sanPham);
                chiTietSanPham.setSize(size);
                chiTietSanPham.setMauSac(color);
                chiTietSanPham.setSoLuong(quantity);
                chiTietSanPham.setQrcode(qrcode);
                chiTietSanPham.setImage(fileName);

                chiTietSanPhamRepository.save(chiTietSanPham);
                return "redirect:/admin/index";
            } else {
                model.addAttribute("error", "Sản phẩm không tồn tại.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            model.addAttribute("error", "Có lỗi xảy ra khi thêm chi tiết sản phẩm.");
        }

        return "redirect:/sanPham/" + sanPhamId + "/themChiTiet";
    }





    @GetMapping("/sanPham/{sanPhamId}/chiTiet/{chiTietId}/edit")
    public String showEditChiTiet(@PathVariable Integer sanPhamId, @PathVariable Integer chiTietId, Model model) {
        // Lấy chi tiết sản phẩm từ cơ sở dữ liệu
        Optional<SanPhamChiTiet> chiTietSanPhamOpt = chiTietSanPhamRepository.findById(chiTietId);

        // Kiểm tra xem chi tiết sản phẩm có tồn tại không
        if (chiTietSanPhamOpt.isPresent()) {
            SanPhamChiTiet chiTietSanPham = chiTietSanPhamOpt.get();
            model.addAttribute("chiTietSanPham", chiTietSanPham);

            // Lấy danh sách kích thước và màu sắc từ cơ sở dữ liệu
            List<Size> sizes = sizeRepository.findAll();
            List<MauSac> colors = mauSacRepository.findAll();
            Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
            String username = authentication.getName();

            // Lấy thông tin người dùng hiện tại
            Users userNV = authService.findUserByUsername(username);
            NhanVien nhanVien = userNV.getNhanVien();
            model.addAttribute("userNV", userNV);
            model.addAttribute("khachHang", nhanVien);
            model.addAttribute("sizes", sizes);
            model.addAttribute("colors", colors);
            model.addAttribute("sanPhamId", sanPhamId);

            return "/san_pham/suaChiTietSanPham"; // Tên file JSP cho trang sửa chi tiết
        } else {
            // Nếu không tìm thấy chi tiết sản phẩm, có thể chuyển hướng đến trang khác hoặc hiển thị thông báo lỗi
            model.addAttribute("errorMessage", "Chi tiết sản phẩm không tồn tại.");
            return "redirect:/admin/sanPham/" + sanPhamId; // Quay lại trang chi tiết sản phẩm
        }
    }

    @PostMapping("/sanPham/{sanPhamId}/chiTiet/{chiTietId}")
    public String updateChiTiet(@PathVariable Integer sanPhamId, @PathVariable Integer chiTietId,
                                @RequestParam Integer sizeId, @RequestParam Integer colorId,
                                @RequestParam int soLuong,
                                @RequestParam("image") MultipartFile imageFile,
                                HttpServletRequest request) {
        Optional<SanPhamChiTiet> chiTietSanPhamOpt = chiTietSanPhamRepository.findById(chiTietId);

        if (chiTietSanPhamOpt.isPresent()) {
            SanPhamChiTiet chiTietSanPham = chiTietSanPhamOpt.get();

            chiTietSanPham.setSize(sizeRepository.findById(sizeId).orElse(null));
            chiTietSanPham.setMauSac(mauSacRepository.findById(colorId).orElse(null));
            chiTietSanPham.setSoLuong(soLuong);

            // Xử lý lưu ảnh mới
            if (!imageFile.isEmpty()) {
                try {
                    String fileName = imageFile.getOriginalFilename();
                    String uploadDir = request.getServletContext().getRealPath("/image");
                    File uploadPath = new File(uploadDir);

                    if (!uploadPath.exists()) {
                        uploadPath.mkdirs();
                    }

                    Path filePath = Paths.get(uploadDir + fileName);
                    Files.copy(imageFile.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                    chiTietSanPham.setImage(fileName); // Lưu tên file ảnh vào cơ sở dữ liệu
                } catch (IOException e) {
                    e.printStackTrace();
                    return "redirect:/admin/productDetail/" + sanPhamId + "?error=upload_failed";
                }
            }

            chiTietSanPhamRepository.save(chiTietSanPham);
            return "redirect:/admin/productDetail/" + sanPhamId;
        } else {
            return "redirect:/admin/productDetail/" + sanPhamId + "?error=not_found";
        }
    }


    @Autowired
    private NhapHangRepository nhapHangRepository;


    @GetMapping("/nhapHang")
    public String showNhapHangForm(@RequestParam("idSanPham") Integer idSanPham, Model model) {
        SanPham sanPham = sanPhamRepository.findById(idSanPham).orElse(null);
        List<Size> listSize = sizeRepository.findAll();
        List<MauSac> listColor = mauSacRepository.findAll();
        List<SanPhamChiTiet> listChiTiet = chiTietSanPhamRepository.findBySanPhamId(idSanPham);

        model.addAttribute("sanPham", sanPham);
        model.addAttribute("listSize", listSize);
        model.addAttribute("listColor", listColor);
        model.addAttribute("listChiTiet", listChiTiet);  // Add product details to the model

        return "/san_pham/nhapHang";
    }

    @PostMapping("/sanPham/nhapHang")
    public String nhapHang(
            @RequestParam("idSanPham") Integer idSanPham,
            @RequestParam("sizeId") Integer sizeId,
            @RequestParam("colorId") Integer colorId,
            @RequestParam("soLuong") Integer soLuong,
            @RequestParam("giaNhap") BigDecimal giaNhap) {

        // Tìm sản phẩm chi tiết theo id sản phẩm, kích thước và màu sắc
        SanPhamChiTiet chiTiet = chiTietSanPhamRepository.findBySanPhamIdAndSizeIdAndMauSacId(idSanPham, sizeId, colorId);

        if (chiTiet == null) {
            // Nếu không tìm thấy, tạo mới sản phẩm chi tiết
            chiTiet = new SanPhamChiTiet();
            chiTiet.setSanPham(sanPhamRepository.findById(idSanPham).orElseThrow(() ->
                    new IllegalArgumentException("Không tìm thấy sản phẩm!")));
            chiTiet.setSize(sizeRepository.findById(sizeId).orElseThrow(() ->
                    new IllegalArgumentException("Không tìm thấy kích thước!")));
            chiTiet.setMauSac(mauSacRepository.findById(colorId).orElseThrow(() ->
                    new IllegalArgumentException("Không tìm thấy màu sắc!")));
            chiTiet.setSoLuong(soLuong); // Đặt số lượng nhập ban đầu
//            chiTiet.setGiaNhap(giaNhap); // Giá nhập ban đầu (tùy chọn nếu bạn muốn lưu)
        } else {
            // Nếu đã tồn tại, cập nhật số lượng
            chiTiet.setSoLuong(chiTiet.getSoLuong() + soLuong);
        }

        // Lưu sản phẩm chi tiết vào cơ sở dữ liệu
        chiTietSanPhamRepository.save(chiTiet);

        // Lưu lịch sử nhập hàng
        NhapHang nhapHang = new NhapHang();
        nhapHang.setChiTietsp(chiTiet);
        nhapHang.setSoLuong(soLuong);
        nhapHang.setGiaNhap(giaNhap);
        nhapHang.setNgayNhap(new Date());
        nhapHangRepository.save(nhapHang);

        return "redirect:/admin/productDetail/" + idSanPham;
    }

    @GetMapping("/lichSuNhapHang")
    private String showLichSuNhapHang(Model model) {
        List<NhapHang> dm = nhapHangRepository.findAll();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);
        model.addAttribute("listNhapHang", dm);
        return "/san_pham/lichSuNhaphang";
    }

    @GetMapping("/check-ma")
    public ResponseEntity<Boolean> checkMaSanPham(@RequestParam("ma") String ma) {

        boolean exists = sanPhamRepository.existsByMa(ma);
        return ResponseEntity.ok(exists);
    }

    @GetMapping("/sanPham/{sanPhamId}/chiTiet/{chiTietId}/delete")
    public String deleteChiTietSanPham(@PathVariable("sanPhamId") Integer sanPhamId,
                                       @PathVariable("chiTietId") Integer chiTietId,
                                       RedirectAttributes redirectAttributes) {
        try {
            // Xóa chi tiết sản phẩm theo ID
            chiTietSanPhamRepository.deleteById(chiTietId);

            // Thêm thông báo thành công
            redirectAttributes.addFlashAttribute("successMessage", "Xóa chi tiết sản phẩm thành công");
        } catch (Exception e) {
            // Thêm thông báo lỗi nếu có lỗi xảy ra
            redirectAttributes.addFlashAttribute("errorMessage", "Có lỗi xảy ra khi xóa chi tiết sản phẩm");
        }

        // Quay lại trang chi tiết sản phẩm
        return "redirect:/admin/productDetail/" + sanPhamId;
    }

}

package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.service.AuthService;
import com.example.datn_sd_78.service.ThongKeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.time.LocalDate;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class ThongKeController {

    @Autowired
    private ThongKeService thongKeService;
    @Autowired
    private AuthService authService;

    @GetMapping("/thong-ke")
    public String thongKe(Model model,
                          @RequestParam(required = false) Integer year,
                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate startDate,
                          @RequestParam(required = false) @DateTimeFormat(pattern = "yyyy-MM-dd") LocalDate endDate) {

        // Nếu startDate và endDate không có giá trị, gán mặc định là ngày hôm nay
        if (startDate == null) {
            startDate = LocalDate.now();
        }
        if (endDate == null) {
            endDate = LocalDate.now();
        }
        List<Object[]> topCustomers = thongKeService.getTopCustomersBySales();
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        String username = authentication.getName();

        // Lấy thông tin người dùng hiện tại
        Users userNV = authService.findUserByUsername(username);
        NhanVien nhanVien = userNV.getNhanVien();
        model.addAttribute("userNV", userNV);
        model.addAttribute("khachHang", nhanVien);

        // Thêm dữ liệu vào model để hiển thị trên view
        model.addAttribute("topCustomers", topCustomers);
        // Thêm các thông tin thống kê vào model
        model.addAttribute("soLuongDaBan", thongKeService.getSoLuongDaBan(startDate, endDate));
        model.addAttribute("tongDoanhThu", thongKeService.getTongDoanhThu(startDate, endDate));
        model.addAttribute("tongHoaDon", thongKeService.getTongHoaDon(startDate, endDate));
        model.addAttribute("doanhThuTrongNgay", thongKeService.getDoanhThuTrongNgay());
        model.addAttribute("topSellingProducts", thongKeService.getTopSellingProducts());
        model.addAttribute("tongHoaDonHuy", thongKeService.getTongHoaDonHuy(startDate, endDate));
        model.addAttribute("doanhThuTrongKhoangNgay", thongKeService.getDoanhThuTrongKhoangNgay(startDate, endDate));
        model.addAttribute("tongHoaDonTrongKhoangNgay", thongKeService.getTongHoaDonTrongKhoangNgay(startDate, endDate));
        model.addAttribute("doanhThuTheoThang", thongKeService.getDoanhThuTheoThang(year != null ? year : 2024));
        model.addAttribute("sanPhamTonKho", thongKeService.getSanPhamTonKho());

        return "thongke/thongke";
    }
}

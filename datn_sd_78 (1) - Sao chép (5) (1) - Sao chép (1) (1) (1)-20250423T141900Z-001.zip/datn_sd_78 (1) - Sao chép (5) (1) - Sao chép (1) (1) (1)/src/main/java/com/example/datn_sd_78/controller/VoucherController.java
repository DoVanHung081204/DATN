package com.example.datn_sd_78.controller;

import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.KhachHangVoucher;
import com.example.datn_sd_78.entity.KhachHangVoucherId;
import com.example.datn_sd_78.entity.Voucher;
import com.example.datn_sd_78.repository.KhachHangRepository;
import com.example.datn_sd_78.repository.KhachHangVoucherRepository;
import com.example.datn_sd_78.repository.VoucherRepository;
import com.example.datn_sd_78.service.EmailService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Controller
@RequestMapping("/voucher")
public class VoucherController {

    @Autowired
    private VoucherRepository voucherRepository;

    @Autowired
    private KhachHangRepository khachHangRepository;

    @Autowired
    private KhachHangVoucherRepository khachHangVoucherRepository;

    @Autowired
    private EmailService emailService;

    // Hiển thị form
    @GetMapping
    public String showForm(
            @RequestParam(value = "searchName", required = false) String searchName,
            @RequestParam(value = "genderFilter", required = false) Integer genderFilter,
            @RequestParam(value = "page", defaultValue = "0") int page, // Page number (0-based index)
            @RequestParam(value = "size", defaultValue = "8") int size, // Number of items per page
            Model model) {

        Page<KhachHang> customersPage; // Using Page instead of List for pagination

        Pageable pageable = PageRequest.of(page, size); // Create Pageable object

        if (searchName != null && !searchName.isEmpty() && genderFilter != null) {
            // Search by customer name and filter by gender
            customersPage = khachHangRepository.findByHoTenContainingIgnoreCaseAndGioiTinh(searchName, genderFilter, pageable);
        } else if (searchName != null && !searchName.isEmpty()) {
            // Search by customer name only
            customersPage = khachHangRepository.findByHoTenContainingIgnoreCase(searchName, pageable);
        } else if (genderFilter != null) {
            // Filter by gender only
            customersPage = khachHangRepository.findByGioiTinh(genderFilter, pageable);
        } else {
            // Show all customers if no search/filter is applied
            customersPage = khachHangRepository.findAll(pageable);
        }

        model.addAttribute("customers", customersPage.getContent()); // Add paginated data
        model.addAttribute("currentPage", page); // Current page number
        model.addAttribute("totalPages", customersPage.getTotalPages()); // Total number of pages
        return "voucher/create_voucher";
    }


    @PostMapping("/create")
    @ResponseBody
    public ResponseEntity<?> createVoucher(
            @RequestParam String ten,
            @RequestParam String ma,
            @RequestParam BigDecimal giaTriGiam,
            @RequestParam BigDecimal giaTriDonHangToiThieu,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date ngayBatDau,
            @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date ngayKetThuc,
            @RequestParam(required = false) List<Integer> customerIds,
            @RequestParam String lyDo,
            @RequestParam String ghiChu) {

        // Kiểm tra danh sách khách hàng
        if (ngayKetThuc.before(ngayBatDau)) {
            return ResponseEntity.badRequest().body("Ngày kết thúc phải lớn hơn ngày bắt đầu.");
        }
        if (lyDo==null || lyDo.isEmpty()) {
            return ResponseEntity.badRequest().body("Vui lòng nhập lý do tạo Voucher");
        }
        if (ghiChu==null || ghiChu.isEmpty()) {
            return ResponseEntity.badRequest().body("Vui lòng nhập ghi chú gửi đến khách hanàng");
        }
        if (customerIds == null || customerIds.isEmpty()) {
            return ResponseEntity.badRequest().body("Vui lòng chọn ít nhất một khách hàng.");
        }

        if (customerIds == null || customerIds.isEmpty()) {
            return ResponseEntity.badRequest().body("Vui lòng chọn ít nhất một khách hàng.");
        }

        // Tạo đối tượng Voucher
        Voucher voucher = new Voucher();
        voucher.setTen(ten);
        voucher.setMa(ma);
        voucher.setGiaTriGiam(giaTriGiam);
        voucher.setGiaTriDonHangToiThieu(giaTriDonHangToiThieu);
        voucher.setNgayBatDau(ngayBatDau);
        voucher.setNgayKetThuc(ngayKetThuc);
        voucher.setTrangThai(0); // Trạng thái mặc định "Còn hiệu lực"
        voucher.setLyDo(lyDo);

        // Lưu voucher vào cơ sở dữ liệu
        voucher = voucherRepository.save(voucher);

        // Lấy danh sách khách hàng từ customerIds
        List<KhachHang> customers = khachHangRepository.findAllById(customerIds);

        // Liên kết khách hàng với voucher
        for (KhachHang customer : customers) {
            KhachHangVoucher khachHangVoucher = new KhachHangVoucher();
            KhachHangVoucherId id = new KhachHangVoucherId();
            id.setKhachHangId(customer.getId());
            id.setVoucherId(voucher.getId());
            khachHangVoucher.setId(id);
            khachHangVoucher.setKhachHang(customer);
            khachHangVoucher.setVoucher(voucher);
            khachHangVoucher.setTrangThai(0); // Trạng thái "Còn hiệu lực"
            khachHangVoucher.setGhiChu(ghiChu);
            emailService.chucMungKhachHang(khachHangVoucher.getKhachHang().getUser().getEmail(),ghiChu,ma);
            khachHangVoucherRepository.save(khachHangVoucher);

        }
        return ResponseEntity.ok("Voucher đã được tạo thành công!");
    }

    @GetMapping("/list")
    public String showVoucherList(@RequestParam(value = "search", required = false) String search,
                                  @RequestParam(value = "page", defaultValue = "0") int page,
                                  @RequestParam(value = "size", defaultValue = "8") int size,
                                  Model model) {
        Pageable pageable = PageRequest.of(page, size);
        Page<Voucher> voucherPage;

        if (search != null && !search.isEmpty()) {
            voucherPage = voucherRepository.findByTenContainingIgnoreCase(search, pageable);
        } else {
            voucherPage = voucherRepository.findAll(pageable);
        }

        // Convert Page<Voucher> to List<Voucher>
        List<Voucher> vouchers = voucherPage.getContent();

        model.addAttribute("vouchers", vouchers);
        model.addAttribute("search", search);
        model.addAttribute("currentPage", page);
        model.addAttribute("totalPages", voucherPage.getTotalPages());
        return "voucher/voucher_list";
    }


    @GetMapping("/edit/{id}")
    public String showEditForm(@PathVariable("id") Integer id, Model model) {
        // Tìm voucher theo id
        Voucher voucher = voucherRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid voucher ID: " + id));

        model.addAttribute("voucher", voucher);  // Thêm voucher vào model để hiển thị trên form sửa
        return "voucher/edit_voucher";  // Trả về view sửa voucher
    }

    @PostMapping("/edit/{id}")
    public String editVoucher(@PathVariable("id") Integer id,
                              @RequestParam String ten,
                              @RequestParam String ma,
                              @RequestParam BigDecimal giaTriGiam,
                              @RequestParam BigDecimal giaTriDonHangToiThieu,
                              @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date ngayBatDau,
                              @RequestParam @DateTimeFormat(pattern = "yyyy-MM-dd") Date ngayKetThuc) {
        // Tìm voucher cần sửa
        Voucher voucher = voucherRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid voucher ID: " + id));

        // Cập nhật thông tin voucher
        voucher.setTen(ten);
        voucher.setMa(ma);
        voucher.setGiaTriGiam(giaTriGiam);
        voucher.setGiaTriDonHangToiThieu(giaTriDonHangToiThieu);
        voucher.setNgayBatDau(ngayBatDau);
        voucher.setNgayKetThuc(ngayKetThuc);

        // Lưu lại voucher đã cập nhật
        voucherRepository.save(voucher);

        return "redirect:/voucher/list";  // Sau khi sửa xong, quay lại danh sách voucher
    }

    @GetMapping("/delete/{id}")
    public String deleteVoucher(@PathVariable("id") Integer id) {
        // Tìm voucher theo id và xóa
        Voucher voucher = voucherRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Invalid voucher ID: " + id));
        voucherRepository.delete(voucher);

        return "redirect:/voucher/list";  // Sau khi xóa xong, quay lại danh sách voucher
    }


}


package com.example.datn_sd_78.entity;
import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;

@Entity
@Table(name = "ctsp_khuyen_mai")
@Data
public class CtspKhuyenMai {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @ManyToOne
    @JoinColumn(name = "id_san_pham", nullable = false)
    private SanPham sanPham;

    @ManyToOne
    @JoinColumn(name = "id_khuyen_mai", nullable = false)
    private KhuyenMai khuyenMai;

    @Column(name = "loai_giam_gia", nullable = false)
    private Boolean loaiGiamGia;

    @Column(name = "muc_giam", nullable = false, precision = 18, scale = 2)
    private BigDecimal mucGiam;

    @Column(name = "trang_thai", nullable = false)
    private Integer trangThai;

    @Column(name = "don_gia_sau_khi_giam", precision = 18, scale = 2)
    private BigDecimal donGiaSauKhiGiam;
}

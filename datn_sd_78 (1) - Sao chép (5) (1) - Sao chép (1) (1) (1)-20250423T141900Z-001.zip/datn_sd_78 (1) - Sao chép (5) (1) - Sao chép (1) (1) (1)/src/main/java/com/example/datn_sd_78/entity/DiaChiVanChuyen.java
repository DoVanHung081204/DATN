package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "dia_chi_van_chuyen")
public class DiaChiVanChuyen {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_dia_chi_van_chuyen")
    private Integer idDiaChiVanChuyen;

    @Column(name = "dia_chi_cu_the", nullable = false, length = 100)
    private String diaChiCuThe;

    @Column(name = "ngay_tao")
    @Temporal(TemporalType.DATE)
    private Date ngayTao;

    @Column(name = "ngay_cap_nhat")
    @Temporal(TemporalType.DATE)
    private Date ngayCapNhat;

    @Column(name = "trang_thai")
    private Boolean trangThai;

    @Column(name = "mo_ta", columnDefinition = "TEXT")
    private String moTa;

    @ManyToOne
    @JoinColumn(name = "id_tinh", nullable = false)
    private Tinh tinh;

    @ManyToOne
    @JoinColumn(name = "id_huyen", nullable = false)
    private Huyen huyen;

    @ManyToOne
    @JoinColumn(name = "id_xa", nullable = false)
    private Xa xa;

    @ManyToOne
    @JoinColumn(name = "khach_hang_id", nullable = false)
    private KhachHang khachHang;

    // Getter, Setter, Constructor
}

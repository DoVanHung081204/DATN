package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.Data;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;

@Data
@Entity
@Table(name = "HoaDon")
public class HoaDon {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "diaChi")
    private String diaChi;

    @Column(name = "hoTen")
    private String hoTen;

    @Column(name = "sdt")
    private String sdt;

    @Column(name = "ngayTao")
    private LocalDateTime ngayTao;

    @Column(name = "ngay_nhan_hang")
    private LocalDateTime ngayNhanHang;

    @Column(name = "ngay_thanh_toan")
    private LocalDateTime ngayThanhToan;

    @Column(name = "moTa")
    private String moTa;

    @Column(name = "tienShip", precision = 18, scale = 2)
    private BigDecimal tienShip;

    @Column(name = "tienHang", precision = 18, scale = 2)
    private BigDecimal tienHang;

    @Column(name = "tongTien", precision = 18, scale = 2)
    private BigDecimal tongTien;

    @Column(name = "tienGiam", precision = 18, scale = 2)
    private BigDecimal tienGiam;

    @ManyToOne
    @JoinColumn(name = "trangThai", referencedColumnName = "id")
    private TrangThaiHoaDon trangThai; // Liên kết với bảng TrangThai

    @Column(name = "loaiHoaDon")
    private Boolean loaiHoaDon;


    @Column(name = "phuongThucThanhToan")
    private Boolean phuongThucThanhToan;


    @Column(name = "hinhThucNhanHang")
    private Boolean hinhThucNhanHang;

    @ManyToOne
    @JoinColumn(name = "idNhanVien")
    private NhanVien nhanVien;

    @ManyToOne
    @JoinColumn(name = "idKhachHang")
    private KhachHang khachHang;

    @Column(name = "lyDoHuy")
    private String lyDoHuy;

    @Column(name = "Id_dia_chi_van_chuyen")
    private Integer diaChiVanChuyen;

    @Column(name = "trangThaiThanhToan")
    private Boolean trangThaiThanhToan;

    @OneToMany(mappedBy = "hoaDon", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private List<HoaDonChiTiet> hoaDonChiTiet;

    @ManyToOne
    @JoinColumn(name = "idVoucher")
    private Voucher voucher;  // Liên kết với bảng Voucher

    public String getFormattedDateTime() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        return ngayTao != null ? ngayTao.format(formatter) : "";
    }

}

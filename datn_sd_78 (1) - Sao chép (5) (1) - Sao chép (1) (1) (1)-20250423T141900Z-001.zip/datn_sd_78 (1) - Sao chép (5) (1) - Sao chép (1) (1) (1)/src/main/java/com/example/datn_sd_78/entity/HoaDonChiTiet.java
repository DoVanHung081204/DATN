package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.List;

@Entity
@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "HoaDonChiTiet")
public class HoaDonChiTiet {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "donGia", precision = 18, scale = 2, nullable = false)
    private BigDecimal donGia;

    @Column(name = "soLuong", nullable = false)
    private Integer soLuong;

    @ManyToOne
    @JoinColumn(name = "idHoaDon", nullable = false) // Liên kết với bảng Hóa Đơn
    private HoaDon hoaDon;

    @ManyToOne
    @JoinColumn(name = "idCTSP", nullable = false) // Liên kết với bảng Chi Tiết Sản Phẩm
    private SanPhamChiTiet chiTietSanPham;

    @ManyToOne
    @JoinColumn(name = "id_trangThai")
    private TrangThaiHoaDonChiTiet trangThai;

    @Column(name = "lyDoHuy", length = 500)
    private String lyDoHuy;

    // Tính tổng tiền
    public BigDecimal getTongTien() {
        if (donGia != null && soLuong != null) {
            return donGia.multiply(new BigDecimal(soLuong));
        }
        return BigDecimal.ZERO;
    }
}

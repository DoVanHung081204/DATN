package com.example.datn_sd_78.entity;



import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;



@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class HoaDondto {
    private List<SanPhamChiTiet> sanPhamChiTiets = new ArrayList<>();

    private Integer id;

    private String diaChi;


    private String hoTen;


    private String sdt;


    private LocalDateTime ngayTao;


    private Date ngayNhanHang;


    private LocalDateTime ngayThanhToan;


    private String moTa;


    private BigDecimal tongTien;


    private TrangThaiHoaDon trangThai; // Liên kết với bảng TrangThai

    private Boolean loaiHoaDon;

    private Integer soLuong;

    private Boolean phuongThucThanhToan;


    private Boolean hinhThucNhanHang;


    private NhanVien nhanVien;

    private KhachHang khachHang;


    public List<SanPhamChiTiet> getSanPhamChiTiets() {
        return sanPhamChiTiets;
    }

}

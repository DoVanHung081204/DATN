package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "Khach_Hang_Voucher")
public class KhachHangVoucher {
    @EmbeddedId
    private KhachHangVoucherId id; // Composite key (khach_hang_id, voucher_id)

    @Column(name = "trang_thai")
    private Integer trangThai;

    @Column(name = "ghi_chu")
    private String ghiChu;

    @ManyToOne
    @MapsId("khachHangId")  // Tạo liên kết với KhachHang
    @JoinColumn(name = "khach_hang_id", insertable = false, updatable = false)
    private KhachHang khachHang;

    @ManyToOne
    @MapsId("voucherId")  // Tạo liên kết với Voucher
    @JoinColumn(name = "voucher_id", insertable = false, updatable = false)
    private Voucher voucher;
}

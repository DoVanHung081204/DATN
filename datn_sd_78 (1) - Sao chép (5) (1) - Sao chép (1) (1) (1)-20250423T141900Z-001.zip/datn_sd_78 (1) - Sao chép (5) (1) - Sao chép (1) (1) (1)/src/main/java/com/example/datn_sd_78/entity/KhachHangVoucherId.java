package com.example.datn_sd_78.entity;


import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Embeddable
@AllArgsConstructor
@NoArgsConstructor
@Getter
@Setter
public class KhachHangVoucherId {

    @Column(name = "khach_hang_id")
    private Integer khachHangId;

    @Column(name = "voucher_id")
    private Integer voucherId;
}

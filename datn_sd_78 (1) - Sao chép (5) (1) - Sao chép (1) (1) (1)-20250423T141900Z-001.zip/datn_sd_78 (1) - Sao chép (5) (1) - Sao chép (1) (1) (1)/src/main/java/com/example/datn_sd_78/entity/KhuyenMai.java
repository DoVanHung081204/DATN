package com.example.datn_sd_78.entity;
import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.Nationalized;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "KhuyenMai")
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class KhuyenMai {
    @Id
    @Column(name = "id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ma", unique = true)
    private String ma;

    @Column(name = "ten")
    private String ten;

    @Column(name = "ngay_bat_dau")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Định dạng ngày tháng
    private Date ngayBatDau;

    @Column(name = "ngay_ket_thuc")
    @DateTimeFormat(pattern = "yyyy-MM-dd") // Định dạng ngày tháng
    private Date ngayKetThuc;

    @Column(name = "mo_ta", length = 500)
    @Nationalized
    private String moTa;

    @Column(name = "trang_thai")
    private Integer trangThai; // 0: Không hoạt động, 1: Hoạt động

    @Column(name = "loai_giam_gia")
    private Boolean loaiGiamGia; // true: Giảm %; false: Giảm VND

    @Column(name = "muc_giam")
    private BigDecimal mucGiam; // Thêm thuộc tính mức giảm

    public BigDecimal getMucGiam() {
        return mucGiam;
    }
}

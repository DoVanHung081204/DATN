package com.example.datn_sd_78.entity;



import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;
@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "nhan_vien")
public class NhanVien {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "gioi_tinh")
    private Integer gioiTinh;

    @Column(name = "cccd", length = 255)
    private String cccd;

    @Column(name = "dia_chi", length = 255)
    private String diaChi;

    @Column(name = "email", length = 255)
    private String email;

    @Column(name = "ma_nhan_vien", length = 255)
    private String maNhanVien;

    @Column(name = "quoc_tinh", length = 255)
    private String quocTinh;

    @Column(name = "sdt", length = 15, nullable = false)
    private String sdt;

    @Column(name = "ten_nhan_vien", length = 255)
    private String tenNhanVien;

    @Column(name = "trang_thai")
    private Integer trangThai;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private Users user;
}
package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "TrangThai")
public class TrangThaiHoaDon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(name = "ten")
    private String ten; // Tên trạng thái
}

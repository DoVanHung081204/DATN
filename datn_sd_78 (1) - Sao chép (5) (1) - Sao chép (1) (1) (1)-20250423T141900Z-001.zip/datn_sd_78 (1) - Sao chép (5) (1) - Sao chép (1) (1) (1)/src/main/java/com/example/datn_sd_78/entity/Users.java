package com.example.datn_sd_78.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Date;

@Entity
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "Users")
public class Users {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    @Column(name = "tai_khoan", length = 255, unique = true, nullable = false)
    private String taiKhoan;

    @Column(name = "mat_khau", length = 255, nullable = false)
    private String matKhau;

    @Column(name = "email", length = 255, nullable = false)
    private String email;

    @Column(name = "trang_thai")
    private Integer trangThai;

    @ManyToOne
    @JoinColumn(name = "id_vai_tro", nullable = false)
    private VaiTro vaiTro;

    @Column(name = "ngay_tao", nullable = false)
    private Date ngayTao;
    @Column(name = "reset_token", length = 255)
    private String resetToken;

    @Column(name = "reset_token_expiration")
    private Date resetTokenExpiration; // Thời gian hết hạn token (tùy chọn)
    @Column(name = "ngay_sua")
    private Date ngaySua;
    @OneToOne(mappedBy = "user")
    private NhanVien nhanVien; // Mối quan hệ 1-1 với NhanVien
    @OneToOne(mappedBy = "user")
    private KhachHang khachHang; // Mối quan hệ 1-1 với NhanVien
}
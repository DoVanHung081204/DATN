package com.example.datn_sd_78.reponse;
import lombok.Data;

@Data
public class ResponseDTO {
    private int total;
    // Thêm các trường khác nếu cần
    private ResponseDTO data;
    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }
}

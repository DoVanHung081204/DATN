package com.example.datn_sd_78.repository;


import com.example.datn_sd_78.entity.Anh;
import com.example.datn_sd_78.entity.SanPham;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface AnhRepository extends JpaRepository<Anh, Integer> {
    List<Anh> findBySanPham(SanPham sanPham); // Tìm ảnh theo sản phẩm
}

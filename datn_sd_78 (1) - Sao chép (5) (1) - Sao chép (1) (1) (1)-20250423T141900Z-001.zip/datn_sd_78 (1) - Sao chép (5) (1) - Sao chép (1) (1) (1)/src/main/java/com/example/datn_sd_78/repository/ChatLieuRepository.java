package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.ChatLieu;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ChatLieuRepository extends JpaRepository<ChatLieu, Integer> {
}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.MauSac;
import com.example.datn_sd_78.entity.SanPham;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.entity.Size;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface ChiTietSanPhamRepository extends JpaRepository<SanPhamChiTiet, Integer> {
    List<SanPhamChiTiet> findBySanPhamId(Integer id); // Sử dụng tên thuộc tính trong entity

    @Query("SELECT COALESCE(SUM(ct.soLuong), 0) FROM SanPhamChiTiet ct WHERE ct.sanPham.id = :idsanpham")
    int sumQuantityBySanPhamId(@Param("idsanpham") int idsanpham);

    @Query("SELECT ct FROM SanPhamChiTiet ct WHERE ct.sanPham.id = :id AND ct.mauSac.ten = :mauSac AND ct.size.ten = :size")
    SanPhamChiTiet findVariantByColorAndSize(@Param("id") Integer id, @Param("mauSac") String mauSac, @Param("size") String size);


    @Query("SELECT ct FROM SanPhamChiTiet ct WHERE ct.sanPham.id = :id AND ct.size.id = :sizeId AND ct.mauSac.id = :mauSacId")
    SanPhamChiTiet findBySanPhamIdAndSizeIdAndMauSacId(@Param("id") int id, @Param("sizeId") int sizeId, @Param("mauSacId") int mauSacId);

    @Query("SELECT COALESCE(SUM(ct.soLuong), 0) FROM SanPhamChiTiet ct WHERE ct.sanPham.id = :idsanpham AND ct.mauSac.id = :mauSacId AND ct.size.id = :sizeId")
    int sumQuantityBySanPhamIdAndColorAndSize(@Param("idsanpham") int idsanpham, @Param("mauSacId") int mauSacId, @Param("sizeId") int sizeId);


    @Query("SELECT spct FROM SanPhamChiTiet spct WHERE spct.soLuong > 0")
    Page<SanPhamChiTiet> getDanhSach(Pageable pageable);

    // Phương thức tìm kiếm sản phẩm theo tên
    @Query("SELECT spct FROM SanPhamChiTiet spct WHERE " +
            "(:keyword IS NULL OR spct.sanPham.ten LIKE %:keyword%) AND " +
            "(:colorId IS NULL OR spct.mauSac.id = :colorId) AND " +
            "(:sizeId IS NULL OR spct.size.id = :sizeId)")
    Page<SanPhamChiTiet> filterSanPham(
            @Param("keyword") String keyword,
            @Param("colorId") Long colorId,
            @Param("sizeId") Long sizeId,
            Pageable pageable);

    Optional<SanPhamChiTiet> findBySanPhamAndSizeAndMauSac(SanPham sanPham, Size size, MauSac mauSac);

}

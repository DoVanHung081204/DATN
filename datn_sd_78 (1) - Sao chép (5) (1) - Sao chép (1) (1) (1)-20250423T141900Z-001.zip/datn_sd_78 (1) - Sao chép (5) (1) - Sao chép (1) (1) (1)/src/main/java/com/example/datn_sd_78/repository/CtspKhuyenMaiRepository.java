package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.CtspKhuyenMai;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CtspKhuyenMaiRepository extends JpaRepository<CtspKhuyenMai, Integer> {
    boolean existsBySanPhamId(Integer sanPhamId); // Phương thức kiểm tra xem sản phẩm có khuyến mại không
    List<CtspKhuyenMai> findByKhuyenMaiId(Integer khuyenMaiId);
    List<CtspKhuyenMai> findBySanPhamId(Integer sanPhamId);

    @Query("SELECT c FROM CtspKhuyenMai c WHERE c.sanPham.id = :productId AND c.khuyenMai.trangThai = 1 AND c.khuyenMai.ngayKetThuc >= CURRENT_DATE")
    CtspKhuyenMai findActivePromotionByProductId(@Param("productId") Integer productId);
}

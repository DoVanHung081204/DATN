package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.DanhMuc;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DanhMucRepository extends JpaRepository<DanhMuc, Integer> {
    Page<DanhMuc> findAll(Pageable pageable);
}

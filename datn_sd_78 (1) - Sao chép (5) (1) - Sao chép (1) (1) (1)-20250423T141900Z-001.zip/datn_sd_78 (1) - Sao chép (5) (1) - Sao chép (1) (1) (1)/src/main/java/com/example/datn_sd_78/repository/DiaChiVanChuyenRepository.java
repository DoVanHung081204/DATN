package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.DiaChiVanChuyen;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface DiaChiVanChuyenRepository extends JpaRepository<DiaChiVanChuyen, Integer> {
    Optional<DiaChiVanChuyen> findByIdDiaChiVanChuyen(Integer idDiaChiVanChuyen);
}


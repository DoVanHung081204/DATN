package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.GioHang;
import com.example.datn_sd_78.entity.GioHangChiTiet;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface GioHangChiTietRespository extends JpaRepository<GioHangChiTiet,Integer> {
    @Query("SELECT g FROM GioHangChiTiet g WHERE g.gioHang.id = :gioHangId AND g.chiTietSanPham.id = :sanPhamId")
    GioHangChiTiet findByGioHangIdAndSanPhamId(@Param("gioHangId") Integer gioHangId, @Param("sanPhamId") Integer sanPhamId);

    List<GioHangChiTiet> findByGioHang(GioHang gioHang);

    List<GioHangChiTiet> findByGioHangId(Integer gioHangId);

    @Transactional
    void deleteByGioHang(GioHang gioHang);


}

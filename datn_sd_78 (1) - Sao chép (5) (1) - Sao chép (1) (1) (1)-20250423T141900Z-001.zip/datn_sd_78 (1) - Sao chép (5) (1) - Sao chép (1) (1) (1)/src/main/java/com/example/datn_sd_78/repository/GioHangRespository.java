package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.GioHang;
import com.example.datn_sd_78.entity.KhachHang;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface GioHangRespository extends JpaRepository<GioHang,Integer> {
    Optional<GioHang> findByKhachHang(KhachHang khachHang);
    void deleteById(Integer id);
}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.HoaDon;

import com.example.datn_sd_78.entity.HoaDonChiTiet;
import jakarta.transaction.Transactional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface HoaDonChiTietRepository extends JpaRepository<HoaDonChiTiet, Integer> {
    @Query(value = "SELECT * FROM HoaDonChiTiet WHERE idHoaDon = :idHoaDon", nativeQuery = true)
    List<HoaDonChiTiet> lstHoaDonChiTiet(@Param("idHoaDon") int idHoaDon);

    @Modifying
    @Transactional
    @Query(value = "INSERT INTO HoaDonChiTiet(idCTSP, soLuong, donGia, idHoaDon) VALUES (?,?,?,?)", nativeQuery = true)
    int insertHoaDonChiTiet(int idctsp, int soLuong, BigDecimal donGia, int idHoaDon);

    List<HoaDonChiTiet> findByHoaDon_Id(Integer id);

    List<HoaDonChiTiet> findByHoaDonId(Integer hoaDonId);
    //Thống kê
    @Query("SELECT COUNT(hd) FROM HoaDon hd WHERE hd.trangThai.id = 8 " +
            "AND CAST(hd.ngayThanhToan AS date) BETWEEN :startDate AND :endDate")
    Long getTongHoaDonHuy(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT SUM(hd.tongTien) FROM HoaDon hd WHERE CAST(hd.ngayThanhToan AS date) BETWEEN :startDate AND :endDate AND hd.trangThai.id = 7")
    BigDecimal getDoanhThuTrongKhoangNgay(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT COUNT(hd) FROM HoaDon hd WHERE CAST(hd.ngayThanhToan AS date) BETWEEN :startDate AND :endDate AND hd.trangThai.id = 7")
    Long getTongHoaDonTrongKhoangNgay(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    @Query("SELECT SUM(hdt.soLuong) FROM HoaDonChiTiet hdt " +
            "JOIN HoaDon hd ON hdt.hoaDon.id = hd.id " +
            "WHERE CAST(hd.ngayThanhToan AS date) BETWEEN :startDate AND :endDate " +
            "AND hd.trangThai.id = 7")
    Long getSoLuongDaBan(@Param("startDate") LocalDate startDate, @Param("endDate") LocalDate endDate);

    // Doanh thu trong ngày
//        @Query("SELECT hdt.donGia, hdt.soLuong FROM HoaDonChiTiet hdt WHERE hdt.hoaDon.trangThai.id = 5 AND hdt.hoaDon.ngayThanhToan = CURRENT_DATE")
//        List<Object[]> getDoanhThuTrongNgayData();

    // Sản phẩm bán chạy nhất
    @Query("SELECT sp.ten, ctsp.sanPham.id, SUM(hdt.soLuong), SUM(hdt.soLuong * hdt.donGia) " +
            "FROM HoaDonChiTiet hdt " +
            "JOIN hdt.chiTietSanPham ctsp " +
            "JOIN ctsp.sanPham sp " +
            "WHERE hdt.hoaDon.trangThai.id = 7 " +
            "GROUP BY ctsp.sanPham.id, sp.ten " +
            "ORDER BY SUM(hdt.soLuong) DESC")
    List<Object[]> getTopSellingProducts();



    // Tổng số hóa đơn hủy
    @Query("SELECT COUNT(hd) FROM HoaDon hd WHERE hd.trangThai.id = 8")
    Long getTongHoaDonHuy();

    // Doanh thu theo tháng
    @Query("SELECT EXTRACT(MONTH FROM hd.ngayThanhToan), SUM(hd.tongTien) " +
            "FROM HoaDon hd " +
            "WHERE EXTRACT(YEAR FROM hd.ngayThanhToan) = :year AND hd.trangThai.id = 7 " +
            "GROUP BY EXTRACT(MONTH FROM hd.ngayThanhToan) " +
            "ORDER BY EXTRACT(MONTH FROM hd.ngayThanhToan)")
    List<Object[]> getDoanhThuTheoThang(@Param("year") int year);



    // Sản phẩm tồn kho
    @Query("SELECT sp.id, sp.ten, SUM(ctsp.soLuong) " +
            "FROM SanPham sp " +
            "JOIN SanPhamChiTiet ctsp ON sp.id = ctsp.sanPham.id " +
            "GROUP BY sp.id, sp.ten " +
            "HAVING SUM(ctsp.soLuong) > 0 " +   // Chỉ hiển thị sản phẩm có số lượng > 0
            "ORDER BY SUM(ctsp.soLuong) DESC")
    List<Object[]> getSanPhamTonKho();
//    @Query("SELECT sp.id AS sanPhamId, sp.ten AS tenSanPham, ctsp.id AS sizeId, s.ten AS tenSize, " +
//            "ctsp.id AS mauSacId, ms.ten AS tenMauSac, SUM(ctsp.soLuong) AS soLuongTon " +
//            "FROM SanPham sp " +
//            "JOIN SanPhamChiTiet ctsp ON sp.id = ctsp.sanPham.id " +
//            "JOIN Size s ON ctsp.id = s.id " +
//            "JOIN MauSac ms ON ctsp.id = ms.id " +
//            "GROUP BY sp.id, sp.ten, ctsp.id, s.ten, ctsp.id, ms.ten " +
//            "HAVING SUM(ctsp.soLuong) > 0 " +
//            "ORDER BY soLuongTon DESC")
//    List<Object[]> getSanPhamTonKho();

    List<HoaDonChiTiet> findByHoaDon(HoaDon hoaDon);

}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.TrangThaiHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.time.LocalDateTime;
import java.util.List;

public interface HoaDonRepository extends JpaRepository<HoaDon, Integer> {
    @Query("SELECT h FROM HoaDon h WHERE h.trangThai.id = 9 ORDER BY h.ngayTao DESC")
    List<HoaDon> findAllHoaDon();

    @Query("SELECT h FROM HoaDon h ORDER BY h.ngayTao DESC")
    List<HoaDon> hihi();

    Iterable<HoaDon> findByHoTenContaining(String hoTen);

    // Lấy tất cả đơn hàng
    List<HoaDon> findAll();

    @Query("SELECT h FROM HoaDon h WHERE " +
            "(:search IS NULL OR h.hoTen LIKE %:search%) AND " +
            "(:status IS NULL OR h.trangThai.ten = :status) AND " +
            "(:startDate IS NULL OR h.ngayTao >= :startDate) AND " +
            "(:endDate IS NULL OR h.ngayTao <= :endDate)")
    List<HoaDon> searchAndFilterOrders(@Param("search") String search,
                                       @Param("status") String status,
                                       @Param("startDate") LocalDateTime startDate,
                                       @Param("endDate") LocalDateTime endDate);

    List<HoaDon> findByTrangThaiAndKhachHang(TrangThaiHoaDon trangThai, KhachHang khachHang);
    @Query("SELECT SUM(hd.tongTien) FROM HoaDon hd WHERE hd.trangThai.id = 7 AND CAST(hd.ngayThanhToan AS DATE) = CURRENT_DATE")
    List<Object[]> getDoanhThuTrongNgayData();

    @Query("SELECT kh.hoTen AS tenKhachHang, " +
            "SUM(hdt.soLuong) AS tongDaSoLuongMua, " +
            "SUM(hdt.soLuong * hdt.donGia) AS tongDoanhThu " +
            "FROM HoaDonChiTiet hdt " +
            "JOIN hdt.hoaDon hd " +
            "JOIN hd.khachHang kh " +
            "WHERE hd.trangThai.id = 7 " + // Chỉ lấy các hóa đơn đã hoàn thành
            "AND FUNCTION('MONTH', hd.ngayThanhToan) = FUNCTION('MONTH', CURRENT_DATE) " + // Lọc theo tháng hiện tại
            "AND FUNCTION('YEAR', hd.ngayThanhToan) = FUNCTION('YEAR', CURRENT_DATE) " + // Lọc theo năm hiện tại
            "GROUP BY kh.hoTen " +
            "ORDER BY tongDaSoLuongMua DESC")
    List<Object[]> getTopCustomersBySales();
    List<HoaDon> findByTrangThaiInAndKhachHang(List<TrangThaiHoaDon> trangThaiList, KhachHang khachHang);

    List<HoaDon> findByLoaiHoaDon(Boolean loaiHoaDon);
}

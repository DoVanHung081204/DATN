package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.Huyen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HuyenRepository extends JpaRepository<Huyen, Integer> {
}


package com.example.datn_sd_78.repository;


import com.example.datn_sd_78.entity.KhachHang;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Optional;

public interface KhachHangRepository extends JpaRepository<KhachHang, Integer> {

    Optional<KhachHang> findBySdt(String sdt);

    Page<KhachHang> findByHoTenContainingIgnoreCase(String hoTen, Pageable pageable);

    Optional<KhachHang> findByUser_TaiKhoan(String taiKhoan);

    @Query("SELECT k FROM KhachHang k WHERE " +
            "(LOWER(k.hoTen) LIKE LOWER(CONCAT('%', :KhachHangKeyWord, '%')) " +
            "OR LOWER(k.sdt) LIKE LOWER(CONCAT('%', :KhachHangKeyWord, '%')))")
    Page<KhachHang> searchKhachHang(@Param("KhachHangKeyWord") String KhachHangKeyWord, Pageable pageable);

    Page<KhachHang> findAll(Pageable pageable);


//    List<KhachHang> findByHoTenContainingIgnoreCase(String hoTen);
//
//    List<KhachHang> findByHoTenContainingIgnoreCaseAndGioiTinh(String hoTen, Integer gioiTinh);
//
//    List<KhachHang> findByGioiTinh(Integer gioiTinh);

    Page<KhachHang> findByHoTenContainingIgnoreCaseAndGioiTinh(String hoTen, Integer gioiTinh, Pageable pageable);

//    Page<KhachHang> findByHoTenContainingIgnoreCase(String hoTen, Pageable pageable);

    Page<KhachHang> findByGioiTinh(Integer gioiTinh, Pageable pageable);

}

package com.example.datn_sd_78.repository;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.KhachHangVoucher;
import com.example.datn_sd_78.entity.Voucher;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface KhachHangVoucherRepository extends CrudRepository<KhachHangVoucher, Integer> {

    KhachHangVoucher findByKhachHangAndVoucher(KhachHang khachHang, Voucher voucher);

    @Modifying
    @Query("UPDATE KhachHangVoucher khv SET khv.trangThai = 1 WHERE khv.khachHang = :khachHang AND khv.voucher = :voucher")
    void updateTrangThaiVoucherToUsed(@Param("khachHang") KhachHang khachHang, @Param("voucher") Voucher voucher);

    @Query("SELECT k FROM KhachHangVoucher k WHERE k.khachHang.id = :khachHangId ORDER BY k.trangThai ASC")
    List<KhachHangVoucher> findByKhachHangIdOrderByTrangThai(Integer khachHangId);




}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.KieuDang;
import org.springframework.data.jpa.repository.JpaRepository;

public interface KieuDangRepository extends JpaRepository<KieuDang,Integer> {
}

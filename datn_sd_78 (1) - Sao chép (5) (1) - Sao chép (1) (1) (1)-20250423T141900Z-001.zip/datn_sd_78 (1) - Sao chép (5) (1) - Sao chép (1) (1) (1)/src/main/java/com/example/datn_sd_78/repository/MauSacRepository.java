package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.MauSac;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MauSacRepository extends JpaRepository<MauSac, Integer> {
    MauSac findByTen(String ten);
}

package com.example.datn_sd_78.repository;


import com.example.datn_sd_78.entity.NhanVien;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface NhanVienRepo extends JpaRepository<NhanVien, Integer> {

//    Page<NhanVien> findBytenNhanVienContainingIgnoreCase(String tenNhanVien, Pageable pageable);



        Optional<NhanVien> findBySdt(String sdt);

        Page<NhanVien> findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCase(String tenNhanVien, String sdt, Pageable pageable);

        Page<NhanVien> findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndGioiTinhAndTrangThai(
                String tenNhanVien, String sdt, Integer gioiTinh, Integer trangThai, Pageable pageable);

        Page<NhanVien> findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndGioiTinh(
                String tenNhanVien, String sdt, Integer gioiTinh, Pageable pageable);

        Page<NhanVien> findByTenNhanVienContainingIgnoreCaseOrSdtContainingIgnoreCaseAndTrangThai(
                String tenNhanVien, String sdt, Integer trangThai, Pageable pageable);

        Page<NhanVien> findByGioiTinhAndTrangThai(Integer gioiTinh, Integer trangThai, Pageable pageable);

        Page<NhanVien> findByGioiTinh(Integer gioiTinh, Pageable pageable);

        Page<NhanVien> findByTrangThai(Integer trangThai, Pageable pageable);

        Optional<NhanVien> findByUser_TaiKhoan(String taiKhoan);


}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.NhapHang;
import org.springframework.data.jpa.repository.JpaRepository;

public interface NhapHangRepository extends JpaRepository<NhapHang, Integer> {
}

package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.SanPham;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface SanPhamRepository extends JpaRepository<SanPham, Integer> {
    List<SanPham> findByTenContaining(String ten); // Tìm kiếm sản phẩm theo tên

    // Sử dụng Optional để dễ dàng xử lý trường hợp không tìm thấy sản phẩm
    // Nếu không muốn sử dụng Optional, hãy xem hướng dẫn bên dưới
    SanPham getById(Integer id); // Phương thức này sẽ ném ra EntityNotFoundException nếu không tìm thấy

    // Nếu bạn muốn giữ lại phương thức trả về null khi không tìm thấy:
    // SanPham findById(Integer id); // Phương thức này sẽ trả về null nếu không tìm thấy

    @Query("SELECT sp FROM SanPham sp " +
            "JOIN sp.chiTietSanPham chiTiet " +
            "JOIN chiTiet.size s " +
            "JOIN chiTiet.mauSac c " +
            "WHERE (:keyword IS NULL OR sp.ten LIKE %:keyword%) " +
            "AND (:color IS NULL OR c.id = :color) " +
            "AND (:size IS NULL OR s.id = :size) " +
            "AND (:minPrice IS NULL OR sp.giaBan >= :minPrice) " +
            "AND (:maxPrice IS NULL OR sp.giaBan <= :maxPrice)")
    Page<SanPham> filterProducts(@Param("keyword") String keyword,
                                 @Param("color") Integer color,
                                 @Param("size") Integer size,
                                 @Param("minPrice") Double minPrice,
                                 @Param("maxPrice") Double maxPrice,
                                 Pageable pageable);

    boolean existsByMa(String ma); // Tự động tạo query từ tên phương thức

    @Query("SELECT s FROM SanPham s ORDER BY s.ngayTao DESC")

    List<SanPham> findTop20Newest(Pageable pageable);

}

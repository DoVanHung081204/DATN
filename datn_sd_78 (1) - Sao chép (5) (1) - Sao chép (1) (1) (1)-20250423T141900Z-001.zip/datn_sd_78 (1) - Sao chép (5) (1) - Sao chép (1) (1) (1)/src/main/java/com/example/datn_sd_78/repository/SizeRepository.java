package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.Size;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface SizeRepository extends JpaRepository<Size, Integer> {
    Size findByTen(String ten);
}

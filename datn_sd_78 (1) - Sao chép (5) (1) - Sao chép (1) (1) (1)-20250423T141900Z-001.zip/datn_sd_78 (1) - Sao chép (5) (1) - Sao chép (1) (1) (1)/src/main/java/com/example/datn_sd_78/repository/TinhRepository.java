package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.Tinh;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface TinhRepository extends JpaRepository<Tinh, Integer> {
}


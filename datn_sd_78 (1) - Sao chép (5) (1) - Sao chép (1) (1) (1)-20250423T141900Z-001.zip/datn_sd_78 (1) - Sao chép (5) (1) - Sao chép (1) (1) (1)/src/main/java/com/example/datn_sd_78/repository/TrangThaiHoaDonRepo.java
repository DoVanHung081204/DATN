package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.TrangThaiHoaDon;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TrangThaiHoaDonRepo extends JpaRepository<TrangThaiHoaDon, Integer>{
        Optional<TrangThaiHoaDon> findByTen(String ten);  // Phương thức tìm trạng thái theo tên
        List<TrangThaiHoaDon> findAllByTenIn(List<String> tenList);
}

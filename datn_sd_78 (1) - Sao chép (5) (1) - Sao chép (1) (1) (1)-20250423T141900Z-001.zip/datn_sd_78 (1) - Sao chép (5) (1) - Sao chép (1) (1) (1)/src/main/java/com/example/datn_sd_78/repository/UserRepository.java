package com.example.datn_sd_78.repository;


import com.example.datn_sd_78.entity.Users;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<Users, Integer> {
    Optional<Users> findByTaiKhoan(String taiKhoan);
    Optional<Users> findByEmail(String email);

    Optional<Users> findByResetToken(String resetToken); // Thêm phương thức này
}

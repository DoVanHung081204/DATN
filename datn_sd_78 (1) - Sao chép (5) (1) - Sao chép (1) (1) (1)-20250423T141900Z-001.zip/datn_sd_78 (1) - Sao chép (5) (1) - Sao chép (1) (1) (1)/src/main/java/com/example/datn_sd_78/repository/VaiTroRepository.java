package com.example.datn_sd_78.repository;


import com.example.datn_sd_78.entity.VaiTro;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VaiTroRepository extends JpaRepository<VaiTro, Integer> {
    VaiTro findByTenVaiTro(String tenVaiTro); // Thêm phương thức tìm vai trò
}

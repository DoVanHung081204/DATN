package com.example.datn_sd_78.repository;

import com.example.datn_sd_78.entity.Voucher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface VoucherRepository extends JpaRepository<Voucher, Integer> {
    public List<Voucher> findByKhachHangs_Id(int customerId);
    Page<Voucher> findByTenContainingIgnoreCase(String ten, Pageable pageable);
}

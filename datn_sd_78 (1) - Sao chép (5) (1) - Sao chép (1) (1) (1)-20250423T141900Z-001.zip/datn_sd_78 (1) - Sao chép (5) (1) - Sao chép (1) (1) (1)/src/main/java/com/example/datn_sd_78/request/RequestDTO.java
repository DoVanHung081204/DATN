package com.example.datn_sd_78.request;

import lombok.Data;

@Data
public class RequestDTO {
    private int service_type_id = 2;       // Loại dịch vụ
    private int from_district_id = 1447;  // Quận/huyện gửi
    private String from_ward_code = "20515";  // Mã phường/xã gửi
    private int to_district_id = 1442;    // Quận/huyện nhận
    private String to_ward_code = "20110";    // Mã phường/xã nhận
    private int weight = 2000;            // Trọng lượng (gram)
}

package com.example.datn_sd_78.rest;

import com.example.datn_sd_78.city.District;
import com.example.datn_sd_78.city.Ward;
import com.example.datn_sd_78.reponse.ResponseDTO;
import com.example.datn_sd_78.request.RequestDTO;
import com.example.datn_sd_78.service.GHNService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import java.util.List;

@RestController
public class ApiShipRestController {

    @Autowired
    private GHNService ghnService;
    private final String token = "f7a6a8d9-a552-11ef-a89d-dab02cbaab48";
    @PostMapping("/ship")
    public ResponseDTO eship(@RequestBody RequestDTO requestDTO){
        String url = "https://online-gateway.ghn.vn/shiip/public-api/v2/shipping-order/fee";
//        RequestDTO requestDTO = new RequestDTO();
        RestTemplate restTemplate = new RestTemplate();
        HttpHeaders headers = new HttpHeaders();
        headers.set("Token", token);
        headers.setContentType(MediaType.APPLICATION_JSON);

        HttpEntity<RequestDTO> entity = new HttpEntity<>(requestDTO, headers);
        System.out.println("entity: "+entity);
        ResponseEntity<ResponseDTO> response = restTemplate.exchange(
                url,
                HttpMethod.POST,
                entity,
                ResponseDTO.class
        );
        System.out.println("check get fee API: "+response.getBody().getData());
        return response.getBody();
    }

    @GetMapping("/checkout/getDistricts/{provinceId}")
    @ResponseBody
    public List<District> getDistricts(@PathVariable int provinceId) {
        return ghnService.getDistricts(provinceId);
    }

    // API lấy danh sách phường xã theo quận huyện
    @GetMapping("/checkout/getWards/{districtId}")
    @ResponseBody
    public List<Ward> getWards(@PathVariable int districtId) {
        return ghnService.getWards(districtId);
    }
}

package com.example.datn_sd_78.service;


import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.entity.VaiTro;
import com.example.datn_sd_78.repository.KhachHangRepository;
import com.example.datn_sd_78.repository.UserRepository;
import com.example.datn_sd_78.repository.VaiTroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private KhachHangRepository khachHangRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private VaiTroRepository vaiTroRepository;

    public String registerUser(String taiKhoan, String matKhau, String email, String ten, String diaChi, String soDienThoai, Integer gioiTinh) {
        // Kiểm tra tính duy nhất của tài khoản, email và số điện thoại
        if (userRepository.findByTaiKhoan(taiKhoan).isPresent()) {
            return "Tên đăng nhập đã tồn tại!";
        }
        if (userRepository.findByEmail(email).isPresent()) {
            return "Email đã tồn tại!";
        }
        if (khachHangRepository.findBySdt(soDienThoai).isPresent()) {
            return "Số điện thoại đã tồn tại!";
        }

        // Mã hóa mật khẩu
        String encodedPassword = passwordEncoder.encode(matKhau);

        // Lấy vai trò "KhachHang"
        VaiTro vaiTro = vaiTroRepository.findByTenVaiTro("CLIENT");

        // Tạo đối tượng User
        Users user = new Users();
        user.setTaiKhoan(taiKhoan);
        user.setMatKhau(encodedPassword);
        user.setEmail(email);
        user.setNgayTao(new Date());
        user.setTrangThai(1);
        user.setVaiTro(vaiTro);

        userRepository.save(user);

        // Tạo đối tượng KhachHang
        KhachHang khachHang = new KhachHang();
        khachHang.setHoTen(ten);
        khachHang.setDiaChi(diaChi);
        khachHang.setSdt(soDienThoai);
        khachHang.setUser(user);
        khachHang.setGioiTinh(gioiTinh);

        khachHangRepository.save(khachHang);

        return "success"; // Đăng ký thành công
    }

    // Phương thức xác thực người dùng
    public boolean authenticateUser(String taiKhoan, String matKhau) {
        Optional<Users> optionalUser = userRepository.findByTaiKhoan(taiKhoan);
        if (optionalUser.isPresent()) {
            Users user = optionalUser.get();
            return passwordEncoder.matches(matKhau, user.getMatKhau());
        }
        return false;
    }


    // Phương thức tìm người dùng theo tên đăng nhập
    public Users findUserByUsername(String username) {
        // Trả về đối tượng Users hoặc ném ngoại lệ nếu không tìm thấy
        return userRepository.findByTaiKhoan(username)
                .orElseThrow(() -> new RuntimeException("User not found with username: " + username));
    }

    // Quên mật khẩu - tạo token đặt lại mật khẩu
    public String generateResetToken(String email) {
        Optional<Users> optionalUser = userRepository.findByEmail(email);
        if (optionalUser.isEmpty()) {
            throw new RuntimeException("Email không tồn tại trong hệ thống");
        }

        Users user = optionalUser.get();
        String resetToken = UUID.randomUUID().toString(); // Tạo token ngẫu nhiên
        user.setResetToken(resetToken);
        user.setResetTokenExpiration(new Date(System.currentTimeMillis() + 15 * 60 * 1000)); // Token hết hạn sau 15 phút
        userRepository.save(user);

        return resetToken;
    }

    // Xác thực token đặt lại mật khẩu
    // Xác thực token đặt lại mật khẩu
    public boolean validateResetToken(String token) {
        Optional<Users> optionalUser = userRepository.findByResetToken(token);
        if (optionalUser.isEmpty()) {
            return false; // Token không tồn tại
        }

        Users user = optionalUser.get();
        // Kiểm tra nếu token đã hết hạn
        if (user.getResetTokenExpiration().before(new Date())) {
            // Xóa token và ngày hết hạn nếu token đã hết hạn
            user.setResetToken(null);
            user.setResetTokenExpiration(null);
            userRepository.save(user);
            return false; // Token đã hết hạn
        }

        return true; // Token hợp lệ
    }


    // Đặt lại mật khẩu mới
    public boolean resetPassword(String token, String newPassword) {
        Optional<Users> optionalUser = userRepository.findByResetToken(token);
        if (optionalUser.isEmpty()) {
            return false;
        }

        Users user = optionalUser.get();
        if (user.getResetTokenExpiration().before(new Date())) {
            throw new RuntimeException("Token đã hết hạn");
        }

        user.setMatKhau(passwordEncoder.encode(newPassword));
        user.setResetToken(null); // Xóa token sau khi dùng
        user.setResetTokenExpiration(null);
        userRepository.save(user);

        return true;
    }

}

package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.entity.HoaDonChiTiet;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.entity.TrangThaiHoaDon;
import com.example.datn_sd_78.entity.Voucher;
import com.example.datn_sd_78.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.security.Principal;
import java.time.LocalDateTime;
import java.util.List;

@Service
public class CartServices {
    @Autowired
    ChiTietSanPhamRepository sanPhamChiTietRepository;

    @Autowired
    HoaDonRepository hoaDonRepo;

    @Autowired
    TrangThaiHoaDonRepo trangThaiHoaDonRepository;
    @Autowired
    ChiTietSanPhamRepository SanPhamChiTietRepo;
    @Autowired
    HoaDonChiTietRepository hoaDonChiTietRepo;
    @Autowired
    KhachHangRepository khachHangRepo;
    @Autowired
    VoucherRepository voucherRepo;
    @Autowired
    NhanVienService nhanVienService;

    public Integer taoHoaDon(Principal principal) {
        HoaDon hoaDon = new HoaDon();
        hoaDon.setNgayTao(LocalDateTime.now());
        hoaDon.setNhanVien(null);
        hoaDon.setKhachHang(null);
        TrangThaiHoaDon trangThai = trangThaiHoaDonRepository.findById(9).orElse(null);
        hoaDon.setTrangThai(trangThai);
        hoaDon.setLoaiHoaDon(false);

        String username = principal.getName();
        NhanVien nhanVien = nhanVienService.findByTaiKhoan(username);
        hoaDon.setNhanVien(nhanVien);
        // Lưu hóa đơn và trả về id
        HoaDon savedHoaDon = hoaDonRepo.save(hoaDon);
        return savedHoaDon.getId(); // Giả sử `getId()` trả về id của hóa đơn
    }

    public void addProductToCart(int idCTSP, int idHoaDon, int quantity) {
        List<HoaDonChiTiet> items = hoaDonChiTietRepo.lstHoaDonChiTiet(idHoaDon);

        HoaDonChiTiet hoaDonChiTiet = items
                .stream()
                .filter(hdct -> hdct.getChiTietSanPham().getId() == idCTSP)
                .findFirst()
                .orElse(null);

        SanPhamChiTiet spct = sanPhamChiTietRepository.findById(idCTSP).orElse(null);

        if (spct == null) {
            throw new IllegalStateException("Không tìm thấy sản phẩm.");
        }

        int remainingQuantity = spct.getSoLuong() - quantity;
        if (remainingQuantity < 0) {
            throw new IllegalStateException("Số lượng sản phẩm trong kho không đủ.");
        }

        if (hoaDonChiTiet != null) {
            // Cập nhật số lượng trong giỏ hàng
            hoaDonChiTiet.setSoLuong(hoaDonChiTiet.getSoLuong() + quantity);
            hoaDonChiTietRepo.save(hoaDonChiTiet);
        } else {
            // Thêm sản phẩm mới vào giỏ hàng
            BigDecimal donGia = spct.getSanPham().getGiaBan();
            hoaDonChiTietRepo.insertHoaDonChiTiet(idCTSP, quantity, donGia, idHoaDon);
        }

        // Trừ số lượng tồn kho
        spct.setSoLuong(remainingQuantity);
        sanPhamChiTietRepository.save(spct); // Lưu lại thông tin sản phẩm đã cập nhật số lượng
    }

    public BigDecimal tinhTongTien(List<HoaDonChiTiet> lstHoaDonChiTiet) {
        BigDecimal tongTien = BigDecimal.ZERO;
        for (HoaDonChiTiet hdct : lstHoaDonChiTiet) {
            tongTien = tongTien.add(hdct.getDonGia().multiply(BigDecimal.valueOf(hdct.getSoLuong())));
        }
        return tongTien;
    }

    public void addCustomerToBill(int idHoaDon, int idKhachHang) {
        HoaDon hoaDon = hoaDonRepo.findById(idHoaDon).orElse(null);
        KhachHang khachHang = khachHangRepo.findById(idKhachHang).orElse(null);
        hoaDon.setKhachHang(khachHang);
        hoaDonRepo.save(hoaDon);
    }

    public void addVoucherToBill(int idHoaDon, int idVoucher) {
        HoaDon hoaDon = hoaDonRepo.findById(idHoaDon).orElse(null);
        Voucher voucher = voucherRepo.findById(idVoucher).orElse(null);
        hoaDon.setVoucher(voucher);
        hoaDonRepo.save(hoaDon);
    }
}

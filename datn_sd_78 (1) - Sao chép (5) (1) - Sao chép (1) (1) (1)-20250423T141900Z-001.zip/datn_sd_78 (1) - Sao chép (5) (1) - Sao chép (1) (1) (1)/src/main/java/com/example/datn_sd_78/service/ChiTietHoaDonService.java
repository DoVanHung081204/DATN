package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.entity.HoaDonChiTiet;
import com.example.datn_sd_78.repository.HoaDonChiTietRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ChiTietHoaDonService {
    // Inject các repository nếu có (ví dụ: HoaDonChiTietRepository)
    @Autowired
    private HoaDonChiTietRepository hoaDonChiTietRepository;

    // Phương thức để lưu chi tiết hóa đơn
    public void save(HoaDonChiTiet chiTietHoaDon) {
        hoaDonChiTietRepository.save(chiTietHoaDon); // Lưu vào database
    }

    public List<HoaDonChiTiet> findByHoaDon(HoaDon hoaDon) {
        return hoaDonChiTietRepository.findByHoaDon(hoaDon);
    }
}

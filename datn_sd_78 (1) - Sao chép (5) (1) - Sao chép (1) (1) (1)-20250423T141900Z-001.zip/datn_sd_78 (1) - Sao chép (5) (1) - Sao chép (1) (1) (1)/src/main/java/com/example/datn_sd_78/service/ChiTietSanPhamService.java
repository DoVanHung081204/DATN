package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.repository.ChiTietSanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChiTietSanPhamService {
    @Autowired
    private ChiTietSanPhamRepository chiTietSanPhamRepository;

    public void update(SanPhamChiTiet chiTietSanPham) {
        chiTietSanPhamRepository.save(chiTietSanPham);
    }
}

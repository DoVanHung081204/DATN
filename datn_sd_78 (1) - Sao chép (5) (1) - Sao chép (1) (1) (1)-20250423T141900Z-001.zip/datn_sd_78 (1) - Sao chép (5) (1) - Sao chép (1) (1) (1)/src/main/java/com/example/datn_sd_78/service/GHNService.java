package com.example.datn_sd_78.service;

import com.example.datn_sd_78.city.District;
import com.example.datn_sd_78.city.Province;
import com.example.datn_sd_78.city.Response;
import com.example.datn_sd_78.city.Ward;
import com.example.datn_sd_78.reponse.ResponseDTO;
import com.example.datn_sd_78.request.RequestDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class GHNService {
    private final String token = "f7a6a8d9-a552-11ef-a89d-dab02cbaab48";  // Token

//    private final RestTemplate restTemplate;
    private final String API_URL = "https://online-gateway.ghn.vn/shiip/public-api/v2/shipping-order/fee";

//    @Autowired
//    public GHNService(RestTemplate restTemplate) {
//        this.restTemplate = restTemplate;
//    }

    // Lấy danh sách tỉnh thành
    public List<Province> getProvinces() {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://online-gateway.ghn.vn/shiip/public-api/master-data/" + "province";  // Đường dẫn lấy danh sách tỉnh thành
        HttpHeaders headers = new HttpHeaders();
        headers.set("Token", token);  // Thêm token vào header
        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            // Gửi request GET và nhận phản hồi
            ResponseEntity<Response<Province>> response = restTemplate.exchange(
                    url, HttpMethod.GET, entity, new ParameterizedTypeReference<Response<Province>>() {
                    });

            return response.getBody().getData();  // Trả về danh sách tỉnh thành
        } catch (HttpClientErrorException e) {
            // Xử lý lỗi trong trường hợp không kết nối được API
            e.printStackTrace();
            return null;
        }
    }

    // Lấy danh sách quận huyện của tỉnh
    public List<District> getDistricts(int provinceId) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://online-gateway.ghn.vn/shiip/public-api/master-data/" + "district?province_id=" + provinceId;  // Đường dẫn lấy danh sách quận huyện của tỉnh
        HttpHeaders headers = new HttpHeaders();
        headers.set("Token", token);  // Thêm token vào header
        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            // Gửi request GET và nhận phản hồi
            ResponseEntity<Response<District>> response = restTemplate.exchange(
                    url, HttpMethod.GET, entity, new ParameterizedTypeReference<Response<District>>() {
                    });

            return response.getBody().getData();  // Trả về danh sách quận huyện
        } catch (HttpClientErrorException e) {
            // Xử lý lỗi trong trường hợp không kết nối được API
            e.printStackTrace();
            return null;
        }
    }

    // Lấy danh sách phường xã của quận
    public List<Ward> getWards(int districtId) {
        RestTemplate restTemplate = new RestTemplate();
        String url = "https://online-gateway.ghn.vn/shiip/public-api/master-data/" + "ward?district_id=" + districtId;  // Đường dẫn lấy danh sách phường xã của quận
        HttpHeaders headers = new HttpHeaders();
        headers.set("Token", token);  // Thêm token vào header
        HttpEntity<String> entity = new HttpEntity<>(headers);

        try {
            // Gửi request GET và nhận phản hồi
            ResponseEntity<Response<Ward>> response = restTemplate.exchange(
                    url, HttpMethod.GET, entity, new ParameterizedTypeReference<Response<Ward>>() {
                    });

            return response.getBody().getData();  // Trả về danh sách phường xã
        } catch (HttpClientErrorException e) {
            // Xử lý lỗi trong trường hợp không kết nối được API
            e.printStackTrace();
            return null;
        }
    }

    public ResponseDTO getShippingFee(RequestDTO requestDTO) {
        RestTemplate restTemplate = new RestTemplate();

        HttpHeaders headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        headers.set("Token", token);

        HttpEntity<RequestDTO> entity = new HttpEntity<>(requestDTO, headers);

        try {
            ResponseEntity<ResponseDTO> response = restTemplate.exchange(
                    API_URL,
                    HttpMethod.POST,
                    entity,
                    ResponseDTO.class
            );
            System.out.println("Response from GHN: " + response.getBody());
            return response.getBody();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

}

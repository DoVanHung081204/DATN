package com.example.datn_sd_78.service;


import com.example.datn_sd_78.entity.CtspKhuyenMai;
import com.example.datn_sd_78.entity.GioHang;
import com.example.datn_sd_78.entity.GioHangChiTiet;
import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.repository.ChiTietSanPhamRepository;
import com.example.datn_sd_78.repository.CtspKhuyenMaiRepository;
import com.example.datn_sd_78.repository.GioHangChiTietRespository;
import com.example.datn_sd_78.repository.GioHangRespository;
import com.example.datn_sd_78.repository.MauSacRepository;
import com.example.datn_sd_78.repository.SizeRepository;
import jakarta.servlet.http.HttpSession;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class GioHangService {
    @Autowired
    SanPhamService sanPhamService;

    @Autowired
    ChiTietSanPhamRepository sanPhamChiTietRepository;
    @Autowired
    private CtspKhuyenMaiRepository ctspKhuyenMaiRepository;

    @Autowired
    private SizeRepository sizeRepository;

    @Autowired
    private MauSacRepository mauSacRepository;

    @Autowired
    private MauSacService mauSacService;

    @Autowired
    private SizeService sizeService;

    @Autowired
    private GioHangRespository gioHangRespository;

    @Autowired
    private GioHangChiTietRespository gioHangChiTietRespository;

    @Autowired
    private KhachHangService khachHangService;

    public List<GioHangChiTiet> getItems() {
        GioHang gioHang = getGioHangByCurrentCustomer();
        return (gioHang != null) ? gioHang.getGioHangChiTietList() : new ArrayList<>();
    }

    public GioHangService(GioHangRespository gioHangRepository, KhachHangService khachHangService) {
        this.gioHangRespository = gioHangRepository;
        this.khachHangService = khachHangService;
    }

    public KhachHang getCurrentCustomer() {
        Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
        String taiKhoan;

        if (principal instanceof User) {
            taiKhoan = ((User) principal).getUsername();
        } else if (principal instanceof String) {
            taiKhoan = (String) principal;
        } else {
            throw new IllegalStateException("Unknown principal type");
        }
        return khachHangService.findByTaiKhoan(taiKhoan);
    }

    public GioHang getGioHangByCurrentCustomer() {
        KhachHang currentCustomer = getCurrentCustomer();
        if (currentCustomer != null) {
            return gioHangRespository.findByKhachHang(currentCustomer).orElse(null); // Không tạo giỏ hàng mới nếu không tìm thấy
        }
        return null;
    }


    public void add(int id, int soLuong, String mauSac, String size) {
        KhachHang currentCustomer = getCurrentCustomer();
        if (currentCustomer == null) {
            throw new RuntimeException("Bạn cần đăng nhập để thêm sản phẩm vào giỏ hàng.");
        }

        GioHang gioHang = gioHangRespository.findByKhachHang(currentCustomer)
                .orElseGet(() -> {
                    GioHang newGioHang = new GioHang();
                    newGioHang.setKhachHang(currentCustomer);
                    newGioHang.setNgayTao(Date.from(LocalDateTime.now().atZone(ZoneId.systemDefault()).toInstant()));
                    newGioHang.setTrangThai(1); // Trạng thái hoạt động
                    return gioHangRespository.save(newGioHang);
                });

        SanPhamChiTiet sanPhamChiTiet = sanPhamService.findVariantByColorAndSize(id, mauSac, size);
        if (sanPhamChiTiet == null || sanPhamChiTiet.getSoLuong() < soLuong) {
            throw new RuntimeException("Số lượng tồn kho không đủ.");
        }

        List<GioHangChiTiet> items = gioHangChiTietRespository.findByGioHang(gioHang);

        GioHangChiTiet gioHangChiTiet = findGioHangChiTietByProductAndVariant(items, id, size, mauSac);

        if (gioHangChiTiet != null) {
            if (gioHangChiTiet.getSoLuong() + soLuong > sanPhamChiTiet.getSoLuong()) {
                throw new RuntimeException("Số lượng vượt quá tồn kho.");
            }
            gioHangChiTiet.setSoLuong(gioHangChiTiet.getSoLuong() + soLuong);
        } else {
            gioHangChiTiet = new GioHangChiTiet(null, gioHang, sanPhamChiTiet, soLuong);
            items.add(gioHangChiTiet);
        }

        updateProductPrices(items);
        gioHangChiTietRespository.saveAll(items);
        updateCartSession(items);
    }


    public void update(GioHangChiTiet gioHangChiTiet, Integer newSoLuong) {
        if (newSoLuong <= 0) {
            // Nếu số lượng <= 0, xóa sản phẩm khỏi giỏ hàng
            remove(
                    gioHangChiTiet.getChiTietSanPham().getSanPham().getId(),
                    gioHangChiTiet.getChiTietSanPham().getSize().getTen(),
                    gioHangChiTiet.getChiTietSanPham().getMauSac().getTen()
            );
            return;
        }

        List<GioHangChiTiet> items = getItems();

        GioHangChiTiet chiTietCanCapNhat = findGioHangChiTietByProductAndVariant(items,
                gioHangChiTiet.getChiTietSanPham().getSanPham().getId(),
                gioHangChiTiet.getChiTietSanPham().getSize().getTen(),
                gioHangChiTiet.getChiTietSanPham().getMauSac().getTen());

        if (chiTietCanCapNhat != null) {
            chiTietCanCapNhat.setSoLuong(newSoLuong);
            updateProductPrice(chiTietCanCapNhat);
            gioHangChiTietRespository.save(chiTietCanCapNhat);
            updateCartSession(items);
        } else {
            throw new RuntimeException("Sản phẩm chi tiết không tồn tại trong giỏ hàng.");
        }
    }

    public void remove(int productId, String size, String color) {
        KhachHang currentCustomer = getCurrentCustomer();
        if (currentCustomer == null) {
            throw new RuntimeException("Bạn cần đăng nhập để xóa sản phẩm khỏi giỏ hàng.");
        }

        // Retrieve the current customer's cart
        GioHang gioHang = gioHangRespository.findByKhachHang(currentCustomer)
                .orElseThrow(() -> new RuntimeException("Giỏ hàng không tồn tại."));

        // Get the list of items in the cart
        List<GioHangChiTiet> items = gioHangChiTietRespository.findByGioHang(gioHang);

        // Find the item to be removed
        GioHangChiTiet gioHangChiTietToRemove = findGioHangChiTietByProductAndVariant(items, productId, size, color);

        if (gioHangChiTietToRemove != null) {
            // Remove the item from the list
            items.remove(gioHangChiTietToRemove);

            // Save the updated list of items to the cart
            gioHangChiTietRespository.delete(gioHangChiTietToRemove);  // Delete the item from the database
            gioHangChiTietRespository.saveAll(items);  // Save the remaining items in the cart

            // Update the session
            updateCartSession(items);
        } else {
            throw new RuntimeException("Sản phẩm không tồn tại trong giỏ hàng.");
        }
    }

    private GioHangChiTiet findGioHangChiTietByProductAndVariant(List<GioHangChiTiet> items, int productId, String size, String color) {
        return items.stream()
                .filter(gh -> gh.getChiTietSanPham().getSanPham().getId() == productId
                        && gh.getChiTietSanPham().getSize().getTen().equals(size)
                        && gh.getChiTietSanPham().getMauSac().getTen().equals(color))
                .findFirst()
                .orElse(null);
    }

    private GioHangChiTiet findGioHangChiTietByProduct(List<GioHangChiTiet> items, int productId) {
        return items.stream()
                .filter(gh -> gh.getChiTietSanPham().getSanPham().getId() == productId)
                .findFirst()
                .orElse(null);
    }

    private void updateProductPrices(List<GioHangChiTiet> items) {
        for (GioHangChiTiet item : items) {
            updateProductPrice(item);
        }
    }

    private void updateProductPrice(GioHangChiTiet item) {
        SanPhamChiTiet chiTiet = item.getChiTietSanPham();
        BigDecimal giaGoc = chiTiet.getSanPham().getGiaBan();
        BigDecimal giaSauKhiGiam = giaGoc;

        CtspKhuyenMai khuyenMai = ctspKhuyenMaiRepository.findActivePromotionByProductId(chiTiet.getSanPham().getId());
        if (khuyenMai != null) {
            giaSauKhiGiam = khuyenMai.getLoaiGiamGia()
                    ? giaGoc.subtract(giaGoc.multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)))
                    : giaGoc.subtract(khuyenMai.getMucGiam());
        }

        chiTiet.getSanPham().setGiaSauKhiGiam(giaSauKhiGiam);
    }

    private void updateCartSession(List<GioHangChiTiet> items) {
        HttpSession session = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest().getSession();
        session.setAttribute("gioHang", items);
    }

    public int getTongSoLuong() {
        return getItems().stream()
                .mapToInt(GioHangChiTiet::getSoLuong)
                .sum();
    }

    public int getTongGiaTri() {
        return getItems().stream()
                .map(gioHangChiTiet -> {
                    SanPhamChiTiet sanPhamChiTiet = gioHangChiTiet.getChiTietSanPham();
                    BigDecimal giaSuDung = Optional.ofNullable(sanPhamChiTiet.getSanPham().getGiaSauKhiGiam())
                            .filter(gia -> gia.compareTo(BigDecimal.ZERO) > 0)
                            .orElse(sanPhamChiTiet.getSanPham().getGiaBan());
                    return giaSuDung.multiply(BigDecimal.valueOf(gioHangChiTiet.getSoLuong()));
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .intValue();
    }




    @Transactional
    public void clearCartAfterPayment(HttpSession session) {
        if (session.getAttribute("gioHang") != null) {
            List<GioHangChiTiet> items = (List<GioHangChiTiet>) session.getAttribute("gioHang");
            items.clear();  // Remove all products from the cart in session
            session.setAttribute("gioHang", items);  // Update the session cart
        }

        KhachHang currentCustomer = getCurrentCustomer();
        if (currentCustomer != null) {
            GioHang gioHang = gioHangRespository.findByKhachHang(currentCustomer)
                    .orElse(null);  // Find the customer's cart
            if (gioHang != null) {
                gioHangChiTietRespository.deleteByGioHang(gioHang);
                gioHangRespository.delete(gioHang);
            }
        }
    }




}



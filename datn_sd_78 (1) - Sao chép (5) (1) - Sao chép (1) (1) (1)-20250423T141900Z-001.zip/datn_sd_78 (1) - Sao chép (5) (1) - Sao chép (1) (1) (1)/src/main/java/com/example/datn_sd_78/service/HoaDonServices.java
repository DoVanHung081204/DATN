package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.HoaDon;
import com.example.datn_sd_78.entity.HoaDonChiTiet;
import com.example.datn_sd_78.entity.TrangThaiHoaDonChiTiet;
import com.example.datn_sd_78.repository.HoaDonChiTietRepository;
import com.example.datn_sd_78.repository.HoaDonRepository;
import com.example.datn_sd_78.repository.TrangThaiHoaDonChiTietRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HoaDonServices {
    @Autowired
    private HoaDonRepository hoaDonRepository;

    @Autowired
    HoaDonChiTietRepository hoaDonChiTietRepository;

    @Autowired
    TrangThaiHoaDonChiTietRepo trangThaiHoaDonChiTietRepo;


    public HoaDon save(HoaDon hoaDon) {
        return hoaDonRepository.save(hoaDon);
    }

    public HoaDon findById(Integer id) {
        return hoaDonRepository.findById(id).orElse(null); // Trả về null nếu không tìm thấy
    }

    public void huySanPham(Integer chiTietId, String lyDoHuy) {
        HoaDonChiTiet chiTiet = hoaDonChiTietRepository.findById(chiTietId).orElse(null);
        chiTiet.setTrangThai(trangThaiHoaDonChiTietRepo.findById(4).orElse(null));
        chiTiet.setLyDoHuy(lyDoHuy);
        hoaDonChiTietRepository.save(chiTiet);
    }

}

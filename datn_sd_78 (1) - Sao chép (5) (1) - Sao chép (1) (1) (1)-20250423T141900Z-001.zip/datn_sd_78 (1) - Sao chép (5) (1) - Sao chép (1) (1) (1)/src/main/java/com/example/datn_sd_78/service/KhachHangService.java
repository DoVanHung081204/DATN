package com.example.datn_sd_78.service;



import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.entity.VaiTro;
import com.example.datn_sd_78.repository.KhachHangRepository;
import com.example.datn_sd_78.repository.UserRepository;
import com.example.datn_sd_78.repository.VaiTroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
public class KhachHangService {
    @Autowired
    private UserRepository userRepository;

    @Autowired
    private KhachHangRepository khachHangRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private VaiTroRepository vaiTroRepository;

    public String addKH(String taiKhoan, String matKhau, String email, String ten, String diaChi, String soDienThoai, Integer gioiTinh) {
        // Kiểm tra tính duy nhất của tài khoản, email và số điện thoại
        if (userRepository.findByTaiKhoan(taiKhoan).isPresent()) {
            return "Tên đăng nhập đã tồn tại!";
        }
        if (userRepository.findByEmail(email).isPresent()) {
            return "Email đã tồn tại!";
        }
        if (khachHangRepository.findBySdt(soDienThoai).isPresent()) {
            return "Số điện thoại đã tồn tại!";
        }

        // Mã hóa mật khẩu
        String encodedPassword = passwordEncoder.encode(matKhau);

        // Lấy vai trò "KhachHang"
        VaiTro vaiTro = vaiTroRepository.findByTenVaiTro("CLIENT");

        // Tạo đối tượng User
        Users user = new Users();
        user.setTaiKhoan(taiKhoan);
        user.setMatKhau(encodedPassword);
        user.setEmail(email);
        user.setNgayTao(new Date());
        user.setTrangThai(1);
        user.setVaiTro(vaiTro);

        userRepository.save(user);

        // Tạo đối tượng KhachHang
        KhachHang khachHang = new KhachHang();
        khachHang.setHoTen(ten);
        khachHang.setDiaChi(diaChi);
        khachHang.setSdt(soDienThoai);
        khachHang.setUser(user);
        khachHang.setGioiTinh(gioiTinh);

        khachHangRepository.save(khachHang);

        return "success"; // Đăng ký thành công
    }

    public String updateKH(Integer id, String taiKhoan, String matKhau, String email, String ten, String diaChi, String soDienThoai, Integer trangThai) {
        // Kiểm tra khách hàng có tồn tại không
        Optional<KhachHang> khachHangOpt = khachHangRepository.findById(id);
        if (!khachHangOpt.isPresent()) {
            return "Khách hàng không tồn tại!";
        }
        KhachHang khachHang = khachHangOpt.get();

        // Kiểm tra tính duy nhất của tài khoản, email và số điện thoại
        if (userRepository.findByTaiKhoan(taiKhoan).isPresent() && !userRepository.findByTaiKhoan(taiKhoan).get().getId().equals(khachHang.getUser().getId())) {
            return "Tên đăng nhập đã tồn tại!";
        }
        if (userRepository.findByEmail(email).isPresent() && !userRepository.findByEmail(email).get().getId().equals(khachHang.getUser().getId())) {
            return "Email đã tồn tại!";
        }
        if (khachHangRepository.findBySdt(soDienThoai).isPresent() && !khachHangRepository.findBySdt(soDienThoai).get().getId().equals(khachHang.getId())) {
            return "Số điện thoại đã tồn tại!";
        }

        // Mã hóa mật khẩu nếu có thay đổi
        if (!matKhau.isEmpty()) {
            String encodedPassword = passwordEncoder.encode(matKhau);
            khachHang.getUser().setMatKhau(encodedPassword);
        }

        // Cập nhật thông tin user và khách hàng
        Users user = khachHang.getUser();
        user.setTaiKhoan(taiKhoan);
        user.setEmail(email);
        user.setNgayTao(new Date());
        user.setTrangThai(trangThai);
        khachHang.setHoTen(ten);
        khachHang.setDiaChi(diaChi);
        khachHang.setSdt(soDienThoai);
        khachHang.setUser(user);

        khachHangRepository.save(khachHang);
        return "success"; // Cập nhật thành công
    }


    public KhachHang findByTaiKhoan(String taiKhoan) {
        return khachHangRepository.findByUser_TaiKhoan(taiKhoan).orElse(null);
    }

}

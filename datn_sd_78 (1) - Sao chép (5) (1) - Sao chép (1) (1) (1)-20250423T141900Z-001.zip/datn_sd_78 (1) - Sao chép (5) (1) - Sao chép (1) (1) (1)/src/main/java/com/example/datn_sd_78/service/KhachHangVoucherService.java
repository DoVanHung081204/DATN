package com.example.datn_sd_78.service;

import com.example.datn_sd_78.repository.KhachHangVoucherRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class KhachHangVoucherService {
    @Autowired
    private KhachHangVoucherRepository khachHangVoucherRepository;

}


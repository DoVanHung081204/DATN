package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.CtspKhuyenMai;
import com.example.datn_sd_78.entity.KhuyenMai;
import com.example.datn_sd_78.entity.SanPham;
import com.example.datn_sd_78.repository.CtspKhuyenMaiRepository;
import com.example.datn_sd_78.repository.KhuyenMaiRepository;
import com.example.datn_sd_78.repository.SanPhamRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class KhuyenMaiService {
    @Autowired
    private KhuyenMaiRepository khuyenMaiRepository;

    @Autowired
    private SanPhamRepository sanPhamRepository;
    @Autowired
    private CtspKhuyenMaiRepository ctspKhuyenMaiRepository;

    public List<KhuyenMai> findAll() {
        return khuyenMaiRepository.findAll();
    }
    public void save(KhuyenMai khuyenMai) {
        Date currentDate = new Date();

        // Kiểm tra trạng thái của khuyến mại
        if (khuyenMai.getNgayBatDau().after(currentDate)) {
            khuyenMai.setTrangThai(2); // Chưa bắt đầu
        } else if (khuyenMai.getNgayKetThuc().before(currentDate)) {
            khuyenMai.setTrangThai(0); // Không hoạt động
        } else {
            khuyenMai.setTrangThai(1); // Hoạt động
        }

        // Nếu mã không được chỉ định, tạo một mã ngẫu nhiên
        if (khuyenMai.getMa() == null || khuyenMai.getMa().isEmpty()) {
            khuyenMai.setMa(generatePromoCode()); // Hàm này cần được định nghĩa để tạo mã
        }

        // Lưu khuyến mãi vào database
        khuyenMaiRepository.save(khuyenMai);
    }

    // Hàm để tạo mã khuyến mại ngẫu nhiên
    private String generatePromoCode() {
        // Cách đơn giản để tạo mã ngẫu nhiên, có thể điều chỉnh theo yêu cầu
        return "PROMO" + System.currentTimeMillis(); // Ví dụ tạo mã từ timestamp
    }
    public void applyDiscount(Integer khuyenMaiId, List<Integer> productIds) {
        KhuyenMai khuyenMai = khuyenMaiRepository.findById(khuyenMaiId).orElse(null);
        if (khuyenMai != null && khuyenMai.getTrangThai() == 1) { // Kiểm tra trạng thái
            for (Integer productId : productIds) {
                SanPham sanPham = sanPhamRepository.findById(productId).orElse(null);
                if (sanPham != null) {
                    // Kiểm tra nếu sản phẩm đã có khuyến mại
                    List<CtspKhuyenMai> existingPromotions = ctspKhuyenMaiRepository.findBySanPhamId(productId);
                    boolean hasActivePromotion = existingPromotions.stream()
                            .anyMatch(ctsp -> ctsp.getKhuyenMai().getNgayKetThuc().after(new Date()));

                    if (hasActivePromotion) {
                        throw new IllegalArgumentException("Sản phẩm " + sanPham.getTen() + " đã có khuyến mại. Không thể thêm khuyến mại mới cho đến khi khuyến mại cũ hết hạn.");
                    }

                    CtspKhuyenMai ctspKhuyenMai = new CtspKhuyenMai();
                    ctspKhuyenMai.setKhuyenMai(khuyenMai);
                    ctspKhuyenMai.setSanPham(sanPham);
                    ctspKhuyenMai.setLoaiGiamGia(khuyenMai.getLoaiGiamGia());
                    ctspKhuyenMai.setMucGiam(khuyenMai.getMucGiam());

                    // Tính toán giá sau khi giảm
                    BigDecimal donGiaSauKhiGiam;
                    if (khuyenMai.getLoaiGiamGia()) { // Giảm %
                        donGiaSauKhiGiam = sanPham.getGiaBan().subtract(sanPham.getGiaBan().multiply(khuyenMai.getMucGiam()).divide(BigDecimal.valueOf(100)));
                    } else { // Giảm VND
                        donGiaSauKhiGiam = sanPham.getGiaBan().subtract(khuyenMai.getMucGiam());
                    }

                    ctspKhuyenMai.setDonGiaSauKhiGiam(donGiaSauKhiGiam);
                    ctspKhuyenMai.setTrangThai(1); // Đặt trạng thái là hoạt động

                    // Lưu vào database
                    ctspKhuyenMaiRepository.save(ctspKhuyenMai);
                }
            }
        }
    }

    public List<SanPham> getAvailableProductsForPromotion(Integer khuyenMaiId) {
        // Lấy danh sách sản phẩm đã có khuyến mãi
        List<CtspKhuyenMai> ctspKhuyenMais = ctspKhuyenMaiRepository.findByKhuyenMaiId(khuyenMaiId);
        List<Integer> productIdsWithPromotion = ctspKhuyenMais.stream()
                .map(ctsp -> ctsp.getSanPham().getId())
                .collect(Collectors.toList());

        // Lấy tất cả sản phẩm
        List<SanPham> allProducts = sanPhamRepository.findAll();

        // Lọc ra các sản phẩm chưa có khuyến mãi
        return allProducts.stream()
                .filter(sanPham -> !productIdsWithPromotion.contains(sanPham.getId()))
                .collect(Collectors.toList());
    }

// KhuyenMaiService.java

    public List<KhuyenMai> searchByCodeOrName(String query) {
        return khuyenMaiRepository.findByMaContainingOrTenContaining(query, query);
    }

    // Lọc
    public List<KhuyenMai> filterByStatus(Integer status) {
        // Lọc khuyến mãi theo trạng thái
        return khuyenMaiRepository.findByTrangThai(status);
    }
}

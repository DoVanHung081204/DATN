package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.MauSac;
import com.example.datn_sd_78.repository.MauSacRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MauSacService {
    @Autowired
    private MauSacRepository mauSacRepository;

    // Phương thức tìm màu sắc theo tên
    public MauSac findByTen(String ten) {
        return mauSacRepository.findByTen(ten);
    }

    public List<MauSac> getAllColors() {
        return mauSacRepository.findAll();
    }
}

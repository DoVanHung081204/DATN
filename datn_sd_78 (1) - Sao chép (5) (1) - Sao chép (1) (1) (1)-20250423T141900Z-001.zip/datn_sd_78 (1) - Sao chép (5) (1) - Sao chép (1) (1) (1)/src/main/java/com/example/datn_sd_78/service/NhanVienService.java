package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.NhanVien;
import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.entity.VaiTro;

import com.example.datn_sd_78.repository.NhanVienRepo;
import com.example.datn_sd_78.repository.UserRepository;
import com.example.datn_sd_78.repository.VaiTroRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.Optional;

@Service
public class NhanVienService {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private NhanVienRepo nhanVienRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Autowired
    private VaiTroRepository vaiTroRepository;

    // Updated method to include gioiTinh
    public String addNhanVien(String taiKhoan, String matKhau, String email, String ten, String diaChi,
                              String soDienThoai, Integer gioiTinh,String cccd) {
        // Kiểm tra tính duy nhất của tài khoản, email và số điện thoại
        if (userRepository.findByTaiKhoan(taiKhoan).isPresent()) {
            return "Tên đăng nhập đã tồn tại!";
        }
        if (userRepository.findByEmail(email).isPresent()) {
            return "Email đã tồn tại!";
        }
        if (nhanVienRepository.findBySdt(soDienThoai).isPresent()) {
            return "Số điện thoại đã tồn tại!";
        }
        String encodedPassword = passwordEncoder.encode(matKhau);

        // Lấy vai trò "STAFF"
        VaiTro vaiTro = vaiTroRepository.findByTenVaiTro("STAFF");

        // Tạo đối tượng User
        Users user = new Users();
        user.setTaiKhoan(taiKhoan);
        user.setMatKhau(encodedPassword);
        user.setEmail(email);
        user.setNgayTao(new Date());
        user.setTrangThai(1); // Assuming 1 means active status
        user.setVaiTro(vaiTro);

        userRepository.save(user);

        // Tạo đối tượng NhanVien
        NhanVien nhanVien = new NhanVien();
        nhanVien.setTenNhanVien(ten);
        nhanVien.setDiaChi(diaChi);
        nhanVien.setSdt(soDienThoai);
        nhanVien.setGioiTinh(gioiTinh);
        nhanVien.setCccd(cccd);
        nhanVien.setUser(user);
        nhanVienRepository.save(nhanVien);

        return "success";
    }
//
        public String updateNhanVien(Integer id, String taiKhoan, String matKhau, String email, String ten,
                                     String diaChi, String soDienThoai, Integer gioiTinh,String cccd, Integer trangThai) {

            Optional<NhanVien> nhanVienOpt = nhanVienRepository.findById(id);
            if (!nhanVienOpt.isPresent()) {
                return "Nhân viên không tồn tại!";
            }
            NhanVien nhanVien = nhanVienOpt.get();

            if (userRepository.findByTaiKhoan(taiKhoan).isPresent() && !userRepository.findByTaiKhoan(taiKhoan).get().getId().equals(nhanVien.getUser().getId())) {
                return "Tên đăng nhập đã tồn tại!";
            }
            if (userRepository.findByEmail(email).isPresent() && !userRepository.findByEmail(email).get().getId().equals(nhanVien.getUser().getId())) {
                return "Email đã tồn tại!";
            }
            if (nhanVienRepository.findBySdt(soDienThoai).isPresent() && !nhanVienRepository.findBySdt(soDienThoai).get().getId().equals(nhanVien.getId())) {
                return "Số điện thoại đã tồn tại!";
            }


            if (!matKhau.isEmpty()) {
                String encodedPassword = passwordEncoder.encode(matKhau);
                nhanVien.getUser().setMatKhau(encodedPassword);
            }
            // Updating NhaanVien User
            Users user = nhanVien.getUser();
            user.setTaiKhoan(taiKhoan);
            user.setEmail(email);
            user.setNgayTao(new Date());
            user.setTrangThai(trangThai);
            nhanVien.setTenNhanVien(ten);
            nhanVien.setDiaChi(diaChi);
            nhanVien.setSdt(soDienThoai);
            nhanVien.setGioiTinh(gioiTinh);
            nhanVien.setCccd(cccd);
            nhanVienRepository.save(nhanVien);

            return "success";
        }

    public NhanVien findByTaiKhoan(String taiKhoan) {
        return nhanVienRepository.findByUser_TaiKhoan(taiKhoan).orElse(null);
    }

}

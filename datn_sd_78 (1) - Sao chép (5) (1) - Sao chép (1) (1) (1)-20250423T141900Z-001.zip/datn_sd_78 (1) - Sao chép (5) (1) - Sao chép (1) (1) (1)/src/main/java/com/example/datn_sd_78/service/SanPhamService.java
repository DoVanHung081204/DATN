package com.example.datn_sd_78.service;


import com.example.datn_sd_78.entity.SanPham;
import com.example.datn_sd_78.entity.SanPhamChiTiet;
import com.example.datn_sd_78.repository.ChiTietSanPhamRepository;
import com.example.datn_sd_78.repository.MauSacRepository;
import com.example.datn_sd_78.repository.SanPhamRepository;
import com.example.datn_sd_78.repository.SizeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class SanPhamService {
    @Autowired
    private SanPhamRepository sanPhamRepository;

    @Autowired
    private ChiTietSanPhamRepository sanPhamChiTietRepository;

    @Autowired
    private SizeRepository sizeRepository;

    @Autowired
    private MauSacRepository mauSacRepository;

    private List<SanPham> list = new ArrayList<>();

    public SanPham findById(int id) {
        return sanPhamRepository.findById(id).orElse(null);
    }

    public SanPhamChiTiet findByIdCTSP(int id) {
        return sanPhamChiTietRepository.findById(id)
                .orElse(null);
    }

    public SanPhamChiTiet save(SanPhamChiTiet sanPhamChiTiet) {
        return sanPhamChiTietRepository.save(sanPhamChiTiet);
    }

public SanPhamChiTiet findVariantByColorAndSize(Integer productId, String colorId, String sizeId) {
    // Tìm sản phẩm chi tiết từ cơ sở dữ liệu theo ID màu sắc và kích thước
    return sanPhamChiTietRepository.findVariantByColorAndSize(productId, colorId, sizeId);
}

}

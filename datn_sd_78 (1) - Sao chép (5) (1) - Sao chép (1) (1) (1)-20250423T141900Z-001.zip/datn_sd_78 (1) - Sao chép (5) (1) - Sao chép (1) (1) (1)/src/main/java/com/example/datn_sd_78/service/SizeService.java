package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.Size;
import com.example.datn_sd_78.repository.SizeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class SizeService {
    @Autowired
    private SizeRepository sizeRepository;

    // Phương thức tìm màu sắc theo tên
    public Size findByTen(String ten) {
        return sizeRepository.findByTen(ten);
    }

    public List<Size> getAllSizes() {
        return sizeRepository.findAll();
    }
}

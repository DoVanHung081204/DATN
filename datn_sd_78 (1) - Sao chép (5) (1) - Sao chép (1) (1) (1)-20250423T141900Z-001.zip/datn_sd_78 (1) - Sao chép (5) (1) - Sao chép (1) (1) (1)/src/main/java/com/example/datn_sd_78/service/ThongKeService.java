package com.example.datn_sd_78.service;

import com.example.datn_sd_78.repository.HoaDonChiTietRepository;
import com.example.datn_sd_78.repository.HoaDonRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class ThongKeService {

    @Autowired
    private HoaDonChiTietRepository hoaDonChiTietRepository;
    @Autowired
    private HoaDonRepository hoaDonRepository;

    // Thống kê doanh thu trong ngày
    public BigDecimal getDoanhThuTrongNgay() {
        List<Object[]> results = hoaDonRepository.getDoanhThuTrongNgayData();

        if (results == null || results.isEmpty()) {
            // Thêm logging hoặc debug để kiểm tra dữ liệu
            System.out.println("No data found for today's revenue.");
            return BigDecimal.ZERO;
        }

        Object[] row = results.get(0);
        if (row != null && row.length > 0 && row[0] != null) {
            return (BigDecimal) row[0];
        }

        return BigDecimal.ZERO;
    }



    // Thống kê số lượng đã bán trong khoảng thời gian
    public Long getSoLuongDaBan(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getSoLuongDaBan(startDate, endDate);
    }

    // Thống kê tổng doanh thu trong khoảng thời gian
    public BigDecimal getDoanhThuTrongKhoangNgay(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getDoanhThuTrongKhoangNgay(startDate, endDate);
    }

    // Thống kê tổng số hóa đơn trong khoảng thời gian
    public Long getTongHoaDonTrongKhoangNgay(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getTongHoaDonTrongKhoangNgay(startDate, endDate);
    }

    // Thống kê tổng doanh thu trong khoảng thời gian
    public BigDecimal getTongDoanhThu(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getDoanhThuTrongKhoangNgay(startDate, endDate);
    }

    // Thống kê tổng số hóa đơn trong khoảng thời gian
    public Long getTongHoaDon(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getTongHoaDonTrongKhoangNgay(startDate, endDate);
    }

    // Thống kê tổng số hóa đơn đã hủy trong khoảng thời gian
    public Long getTongHoaDonHuy(LocalDate startDate, LocalDate endDate) {
        return hoaDonChiTietRepository.getTongHoaDonHuy(startDate, endDate);
    }

    // Lấy danh sách sản phẩm bán chạy nhất
    public List<Object[]> getTopSellingProducts() {
        return hoaDonChiTietRepository.getTopSellingProducts();
    }

    // Lấy doanh thu theo tháng
    public List<Object[]> getDoanhThuTheoThang(int year) {
        return hoaDonChiTietRepository.getDoanhThuTheoThang(year);
    }

    // Lấy danh sách sản phẩm tồn kho
    public List<Object[]> getSanPhamTonKho() {
        return hoaDonChiTietRepository.getSanPhamTonKho();
    }
    // Thống kê top 3 khách hàng theo doanh thu trong tháng hiện tại
    public List<Object[]> getTopCustomersBySales() {
        return hoaDonRepository.getTopCustomersBySales();
    }
}

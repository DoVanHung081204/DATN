package com.example.datn_sd_78.service;


import com.example.datn_sd_78.entity.Users;
import com.example.datn_sd_78.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Collections;

@Service
public class UserService implements UserDetailsService {

    @Autowired
    private UserRepository userRepository;

    @Override
    public UserDetails loadUserByUsername(String taiKhoan) throws UsernameNotFoundException {
        // Tìm người dùng theo tài khoản
        Users user = userRepository.findByTaiKhoan(taiKhoan)
                .orElseThrow(() -> new UsernameNotFoundException("User not found"));

        // Kiểm tra trạng thái tài khoản (đang hoạt động hay bị vô hiệu hóa)
        if (user.getTrangThai() != 1) {
            throw new DisabledException("Account is not active");
        }

        // Trả về UserDetails với các quyền tương ứng
        return new org.springframework.security.core.userdetails.User(
                user.getTaiKhoan(),
                user.getMatKhau(),
                Collections.singletonList(new SimpleGrantedAuthority(user.getVaiTro().getTenVaiTro()))
        );
    }

}


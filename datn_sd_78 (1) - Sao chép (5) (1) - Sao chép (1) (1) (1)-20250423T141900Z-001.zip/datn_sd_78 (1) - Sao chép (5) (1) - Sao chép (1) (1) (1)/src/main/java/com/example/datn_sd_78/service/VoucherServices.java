package com.example.datn_sd_78.service;

import com.example.datn_sd_78.entity.KhachHang;
import com.example.datn_sd_78.entity.Voucher;
import com.example.datn_sd_78.repository.KhachHangRepository;
import com.example.datn_sd_78.repository.VoucherRepository;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Service
public class VoucherServices {

    @Autowired
    VoucherRepository voucherRepository;

    @Autowired
    KhachHangRepository khachHangRepository;

    @Transactional
    public void createVoucher(String ten, String ma, BigDecimal giaTriGiam,BigDecimal giaTriDonHangToiThieu, Date ngayBatDau,
                              Date ngayKetThuc, Boolean trangThai, List<Integer> khachHangIds) {

        // 1. Tạo đối tượng Voucher
        Voucher voucher = new Voucher();
        voucher.setTen(ten);
        voucher.setMa(ma);
        voucher.setGiaTriGiam(giaTriGiam);
        voucher.setGiaTriDonHangToiThieu(giaTriDonHangToiThieu);
        voucher.setNgayBatDau(ngayBatDau);
        voucher.setNgayKetThuc(ngayKetThuc);
        voucher.setTrangThai(0);

        // 2. Lưu Voucher vào cơ sở dữ liệu
        voucher = voucherRepository.save(voucher);

        // 3. Xử lý liên kết với khách hàng
        if (khachHangIds != null && !khachHangIds.isEmpty()) {
            // Lấy danh sách khách hàng từ ID
            List<KhachHang> customers = khachHangRepository.findAllById(khachHangIds);

            // Thêm các khách hàng vào quan hệ ManyToMany của Voucher
            voucher.getKhachHangs().addAll(customers);

            // Cập nhật lại voucher để lưu mối quan hệ
            voucherRepository.save(voucher);
        }
    }

    public List<Voucher> getVouchersByCustomerId(Integer customerId) {
        return voucherRepository.findByKhachHangs_Id(customerId);
    }

}

document.addEventListener("DOMContentLoaded", function () {
    var provinceId = null;
    var districtId = null;

    // Lưu giá trị tổng tiền ban đầu của các sản phẩm
    var originalTotalAmount = parseFloat($("#tongTienHienThi").text().replace(/[^\d]/g, "")) || 0;

    // Khi thay đổi tỉnh thành
    $('#tinhThanh').change(function () {
        provinceId = $(this).val();
        console.log(provinceId);

        if (provinceId) {
            $.ajax({
                url: '/checkout/getDistricts/' + provinceId,
                method: 'GET',
                success: function (data) {
                    var districtsDropdown = $('#quanHuyen');
                    districtsDropdown.empty();
                    districtsDropdown.append('<option value="">Chọn quận huyện</option>');

                    if (data && Array.isArray(data)) {
                        $.each(data, function (index, district) {
                            districtsDropdown.append('<option value="' + district.DistrictID + '">' + district.DistrictName + '</option>');
                        });
                    } else {
                        districtsDropdown.append('<option value="">Không có quận huyện</option>');
                    }
                },
                error: function () {
                    alert('Lỗi khi tải quận huyện. Vui lòng thử lại.');
                }
            });
        } else {
            $('#quanHuyen').empty().append('<option value="">Chọn quận huyện</option>');
        }

        // Reset phường xã và phí ship khi thay đổi tỉnh
        $('#phuongXa').empty().append('<option value="">Chọn phường xã</option>');
        $('#phiShip').val(0);  // Reset phí ship về 0
        capNhatTongTien(); // Cập nhật lại tổng tiền
    });

    // Khi thay đổi quận huyện
    $('#quanHuyen').change(function () {
        districtId = $(this).val();
        console.log(districtId);

        if (districtId) {
            $.ajax({
                url: '/checkout/getWards/' + districtId,
                method: 'GET',
                success: function (response) {
                    var wardsDropdown = $('#phuongXa');
                    wardsDropdown.empty();
                    wardsDropdown.append('<option value="">Chọn phường xã</option>');

                    if (response && Array.isArray(response)) {
                        $.each(response, function (index, ward) {
                            wardsDropdown.append('<option value="' + ward.WardCode + '">' + ward.WardName + '</option>');
                        });
                    } else {
                        wardsDropdown.append('<option value="">Không có phường xã</option>');
                    }
                },
                error: function () {
                    alert('Lỗi khi tải phường xã. Vui lòng thử lại.');
                }
            });
        } else {
            $('#phuongXa').empty().append('<option value="">Chọn phường xã</option>');
        }

        // Reset phí ship và cập nhật tổng tiền khi thay đổi quận huyện
        $('#phiShip').val(0); // Reset phí ship về 0
        capNhatTongTien(); // Cập nhật lại tổng tiền
    });

    // Khi thay đổi phường xã
    $('#phuongXa').change(function () {
        var wardId = $(this).val();
        console.log("wardId", wardId);
        const requestData = {
            service_type_id: 2,
            from_district_id: 1447,  // Quận/huyện gửi
            from_ward_code: "20515",  // Mã phường/xã gửi
            to_district_id: districtId,  // Quận/huyện nhận
            to_ward_code: wardId,  // Mã phường/xã nhận
            weight: 2000,  // Trọng lượng sản phẩm (hoặc có thể thay đổi theo yêu cầu)
        };

        // Gửi AJAX POST request tính phí vận chuyển
        $.ajax({
            url: "/ship",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            success: function (response) {
                console.log("Response from server:", response);
                const shippingFee = response.data.total;

                // Cập nhật phí ship và tính lại tổng tiền
                $('#phiShip').val(new Intl.NumberFormat().format(shippingFee));
                capNhatTongTien(); // Cập nhật lại tổng tiền
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
                alert("Có lỗi xảy ra khi tính phí vận chuyển.");
            },
        });
    });

    // Hàm cập nhật tổng tiền
    window.capNhatTongTien = function()  {
        // Lấy lại giá trị tổng tiền sản phẩm từ đầu, không bao gồm phí ship
        var tongTienSanPham = originalTotalAmount;

        // Lấy giá trị phí ship mới
        var phiShip = parseFloat($("#phiShip").val().replace(/[^\d]/g, "")) || 0;

        // Lấy giá trị giảm giá từ ô nhập liệu
        var tienGiam = parseFloat($("#tienGiam").val().replace(/[^\d]/g, "")) || 0;

        // Tính tổng tiền (sản phẩm + phí ship - giảm giá)
        var tongTien = tongTienSanPham + phiShip - tienGiam;

        // Đảm bảo tổng tiền không âm
        if (tongTien < 0) {
            tongTien = 0;
        }

        // Cập nhật hiển thị tổng tiền
        $("#tongTienHienThi").text(new Intl.NumberFormat().format(tongTien) + "₫");

        // Cập nhật giá trị tổng tiền trong trường input (thực hiện cho thanh toán)
        $("input[name='amount']").val(tongTien);

        $("#phiShipHidden").val(phiShip);
    }


    // Kiểm tra form khi gửi
    document.getElementById("paymentForm").addEventListener("submit", function (event) {
        let valid = true;

        // Lấy các trường dữ liệu
        const name = document.getElementById("input1");
        const email = document.getElementById("input2");
        const address = document.getElementById("input3");
        const phone = document.getElementById("input4");
        const tinhThanh = document.getElementById("tinhThanh");
        const quanHuyen = document.getElementById("quanHuyen");
        const phuongXa = document.getElementById("phuongXa");

        const nameNoNumberRegex = /^[^\d]+$/;
        const nameNoSpecialCharRegex = /^[a-zA-ZàáảãạăắằẳẵặâấầẩẫậèéẻẽẹêếềểễệìíỉĩịòóỏõọôốồổỗộơớờởỡợùúủũụưứừửữựỳýỷỹỵđĐ\s]+$/;
        const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
        const phoneRegex = /^\+?\d{10}$/;

        if (!name.value) {
            event.preventDefault();
            markInvalid(name, 'Vui lòng nhập tên người nhận hàng !!!');
            return;
        } else if (!nameNoNumberRegex.test(name.value)) {
            event.preventDefault();
            markInvalid(name, 'Tên không được chứa số !!!');
            return;
        } else if (!nameNoSpecialCharRegex.test(name.value)) {
            event.preventDefault();
            markInvalid(name, 'Tên không được chứa ký tự đặc biệt !!!');
            return;
        } else {
            clearInvalid(name);
        }

        if (!address.value) {
            event.preventDefault();
            markInvalid(address, 'Vui lòng nhập địa chỉ người nhận hàng !!!');
            return;
        } else {
            clearInvalid(address);
        }

        if (!email.value) {
            event.preventDefault();
            markInvalid(email, 'Vui lòng nhập email người nhận hàng !!!');
            return;
        } else if (!emailRegex.test(email.value)) {
            event.preventDefault();
            markInvalid(email, 'Vui lòng nhập đúng định dạng email');
            return;
        } else {
            clearInvalid(email);
        }


        if (!phone.value) {
            event.preventDefault();
            markInvalid(phone, 'Vui lòng nhập số điện thoại người nhận hàng !!!');
            return;
        } else if (!phoneRegex.test(phone.value)) {
            event.preventDefault();
            markInvalid(phone, 'Vui lòng nhập đúng định dạng email');
            return;
        } else {
            clearInvalid(phone);
        }

        if (!tinhThanh.value) {
            event.preventDefault();
            markInvalid(tinhThanh, 'Vui lòng chọn tỉnh thành người nhận hàng !!!');
            return;
        } else {
            clearInvalid(tinhThanh);
        }

        if (!quanHuyen.value) {
            event.preventDefault();
            markInvalid(quanHuyen, 'Vui lòng chọn quận huyện người nhận hàng !!!');
            return;
        } else {
            clearInvalid(quanHuyen);
        }

        if (!phuongXa.value) {
            event.preventDefault();
            markInvalid(phuongXa, 'Vui lòng chọn phường xã người nhận hàng !!!');
            return;
        } else {
            clearInvalid(phuongXa);
        }


        function markInvalid(input, message) {
            input.classList.add('is-invalid');
            showAlert('error', message);
            input.focus();
        }

        function clearInvalid(input) {
            input.classList.remove('is-invalid');
        }
    });

});


document.getElementById('clearIcon').addEventListener('click', function (e) {
    e.preventDefault(); // Ngăn chặn hành vi mặc định của thẻ <a>

    var voucherId = document.getElementById('voucherId').value; // Lấy voucherId từ input ẩn

    // Kiểm tra xem có voucherId không
    if (!voucherId) {
        showAlert('error', 'Không có voucher cần xóa!');
        return;
    }

    // Gửi yêu cầu POST đến server
    fetch('/online/remove-voucher', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ voucherId: voucherId })  // Gửi voucherId đến server
    })
        .then(response => {
            if (response.ok) {
                showAlert('success', 'Voucher đã được xóa khỏi hóa đơn!')
                    .then(() => {
                        document.getElementById("tienGiam").value = ""; // Reset giá trị input giảm giá
                        capNhatTongTien(); // Cập nhật lại tổng tiền
                        location.reload();  // Reload trang sau khi thông báo đóng
                    });
            } else {
                showAlert('error', 'Có lỗi xảy ra khi xóa voucher.');
            }
        })
        .catch(error => {
            showAlert('error', 'Lỗi');
        });
});

document.getElementById('searchButton').addEventListener('click', function (event) {
    event.preventDefault();
    var keyword = document.getElementById('keyword').value;
    var minPrice = parseFloat(document.getElementById('minPrice').value);
    var maxPrice = parseFloat(document.getElementById('maxPrice').value);
    var color = document.getElementById('color').value;
    var size = document.getElementById('size').value;

    // Validate keyword (optional)
    if (!keyword.trim() && !color && !size && !minPrice && !maxPrice) {
        showAlert('warning', 'Vui lòng nhập ít nhất một tiêu chí tìm kiếm.');
        event.preventDefault();  // Prevent form submission or page reload
        return;
    }

    // Validate price range
    if (minPrice && maxPrice && minPrice > maxPrice) {
        showAlert('error', 'Giá tối thiểu không thể lớn hơn giá tối đa.');
        event.preventDefault();
        return;
    }


    var productsList = document.getElementById('productsList');  // ID of the container holding the products
    if (productsList && productsList.children.length === 0) {
        showAlert('warning', 'Không có sản phẩm nào phù hợp với tiêu chí tìm kiếm.');
        event.preventDefault();
        return;
    }
});



function showAlert(icon, title) {
    return Swal.fire({
        icon: icon,               // Biểu tượng của thông báo (error, success, v.v.)
        title: title,             // Tiêu đề của thông báo
        toast: true,              // Hiển thị như một toast
        position: 'top-end',      // Vị trí góc trên bên phải
        showConfirmButton: false, // Không hiển thị nút xác nhận
        timer: 1000,              // Thông báo tự động đóng sau 1 giây
        timerProgressBar: true,   // Hiển thị thanh tiến trình
        background: icon === 'success' ? '#4CAF50' : '#f44336', // Màu nền tùy thuộc vào icon
        color: '#fff',            // Màu chữ
        padding: '10px',          // Padding trong thông báo
    }).then(() => {
        // Bạn có thể thêm hành động sau khi thông báo đóng ở đây
        // Ví dụ, reload trang:
        console.log("Thông báo đã đóng!");
    });
}

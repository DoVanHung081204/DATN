document.addEventListener("DOMContentLoaded", function () {
    var provinceId = null;
    var districtId = null;

    // Lưu giá trị tổng tiền ban đầu của các sản phẩm
    var originalTotalAmount = parseFloat($("#tienHang").val().replace(/[^\d]/g, "")) || 0;
    // Khi thay đổi tỉnh thành
    $('#tinhThanh').change(function () {
        provinceId = $(this).val();
        console.log(provinceId);

        if (provinceId) {
            $.ajax({
                url: '/checkout/getDistricts/' + provinceId,
                method: 'GET',
                success: function (data) {
                    var districtsDropdown = $('#quanHuyen');
                    districtsDropdown.empty();
                    districtsDropdown.append('<option value="">Chọn quận huyện</option>');

                    if (data && Array.isArray(data)) {
                        $.each(data, function (index, district) {
                            districtsDropdown.append('<option value="' + district.DistrictID + '">' + district.DistrictName + '</option>');
                        });
                    } else {
                        districtsDropdown.append('<option value="">Không có quận huyện</option>');
                    }
                },
                error: function () {
                    alert('Lỗi khi tải quận huyện. Vui lòng thử lại.');
                }
            });
        } else {
            $('#quanHuyen').empty().append('<option value="">Chọn quận huyện</option>');
        }

        // Reset phường xã và phí ship khi thay đổi tỉnh
        $('#phuongXa').empty().append('<option value="">Chọn phường xã</option>');
        capNhatTongTienKhongShip();
        $('#phiShip').val(0);  // Reset phí ship về 0
    });

    // Khi thay đổi quận huyện
    $('#quanHuyen').change(function () {
        districtId = $(this).val();
        console.log(districtId);

        if (districtId) {
            $.ajax({
                url: '/checkout/getWards/' + districtId,
                method: 'GET',
                success: function (response) {
                    var wardsDropdown = $('#phuongXa');
                    wardsDropdown.empty();
                    wardsDropdown.append('<option value="">Chọn phường xã</option>');

                    if (response && Array.isArray(response)) {
                        $.each(response, function (index, ward) {
                            wardsDropdown.append('<option value="' + ward.WardCode + '">' + ward.WardName + '</option>');
                        });
                    } else {
                        wardsDropdown.append('<option value="">Không có phường xã</option>');
                    }
                },
                error: function () {
                    alert('Lỗi khi tải phường xã. Vui lòng thử lại.');
                }
            });
        } else {
            $('#phuongXa').empty().append('<option value="">Chọn phường xã</option>');
        }

        // Reset phí ship và cập nhật tổng tiền khi thay đổi quận huyện
        $('#phiShip').val(0); // Reset phí ship về 0
    });

    // Khi thay đổi phường xã
    $('#phuongXa').change(function () {
        var wardId = $(this).val();
        console.log("wardId", wardId);
        const requestData = {
            service_type_id: 2,
            from_district_id: 1447,  // Quận/huyện gửi
            from_ward_code: "20515",  // Mã phường/xã gửi
            to_district_id: districtId,  // Quận/huyện nhận
            to_ward_code: wardId,  // Mã phường/xã nhận
            weight: 2000,  // Trọng lượng sản phẩm (hoặc có thể thay đổi theo yêu cầu)
        };

        // Gửi AJAX POST request tính phí vận chuyển
        $.ajax({
            url: "/ship",
            type: "POST",
            contentType: "application/json",
            data: JSON.stringify(requestData),
            success: function (response) {
                console.log("Response from server:", response);
                const shippingFee = response.data.total;

                // Cập nhật phí ship và tính lại tổng tiền
                $('#phiShip').val(new Intl.NumberFormat().format(shippingFee));
                capNhatTongTien(); // Cập nhật lại tổng tiền
            },
            error: function (xhr, status, error) {
                console.error("Error:", error);
                showAlert('error', "Có lỗi xảy ra khi tính phí vận chuyển.");
            },
        });
    });

    // Hàm cập nhật tổng tiền
    function capNhatTongTien() {
        var tongTienSanPham = parseFloat($("#thanhTien").val().replace(/[^\d]/g, "")) || 0;
        var phiShip = parseFloat($("#phiShip").val().replace(/[^\d]/g, "")) || 0;
        var tongTien = tongTienSanPham + phiShip;
        $("#phiShip").val(new Intl.NumberFormat('vi-VN').format(phiShip) + "₫");
        $("input[name='thanhTien']").val(new Intl.NumberFormat('vi-VN').format(tongTien) + "₫");
    }

    function capNhatTongTienKhongShip() {
        var tongTienSanPham = parseFloat($("#thanhTien").val().replace(/[^\d]/g, "")) || 0;
        var phiShip = parseFloat($("#phiShip").val().replace(/[^\d]/g, "")) || 0;
        var tongTien = tongTienSanPham - phiShip;
        $("#phiShip").val(new Intl.NumberFormat('vi-VN').format(phiShip) + "₫");
        $("input[name='thanhTien']").val(new Intl.NumberFormat('vi-VN').format(tongTien) + "₫");
    }

});


// Lấy phần tử input
const thanhTienInput = document.getElementById('thanhTien');
const tienHangInput = document.getElementById('tienHang');
const tienGiamInput = document.getElementById('tienGiam');

// Hàm định dạng số tiền
function formatCurrency(value) {
    if (!isNaN(value)) {
        return parseInt(value).toLocaleString('vi-VN') + '₫';
    }
    return value;
}

if (thanhTienInput && tienHangInput && tienGiamInput) {
    let value = thanhTienInput.value.trim();
    let value1 = tienHangInput.value.trim();
    let value2 = tienGiamInput.value.trim();
    if (value.includes('.00')) {
        value = parseInt(value);
    }
    if (value1.includes('.00')) {
        value1 = parseInt(value1);
    }

    if (value2) {
        if (value2.includes('.00')) {
            value2 = parseInt(value2);
        }
        tienGiamInput.value = formatCurrency(value2);
    } else {
        tienGiamInput.value = '';
    }
    thanhTienInput.value = formatCurrency(value || 0);  // Nếu không có giá trị, dùng 0
    tienHangInput.value = formatCurrency(value1 || 0);  // Nếu không có giá trị, dùng 0
}


// Hàm để cập nhật form giao hàng hoặc hình ảnh thay thế
function toggleDeliveryForm() {
    const deliveryForm = document.getElementById('deliveryForm');
    const nhanTaiQuay = document.getElementById('nhanTaiQuay');
    const deliveryFormPlaceholder = document.getElementById('deliveryFormPlaceholder');

    if (!deliveryFormPlaceholder) {
        console.error("Không tìm thấy phần tử với id 'deliveryFormPlaceholder'");
        return;
    }

    if (nhanTaiQuay.checked) {
        deliveryForm.style.display = 'none'; // Ẩn form giao hàng
        deliveryFormPlaceholder.style.display = 'block'; // Hiển thị hình ảnh
    } else {
        deliveryForm.style.display = 'block'; // Hiển thị form giao hàng
        deliveryFormPlaceholder.style.display = 'none'; // Ẩn hình ảnh
    }
}

// Kiểm tra trạng thái checkbox ngay khi trang được tải
document.addEventListener('DOMContentLoaded', function () {
    toggleDeliveryForm(); // Cập nhật form và hình ảnh ngay khi trang được tải
});

// Hàm cập nhật tiền thừa
function capNhatTienThua() {
    var tongTien = parseFloat($("#thanhTien").val().replace(/[^\d]/g, "")) || 0;
    var tienKhachDua = parseFloat($("#tienKhachDua").val().replace(/[^\d]/g, "")) || 0;
    var tienThua = tienKhachDua - tongTien;

    // Định dạng và hiển thị tiền thừa
    $("#tienThua").val(new Intl.NumberFormat('vi-VN').format(Math.max(tienThua, 0)) + "₫");

    // Kiểm tra nếu tiền khách đưa nhỏ hơn tổng tiền
    if (tienKhachDua < tongTien) {
        // Thêm lớp input-error nếu tiền khách đưa nhỏ hơn tổng tiền
        $("#tienKhachDua").addClass("input-error");

        // Vô hiệu hóa hover của button và link
        $(".button-container button, .button-container a").addClass("disable-hover");
    } else {
        // Xóa lớp input-error nếu tiền khách đưa đủ hoặc lớn hơn tổng tiền
        $("#tienKhachDua").removeClass("input-error");

        // Kích hoạt lại hiệu ứng hover của button và link
        $(".button-container button, .button-container a").removeClass("disable-hover");
    }
}

function convertToNumber(value) {
    // Loại bỏ tất cả ký tự không phải là số và dấu "."
    return value.replace(/[^\d]/g, "");
}

// Hàm định dạng số tiền
function dinhDangTien(input) {
    // Loại bỏ các ký tự không phải là số
    var value = input.value.replace(/[^\d]/g, '');

    // Chia số tiền thành nhóm hàng nghìn và thêm dấu chấm vào giữa
    var formattedValue = value.replace(/\B(?=(\d{3})+(?!\d))/g, ".");

    // Cập nhật giá trị của input với định dạng
    input.value = formattedValue;
}


document.querySelector('form[action*="thanhToan"]').addEventListener('submit', function (e) {
    // Xử lý các input tiền (nếu cần làm sạch giá trị)
    const phiShipInput = document.getElementById('phiShip');
    const thanhTienInput = document.getElementById('thanhTien');
    const tienKhachDuaInput = document.getElementById('tienKhachDua');
    const tienGiamInput = document.getElementById('tienGiam');
    const tienHangInput = document.getElementById('tienHang')

// Hàm convertToNumber để chuyển đổi giá trị input sang số thực
    phiShipInput.value = convertToNumber(phiShipInput.value);
    thanhTienInput.value = convertToNumber(thanhTienInput.value);
    tienKhachDuaInput.value = convertToNumber(tienKhachDuaInput.value);
    tienGiamInput.value = convertToNumber(tienGiamInput.value);
    tienHangInput.value = convertToNumber(tienHangInput.value)

// Kiểm tra trường "Tiền khách đưa"
    const tienKhachDua = parseFloat(tienKhachDuaInput.value);
    const thanhTien = parseFloat(thanhTienInput.value);
    const tienHang = parseFloat(tienHangInput.value);

    // Kiểm tra xem hoaDonId có tồn tại trong session hay không
    const hoaDonId = document.getElementById('hoaDonId').value;

    if (!hoaDonId) {
        e.preventDefault();
        showAlert('error', 'Vui lòng chọn hóa đơn trước khi thanh toán.');
        return;
    }

    if (!tienHang > 0) {
        e.preventDefault();
        markInvalid(tienHangInput, 'Vui lòng hủy hóa đơn nếu không mua hàng');
        return;
    } else {
        clearInvalid(tienHangInput);
    }

    if (tienKhachDua < thanhTien) {
        e.preventDefault();
        showAlert('error', 'Số tiền khách đưa không đủ!');
        tienKhachDuaInput.focus();
        return;
    }

    function markInvalid(input, message) {
        input.classList.add('is-invalid');
        showAlert('error', message);
        input.focus();
    }

    function clearInvalid(input) {
        input.classList.remove('is-invalid');
    }


    const giaoHangInput = document.getElementById('giaoHang');
    if (giaoHangInput.checked) {
        const phoneInput = document.getElementById('sdt');
        const tinhThanhInput = document.getElementById('tinhThanh');
        const quanHuyenInput = document.getElementById('quanHuyen');
        const phuongXaInput = document.getElementById('phuongXa');
        const diaChiInput = document.getElementById('diaChi');

        if (!tinhThanhInput.value) {
            e.preventDefault();
            markInvalid(tinhThanhInput, 'Vui lòng chọn tỉnh thành');
            return;
        } else {
            clearInvalid(tinhThanhInput);
        }

        if (!quanHuyenInput.value) {
            e.preventDefault();
            markInvalid(quanHuyenInput, 'Vui lòng chọn quận/huyện');
            return;
        } else {
            clearInvalid(quanHuyenInput);
        }

        if (!phuongXaInput.value) {
            e.preventDefault();
            markInvalid(phuongXaInput, 'Vui lòng chọn phường xã');
            return;
        } else {
            clearInvalid(phuongXaInput);
        }

        if (!diaChiInput.value.trim()) {
            e.preventDefault();
            markInvalid(diaChiInput, 'Vui lòng nhập địa chỉ');
            return;
        } else {
            clearInvalid(diaChiInput);
        }

        // Kiểm tra số điện thoại hợp lệ
        const phoneRegex = /^0[0-9]{9}$/; // Số bắt đầu bằng 0 và có tổng cộng 10 chữ số
        if (!phoneRegex.test(phoneInput.value)) {
            e.preventDefault();
            markInvalid(phoneInput, 'Vui lòng nhập số điện thoại hợp lệ');
            return;
        } else {
            clearInvalid(phoneInput);
        }
    }
});

// Xóa voucher khỏi hóa đơn
document.getElementById('clearIcon').addEventListener('click', function (e) {
    e.preventDefault(); // Ngăn chặn hành vi mặc định của thẻ <a>

    var voucherId = document.getElementById('voucherId').value; // Lấy voucherId từ input ẩn

    // Kiểm tra xem có voucherId không
    if (!voucherId) {
        showAlert('error', 'Không có voucher cần xóa!');
        return;
    }

    // Gửi yêu cầu POST đến server
    fetch('/order/xoavoucher', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ voucherId: voucherId })  // Gửi voucherId đến server
    })
        .then(response => {
            if (response.ok) {
                showAlert('success', 'Voucher đã được xóa khỏi hóa đơn!')
                    .then(() => {
                        location.reload();  // Reload trang sau khi thông báo đóng
                    });
            } else {
                showAlert('error', 'Có lỗi xảy ra khi xóa voucher.');
            }
        })
        .catch(error => {
            showAlert('error', 'Lỗi')
        });
});


// Xóa khách hàng khỏi hóa đơn
document.getElementById('clearCustomer').addEventListener('click', function (e) {
    e.preventDefault(); // Ngăn chặn hành vi mặc định của thẻ <a>

    var customerId = document.getElementById('customerId').value; // Lấy customerId từ input ẩn

    // Kiểm tra xem có customerId không
    if (!customerId) {
        showAlert('error', 'Không có khách hàng cần xóa!');
        return;
    }

    // Gửi yêu cầu POST đến server để xóa khách hàng khỏi hóa đơn
    fetch('/order/xoakhachhang', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({ customerId: customerId })  // Gửi customerId đến server
    })
        .then(response => {
            if (response.ok) {
                showAlert('success', 'Khách hàng đã được xóa khỏi hóa đơn!')
                    .then(() => {
                        location.reload();  // Reload trang sau khi thông báo đóng
                    });
            } else {
                showAlert('error', 'Có lỗi xảy ra khi xóa khách hàng.');
            }
        })
        .catch(error => {
            showAlert('error', 'Lỗi');
        });
});



function showAlert(icon, title) {
    return Swal.fire({
        icon: icon,               // Biểu tượng của thông báo (error, success, v.v.)
        title: title,             // Tiêu đề của thông báo
        toast: true,              // Hiển thị như một toast
        position: 'top-end',      // Vị trí góc trên bên phải
        showConfirmButton: false, // Không hiển thị nút xác nhận
        timer: 1000,              // Thông báo tự động đóng sau 1 giây
        timerProgressBar: true,   // Hiển thị thanh tiến trình
        background: icon === 'success' ? '#4CAF50' : '#f44336', // Màu nền tùy thuộc vào icon
        color: '#fff',            // Màu chữ
        padding: '10px',          // Padding trong thông báo
    }).then(() => {
        // Bạn có thể thêm hành động sau khi thông báo đóng ở đây
        // Ví dụ, reload trang:
        console.log("Thông báo đã đóng!");
    });
}







